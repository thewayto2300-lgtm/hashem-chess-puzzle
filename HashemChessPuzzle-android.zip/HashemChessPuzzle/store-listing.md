# نصوص صفحة Google Play

## اسم التطبيق (30 حرفًا كحد أقصى)
Hashem Chess Puzzle

## وصف قصير — عربي (80 حرفًا كحد أقصى)
دروس شطرنج تفاعلية وألغاز ولعب ضد الكمبيوتر، بالعربية وبدون إنترنت.

## Short description — English
Interactive chess lessons, puzzles and play against the computer. Works offline.

## وصف كامل — عربي
تطبيق Hashem Chess Puzzle يأخذك في الشطرنج خطوة بخطوة، من حركة القطع حتى التكتيك والكش مات.

• دروس تفاعلية: تلعب النقلة على الرقعة، ويشرح لك المدرب لماذا هي صحيحة ولماذا النقلة الأخرى خطأ.
• منهجان: تعليمي لقواعد اللعبة ومبادئها، وتنافسي للاستعداد للبطولات.
• أكثر من 17 ألف لغز من قاعدة Lichess، مقسمة بالموضوع والمستوى، بتقييم يتغير مع مستواك.
• العب ضد الكمبيوتر بستة مستويات، ثم حلّل مباراتك.
• تحليل بمحرك Stockfish 19 (النسخة الخفيفة للموبايل) للأوضاع والمباريات، ويقبل FEN و PGN.
• عربي وإنجليزي، ويعمل بدون إنترنت، بلا إعلانات ولا جمع بيانات.

من إعداد مدربي أكاديمية Hashem Chess Castle.

## Full description — English
Hashem Chess Puzzle takes you through chess step by step, from how the pieces move to tactics and checkmates.

• Interactive lessons: you play the move on the board and the coach explains why it works and why the other move fails.
• Two tracks: an educational one for the rules and principles, and a competitive one for tournament preparation.
• Over 17,000 puzzles from the Lichess database, by theme and level, with a rating that follows your level.
• Play the computer at six levels, then analyse your game.
• Analysis with the Stockfish 19 engine (lite mobile build), accepting FEN and PGN.
• Arabic and English, works offline, no ads and no data collection.

Made by the coaches of the Hashem Chess Castle academy.

## ملاحظة الرخصة (في آخر الوصف)
يستخدم التطبيق محرك Stockfish (رخصة GPLv3). الكود المصدري: [رابط الكود]
Uses the Stockfish engine (GPLv3). Source code: [link]
