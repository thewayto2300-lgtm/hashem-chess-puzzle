/*
 * Builds the app into one self-contained index.html.
 *   node build.js
 * Output: web/dist/index.html and a copy in the Android project's assets (app/src/main/assets/www/index.html).
 */
const fs = require('fs'), path = require('path');
const src = f => fs.readFileSync(path.join(__dirname, 'src', f), 'utf8');
const lessons = fs.readdirSync(path.join(__dirname, 'src/content')).filter(f => f.endsWith('.pgn')).sort().map(f => ({ name: f, text: src('content/' + f) }));
const puzzles = JSON.parse(src('content/puzzles.builtin.json'))
  .concat(fs.existsSync(path.join(__dirname, 'src/content/puzzles.lichess.json')) ? JSON.parse(src('content/puzzles.lichess.json')) : []);
const builtin = 'window.HCC_BUILTIN = ' + JSON.stringify({ lessons, puzzles }).replace(/</g, '\\u003c') + ';';
const app = ['logo.js', 'ui.js', 'board.js', 'engines.js', 'content.js', 'views.js'].map(src).join('\n');
const parts = { CSS: src('styles.css'), CHESS: src('chess.js'), ENGINE: src('engine.js'), BUILTIN: builtin, APP: app };
let html = src('index.template.html').replace('<!--{{PIECES}}-->', () => src('pieces.svg').trim());
for (const k in parts) {
  if (/<\/script/i.test(parts[k])) throw new Error(k + ' contains a closing script tag');
  html = html.replace('/*{{' + k + '}}*/', () => parts[k]);
}
fs.mkdirSync(path.join(__dirname, 'dist'), { recursive: true });
fs.writeFileSync(path.join(__dirname, 'dist/index.html'), html);
const assets = path.join(__dirname, '../app/src/main/assets/www');
fs.mkdirSync(assets, { recursive: true });
fs.writeFileSync(path.join(assets, 'index.html'), html);
console.log('built', (html.length / 1024).toFixed(0) + ' KB,', lessons.length, 'lesson files,', puzzles.length, 'puzzles');
