const { chromium } = require('playwright');
const path = require('path'), fs = require('fs');
const URL = 'file://' + path.join(__dirname, '../dist/index.html'), SHOTS = '/tmp/shots';
let fail = 0; const errors = [];
const ok = (name, cond, extra) => { if (!cond) { fail++; console.log('FAIL', name, extra === undefined ? '' : extra); } else console.log('ok  ', name); };
(async () => {
  const browser = await chromium.launch();
  const ctx = await browser.newContext({ viewport: { width: 390, height: 800 }, deviceScaleFactor: 2, hasTouch: true });
  const page = await ctx.newPage();
  page.on('console', m => { if (m.type() === 'error' && !/index\.json|engine\.json|ERR_FILE_NOT_FOUND|Failed to load resource|Fetch API cannot load/.test(m.text())) errors.push(m.text()); });
  page.on('pageerror', e => errors.push('PAGEERROR ' + e.message));
  const shot = n => page.screenshot({ path: `${SHOTS}/${n}.png` });
  const sq = async name => { const b = await page.locator('.bd').boundingBox(); const o = await page.evaluate(() => HCC._board.orient);
    const f = name.charCodeAt(0) - 97, r = 8 - +name[1]; const x = o === 'w' ? f : 7 - f, y = o === 'w' ? r : 7 - r; return [b.x + (x + .5) * b.width / 8, b.y + (y + .5) * b.height / 8]; };
  const tap = async name => { const [x, y] = await sq(name); await page.mouse.click(x, y); };
  const mv = async (a, b) => { await tap(a); await tap(b); };
  const say = () => page.locator('.say').innerText();
  const sayCls = () => page.locator('.say').getAttribute('class');
  const tab = async n => { await page.locator('.tabs button').nth(n).click(); await page.waitForTimeout(150); };

  await page.goto(URL); await page.waitForSelector('.hero');
  ok('home renders in Arabic RTL', await page.evaluate(() => document.documentElement.dir) === 'rtl');
  ok('content loaded', await page.evaluate(() => HCC.content.courses.length === 4 && HCC.content.puzzles.length > 17000), await page.evaluate(() => [HCC.content.courses.length, HCC.content.puzzles.length]));
  await shot('01-home');

  // ---- lessons: rook unit
  await tab(1); await shot('02-lessons');
  await page.locator('.card.tap').first().click(); await page.waitForSelector('.unit'); await shot('03-course');
  ok('14 basics units', await page.locator('.unit').count() === 14);
  await page.locator('.unit').first().click(); await page.waitForSelector('.bd'); await shot('04-lesson-start');
  await mv('a1', 'a6'); ok('annotated mistake shown', /bad/.test(await sayCls()), await sayCls());
  await page.getByRole('button', { name: 'حاول مرة أخرى' }).click();
  await mv('a1', 'b1'); ok('plain wrong move keeps position', (await page.evaluate(() => HCC._board.chess.fen())).startsWith('6k1/p2p4/8/8/8/8/8/R5K1 w'));
  await mv('a1', 'a7'); ok('correct move accepted', /good/.test(await sayCls()), await sayCls()); await shot('05-lesson-good');
  await page.getByRole('button', { name: 'التالي', exact: true }).click(); await page.waitForTimeout(400);
  ok('opponent replied Kf8', (await page.evaluate(() => HCC._board.chess.fen())).startsWith('5k2/R2p4/'));
  await page.getByRole('button', { name: 'تلميح' }).click(); ok('hint highlights a square', await page.locator('.bd-sq .hint').count() === 1);
  await mv('a7', 'd7'); await page.waitForSelector('.result'); await page.waitForTimeout(500); await shot('06-lesson-done');
  ok('progress saved with 1 star (mistakes+hint)', await page.evaluate(() => Object.values(HCC.store.data.progress)[0]) === 1, await page.evaluate(() => JSON.stringify(HCC.store.data.progress)));
  // next lesson button -> bishop, solve cleanly for 3 stars
  await page.getByRole('button', { name: 'الدرس التالي' }).click(); await page.waitForTimeout(200);
  await mv('c1', 'g5'); await page.getByRole('button', { name: 'التالي', exact: true }).click(); await page.waitForTimeout(400); await mv('g5', 'e7'); await page.waitForSelector('.result');
  ok('clean solve gives 3 stars', await page.evaluate(() => Object.values(HCC.store.data.progress).includes(3)));
  // promotion unit (index 5)
  await page.locator('.top .icon-btn').first().click(); await page.locator('.unit').nth(5).click(); await page.waitForSelector('.bd');
  await mv('e7', 'e8'); ok('promotion picker opens', await page.locator('.bd-promo button').count() === 4); await shot('07-promo');
  await page.locator('.bd-promo button').first().click(); await page.waitForSelector('.result'); ok('promoted to queen', (await page.evaluate(() => HCC._board.chess.fen())).startsWith('4Q3/'));
  // castling unit (index 11): king e1 -> g1
  await page.locator('.top .icon-btn').first().click(); await page.locator('.unit').nth(11).click(); await page.waitForSelector('.bd');
  await mv('e1', 'g1'); await page.waitForSelector('.result'); ok('castled', (await page.evaluate(() => HCC._board.chess.fen())).includes('R4RK1'));
  // en passant unit (index 12): hero white, black moves first
  await page.locator('.top .icon-btn').first().click(); await page.locator('.unit').nth(12).click(); await page.waitForSelector('.bd');
  await page.getByRole('button', { name: 'التالي', exact: true }).click(); await page.waitForTimeout(400); await mv('e5', 'd6'); await page.waitForSelector('.result');
  ok('en passant captured', (await page.evaluate(() => HCC._board.chess.fen())).startsWith('4k3/8/3P4/8/'));
  // stalemate unit (index 13): wrong Qg6 then right Qg7
  await page.locator('.top .icon-btn').first().click(); await page.locator('.unit').nth(13).click(); await page.waitForSelector('.bd');
  await mv('g5', 'g6'); ok('stalemate blunder explained', /خنق/.test(await say())); await page.getByRole('button', { name: 'حاول مرة أخرى' }).click(); await mv('g5', 'g7'); await page.waitForSelector('.result');
  // hero black lesson: Scholar's mate (course 2, unit 2) incl. losing variation
  await tab(1); await tab(1); await page.locator('.card.tap').nth(1).click(); await page.locator('.unit').nth(1).click(); await page.waitForSelector('.bd');
  ok('board flipped for black hero', await page.evaluate(() => HCC._board.orient) === 'b');
  await page.getByRole('button', { name: 'التالي', exact: true }).click(); await page.waitForTimeout(400); await mv('e7', 'e5'); await page.getByRole('button', { name: 'التالي', exact: true }).click(); await page.waitForTimeout(400);
  await mv('b8', 'c6'); await page.getByRole('button', { name: 'التالي', exact: true }).click(); await page.waitForTimeout(400);
  await mv('g8', 'f6'); await page.waitForTimeout(1400); ok('refutation Qxf7# played out', await page.evaluate(() => HCC._board.chess.isCheckmate())); await shot('08-refutation');
  await page.getByRole('button', { name: 'حاول مرة أخرى' }).click(); ok('rewound after refutation', await page.evaluate(() => HCC._board.chess.history().length) === 5);
  await mv('g7', 'g6'); await page.getByRole('button', { name: 'التالي', exact: true }).click(); await page.waitForTimeout(400); await mv('g8', 'f6'); await page.waitForSelector('.result');
  // competitive: smothered mate full line
  await tab(1); await tab(1); await page.locator('.seg button').nth(1).click(); await page.locator('.card.tap').first().click(); await page.locator('.unit').nth(4).click(); await page.waitForSelector('.bd');
  for (const [a, b] of [['g5', 'f7'], ['f7', 'h6'], ['b3', 'g8'], ['h6', 'f7']]) { await mv(a, b); await page.waitForTimeout(250); const c = page.getByRole('button', { name: 'التالي', exact: true }); if (await c.count()) { await c.click(); } await page.waitForTimeout(700); }
  await page.waitForSelector('.result'); ok('smothered mate lesson ends in mate', await page.evaluate(() => HCC._board.chess.isCheckmate()));

  // ---- puzzles
  await tab(2); await page.waitForSelector('.bd'); await shot('09-puzzle');
  const solve = async () => { for (let i = 0; i < 3; i++) { const st = await page.evaluate(() => { const b = HCC._board, f = b.chess.fen(); const p = HCC.content.puzzles.find(p => p.fen === f); return p ? { m: p.moves[0] } : null; });
      const cur = await page.evaluate(() => { const b = HCC._board; const all = HCC.content.puzzles; const start = b.chess.startFen; const p = all.find(p => p.fen === start); return { moves: p.moves, n: b.chess.history().length }; });
      if (cur.n >= cur.moves.length) break; const u = cur.moves[cur.n]; await mv(u.slice(0, 2), u.slice(2, 4)); await page.waitForTimeout(900); if (await page.evaluate(() => HCC._board.chess.isCheckmate())) break; } };
  const r0 = await page.evaluate(() => HCC.store.data.puzzle.rating);
  await solve(); ok('puzzle solved raises rating', await page.evaluate(() => HCC.store.data.puzzle.rating) > r0 && /good/.test(await sayCls()), await say()); await shot('10-puzzle-solved');
  await page.getByRole('button', { name: 'اللغز التالي' }).click(); await page.waitForTimeout(200);
  // wrong move -> refutation -> rewind
  const wrong = await page.evaluate(() => { const b = HCC._board, C = HCChess, c = b.chess; const p = HCC.content.puzzles.find(p => p.fen === c.startFen); for (const m of c.legalMoves()) { const u = C.uci(m); if (u === p.moves[0]) continue; c.make(m); const mate = c.isCheckmate(); c.undo(); if (!mate && !C.mPromo(m)) return u; } return null; });
  const r1 = await page.evaluate(() => HCC.store.data.puzzle.rating); const f1 = await page.evaluate(() => HCC._board.chess.fen());
  await mv(wrong.slice(0, 2), wrong.slice(2, 4)); await page.waitForTimeout(900); ok('wrong puzzle move explained', /bad/.test(await sayCls()), await say()); await shot('11-puzzle-wrong');
  await page.waitForTimeout(2200); ok('position restored after refutation', await page.evaluate(() => HCC._board.chess.fen()) === f1);
  ok('rating dropped once', await page.evaluate(() => HCC.store.data.puzzle.rating) < r1);
  await page.getByRole('button', { name: 'الحل', exact: true }).click(); await page.waitForTimeout(8000); ok('solution played to the end', await page.evaluate(() => { const c = HCC._board.chess, p = HCC.content.puzzles.find(p => p.fen === c.startFen); return c.history().length === p.moves.length; }));
  await page.locator('#pz-theme').selectOption('fork'); await page.waitForTimeout(300);
  ok('theme filter: fork', await page.evaluate(() => HCC.content.puzzles.find(p => p.fen === HCC._board.chess.startFen).themes.includes('fork')));
  await page.locator('#pz-level').selectOption('5'); await page.waitForTimeout(300);
  ok('level filter: 2000-2299', await page.evaluate(() => { const p = HCC.content.puzzles.find(p => p.fen === HCC._board.chess.startFen); return p.rating >= 2000 && p.rating < 2300 && p.themes.includes('fork'); }));
  ok('level options have counts', /\(\d+\)/.test(await page.locator('#pz-level option').nth(1).innerText()));
  await shot('19-puzzle-filters');
  await page.locator('#pz-theme').selectOption('mateIn2'); await page.locator('#pz-level').selectOption('auto'); await page.waitForTimeout(300);
  ok('mate-in-2 filter', await page.evaluate(() => HCC.content.puzzles.find(p => p.fen === HCC._board.chess.startFen).themes.includes('mateIn2')));

  // ---- play
  await tab(3); await page.waitForSelector('#play-level'); await shot('12-play-setup');
  await page.locator('#play-level').fill('1'); await page.getByRole('button', { name: 'ابدأ', exact: true }).click(); await page.waitForSelector('.bd');
  await mv('e2', 'e4'); await page.waitForTimeout(1500); ok('computer replied', await page.evaluate(() => HCC.store.data.play.moves.length) === 2, await page.evaluate(() => JSON.stringify(HCC.store.data.play)));
  await mv('d2', 'd4'); await page.waitForTimeout(1500); await shot('13-play');
  await page.getByRole('button', { name: 'تراجع' }).click(); await page.waitForTimeout(200); ok('takeback removes two plies', await page.evaluate(() => HCC.store.data.play.moves.length) === 2);
  await page.reload(); await page.waitForSelector('.bd'); ok('game restored after reload (hash route + storage)', await page.evaluate(() => HCC._board.chess.history().length) === 2);
  // drag a piece with the mouse
  { const [x1, y1] = await sq('g1'), [x2, y2] = await sq('f3'); await page.mouse.move(x1, y1); await page.mouse.down(); await page.mouse.move((x1 + x2) / 2, (y1 + y2) / 2, { steps: 4 }); await page.mouse.move(x2, y2, { steps: 4 }); await page.mouse.up(); await page.waitForTimeout(1500);
    ok('drag move works', (await page.evaluate(() => HCC.store.data.play.moves[2])) === 'g1f3'); }
  await page.getByRole('button', { name: 'انسحاب' }).click(); await page.waitForSelector('.result'); await shot('14-play-over');
  await page.getByRole('button', { name: 'حلّل المباراة' }).click(); await page.waitForSelector('.evalbar'); await page.waitForTimeout(2500);
  ok('analysis opened with the game', await page.locator('.moves .m').count() >= 4); ok('engine line shown', await page.locator('.lines .ln').count() >= 1, await page.locator('.card .status').innerText()); await shot('15-analysis');
  await page.locator('.navrow .btn').nth(0).click(); await page.waitForTimeout(200); ok('jump to start', await page.evaluate(() => HCC._board.chess.fen()) === HCChessStart());
  function HCChessStart() { return 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1'; }
  await page.getByRole('button', { name: 'إدخال وضع' }).click(); await page.locator('#setup-text').fill('6k1/5ppp/8/8/8/8/8/R5K1 w - - 0 1'); await page.getByRole('button', { name: 'تحميل' }).click(); await page.waitForTimeout(1500);
  ok('FEN loaded and mate found', /#1/.test(await page.locator('.lines').innerText()), await page.locator('.lines').innerText());
  await page.getByRole('button', { name: 'إدخال وضع' }).click(); await page.locator('#setup-text').fill('1. e4 e5 2. Nf3 Nc6 3. Bb5 a6 {comment} 4. Ba4 Nf6 *'); await page.getByRole('button', { name: 'تحميل' }).click(); await page.waitForTimeout(300);
  ok('PGN loaded', await page.locator('.moves .m').count() === 8);
  await page.getByRole('button', { name: 'إدخال وضع' }).click(); await page.locator('#setup-text').fill('not chess'); await page.getByRole('button', { name: 'تحميل' }).click(); ok('bad input reported', await page.locator('.sheet .note.bad').count() === 1); await page.getByRole('button', { name: 'إلغاء' }).click();

  // ---- settings: import, language
  await page.locator('.top .icon-btn').last().click(); await page.waitForSelector('.sheet'); await shot('16-settings');
  fs.writeFileSync('/tmp/shots/coach.pgn', '[Course "كورس المدرب || Coach Course"]\n[Title "درس تجريبي || Sample"]\n[FEN "6k1/5ppp/8/8/8/8/8/R5K1 w - - 0 1"]\n\n{ جد المات || Find the mate }\n1. Ra8# { تمام || Done } *\n');
  await page.locator('#import-kind').selectOption('lessons-comp'); await page.locator('#import-file').setInputFiles('/tmp/shots/coach.pgn'); await page.waitForTimeout(400);
  ok('PGN lesson imported', await page.evaluate(() => HCC.content.courses.length) === 5 && await page.locator('.sheet .note.good').count() === 1);
  fs.writeFileSync('/tmp/shots/li.csv', 'PuzzleId,FEN,Moves,Rating,RatingDeviation,Popularity,NbPlays,Themes,GameUrl,OpeningTags\n00sHx,q3k1nr/1pp1nQpp/3p4/1P2p3/4P3/B1PP1b2/B5PP/5K2 b k - 0 17,e8d7 a2e6 d7d8 f7f8,1760,80,83,72,mate mateIn2 middlegame short,https://lichess.org/yyznGmXs/black#34,Italian_Game\nbad,8/8/8/8/8/8/8/8 w - - 0 1,e2e4 e7e5,1000,1,1,1,x,u,\n');
  await page.locator('#import-kind').selectOption('puzzles-csv'); await page.locator('#import-file').setInputFiles('/tmp/shots/li.csv'); await page.waitForTimeout(400);
  ok('Lichess CSV imported (1 good, 1 skipped)', await page.evaluate(() => HCC.content.puzzles.length) > 17000 && await page.evaluate(() => { const p = HCC.content.puzzles.find(p => p.id === 'L00sHx'); return p && p.moves.join(' ') === 'a2e6 d7d8 f7f8' && p.last === 'e8d7'; }));
  await page.reload(); await page.waitForSelector('.top'); await page.waitForTimeout(300); ok('imports survive reload', await page.evaluate(() => HCC.content.courses.length === 5 && HCC.content.puzzles.length > 17000));
  await page.locator('.lang-btn').click(); await page.waitForTimeout(200); ok('English is LTR', await page.evaluate(() => document.documentElement.dir) === 'ltr');
  await tab(0); await shot('17-home-en'); await tab(1); await page.locator('.card.tap').first().click(); await page.locator('.unit').first().click(); await page.waitForSelector('.bd'); await shot('18-lesson-en');
  ok('lesson text in English', /rook moves in straight lines/i.test(await say()), await say());
  ok('Android back handler', await page.evaluate(() => HCC.back()) === true && await page.locator('.unit').count() > 0);
  ok('no console errors', errors.length === 0, errors.slice(0, 5).join(' | '));
  await browser.close();
  console.log(fail ? fail + ' FAILED' : 'UI ALL PASSED');
})().catch(e => { console.error('TEST CRASH', e); process.exit(1); });
