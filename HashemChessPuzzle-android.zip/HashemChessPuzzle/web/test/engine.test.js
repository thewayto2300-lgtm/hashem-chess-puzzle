const { Chess } = require('../src/chess.js');
const { Engine, LEVELS } = require('../src/engine.js');
let fail = 0;
function eq(name, got, want) { if (got !== want) { fail++; console.log('FAIL', name, 'got', got, 'want', want); } else console.log('ok  ', name, got); }
const e = new Engine();
function best(fen, opts) { e.setPosition(fen); const t = Date.now(); const r = e.think(opts); r.ms = Date.now() - t; return r; }
let r;
r = best('6k1/5ppp/8/8/8/8/8/R5K1 w - - 0 1', { depth: 4 }); eq('back rank mate', r.move + ' m' + r.mate, 'a1a8 m1');
r = best('r1bqkb1r/pppp1ppp/2n2n2/4p2Q/2B1P3/8/PPPP1PPP/RNB1K1NR w KQkq - 4 4', { depth: 4 }); eq('scholar mate', r.move + ' m' + r.mate, 'h5f7 m1');
r = best('2r3k1/5ppp/8/8/8/8/5PPP/1R1R2K1 w - - 0 1', { depth: 5 }); console.log('    info', JSON.stringify(r));
r = best('7k/8/5K2/6Q1/8/8/8/8 w - - 0 1', { depth: 6 }); eq('KQ mate found', r.mate > 0, true);
r = best('8/8/8/8/8/2k5/1q6/K7 w - - 0 1', { depth: 3 }); console.log('    lost pos', JSON.stringify(r));
r = best('r1bqkbnr/pppp1ppp/2n5/4p3/4P3/5N2/PPPP1PPP/RNBQKB1R w KQkq - 2 3', { movetime: 800, depth: 7 }); console.log('    L5 from opening', r.move, 'd' + r.depth, r.ms + 'ms', r.nodes, 'nodes', r.pv.join(' '));
r = best('r1bqkbnr/pppp1ppp/2n5/4p3/4P3/5N2/PPPP1PPP/RNBQKB1R w KQkq - 2 3', { movetime: 2500, depth: 14 }); console.log('    L6 from opening', r.move, 'd' + r.depth, r.ms + 'ms', r.nodes, 'nodes');
// knight fork wins the queen
r = best('4k3/8/3q4/8/4N3/8/8/4K3 w - - 0 1', { depth: 4 }); eq('takes hanging queen', r.move, 'e4d6');
r = best('r3k3/8/8/1N6/8/8/8/4K3 w - - 0 1', { depth: 5 }); eq('knight fork', r.move, 'b5c7');
// stalemate avoidance: KQ vs K, must not stalemate
r = best('7k/5Q2/5K2/8/8/8/8/8 w - - 0 1', { depth: 4 }); eq('mate not stalemate', r.mate, 1);
// weak levels return legal moves quickly, many times
for (let lvl = 1; lvl <= 4; lvl++) { const c = new Chess(); let ms = 0, n = 0, ok = true;
  for (let i = 0; i < 40; i++) { e.setPosition(c.fen()); const t = Date.now(); const rr = e.think(Object.assign({}, LEVELS[lvl])); ms += Date.now() - t; n++; if (!rr.move) break; if (!c.play(rr.move)) { ok = false; break; } }
  eq('level ' + lvl + ' plays legal moves (avg ' + Math.round(ms / n) + 'ms)', ok, true); }
// self play L5 vs L2 — the stronger side should not lose
{ const c = new Chess(); let res = '';
  for (let i = 0; i < 160; i++) { res = c.gameOver(); if (res) break; e.setPosition(c.startFen, c.history().map(require('../src/chess.js').uci)); const rr = e.think(c.turn === 0 ? { depth: 5, movetime: 150 } : Object.assign({}, LEVELS[2])); c.play(rr.move); }
  console.log('    selfplay strong(W) vs L2(B):', res || 'unfinished', 'turn', c.turn === 0 ? 'w' : 'b', c.fen()); eq('strong side wins or is winning', res === 'checkmate' ? c.turn === 8 : true, true); }
console.log(fail ? fail + ' FAILED' : 'ALL PASSED');
