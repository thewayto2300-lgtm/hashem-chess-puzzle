const { Chess, parsePgn, uci } = require('../src/chess.js');
let fail = 0;
function eq(name, got, want) { if (got !== want) { fail++; console.log('FAIL', name, 'got', got, 'want', want); } else console.log('ok  ', name, got); }
const perfts = [
  ['start', 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1', 4, 197281],
  ['kiwipete', 'r3k2r/p1ppqpb1/bn2pnp1/3PN3/1p2P3/2N2Q1p/PPPBBPPP/R3K2R w KQkq - 0 1', 3, 97862],
  ['pos3', '8/2p5/3p4/KP5r/1R3p1k/8/4P1P1/8 w - - 0 1', 5, 674624],
  ['pos4', 'r3k2r/Pppp1ppp/1b3nbN/nP6/BBP1P3/q4N2/Pp1P2PP/R2Q1RK1 w kq - 0 1', 4, 422333],
  ['pos5', 'rnbq1k1r/pp1Pbppp/2p5/8/2B5/8/PPP1NnPP/RNBQK2R w KQ - 1 8', 4, 2103487],
  ['pos6', 'r4rk1/1pp1qppp/p1np1n2/2b1p1B1/2B1P1b1/P1NP1N2/1PP1QPPP/R4RK1 w - - 0 10', 3, 89890],
];
let t0 = Date.now(), nodes = 0;
for (const [n, fen, d, want] of perfts) { const c = new Chess(fen); const before = c.fen(), lo = c.lo, hi = c.hi; const got = c.perft(d); nodes += got; eq('perft ' + n + ' d' + d, got, want); eq('  state restored', c.fen() === before && c.lo === lo && c.hi === hi, true); }
console.log('nps', Math.round(nodes / ((Date.now() - t0) / 1000)));
// hash consistency: incremental == recomputed after random play
{ const c = new Chess(); let ok = true; let s = 12345; const r = () => (s = (s * 1103515245 + 12345) & 0x7fffffff) / 0x7fffffff;
  for (let g = 0; g < 200 && ok; g++) { c.load('rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1');
    for (let i = 0; i < 120; i++) { const l = c.legalMoves(); if (!l.length) break; const m = l[Math.floor(r() * l.length)];
      const san = c.san(m); const back = c.parseMove(san); if (back !== m) { ok = false; console.log('SAN roundtrip fail', san, uci(m), back && uci(back), c.fen()); break; }
      if (c.parseMove(uci(m)) !== m) { ok = false; console.log('UCI roundtrip fail', uci(m)); break; }
      c.make(m); const lo = c.lo, hi = c.hi; c.computeHash(); if (lo !== c.lo || hi !== c.hi) { ok = false; console.log('hash drift after', san); break; }
      const f = c.fen(); const c2 = new Chess(f); if (c2.fen() !== f || c2.lo !== c.lo || c2.hi !== c.hi) { ok = false; console.log('fen roundtrip', f, c2.fen()); break; } } }
  eq('san/uci/hash/fen roundtrip over random games', ok, true); }
// SAN specifics
{ const c = new Chess('r3k2r/8/8/8/8/8/8/R3K2R w KQkq - 0 1'); eq('castle san', c.san(c.parseMove('O-O')), 'O-O'); eq('castle zeros', c.san(c.parseMove('0-0-0')), 'O-O-O'); eq('castle coord', c.san(c.parseMove('e1g1')), 'O-O'); }
{ const c = new Chess('R6R/8/8/8/8/8/6k1/4K3 w - - 0 1'); eq('disambig file', c.san(c.parseMove('a8d8')), 'Rad8'); eq('disambig parse', uci(c.parseMove('Rhd8')), 'h8d8'); }
{ const c = new Chess('R7/8/8/8/8/8/8/R3K2k w - - 0 1'); eq('disambig rank', c.san(c.parseMove('a1a4')), 'R1a4'); }
{ const c = new Chess('7k/P7/8/8/8/8/8/K7 w - - 0 1'); eq('promo default queen', c.san(c.parseMove('a7a8')), 'a8=Q+'); eq('promo N', c.san(c.parseMove('a8=N')), 'a8=N'); eq('promo no =', c.san(c.parseMove('a8R')), 'a8=R+'); }
{ const c = new Chess(); for (const m of 'e4 e5 Qh5 Nc6 Bc4 Nf6'.split(' ')) c.play(m); eq('scholar mate', c.san(c.parseMove('Qxf7')), 'Qxf7#'); c.play('Qxf7#'); eq('gameOver', c.gameOver(), 'checkmate'); }
{ const c = new Chess('7k/5Q2/6K1/8/8/8/8/8 b - - 0 1'); eq('stalemate', c.gameOver(), 'stalemate'); }
{ const c = new Chess('8/8/8/4k3/8/8/8/4K2N w - - 0 1'); eq('insufficient', c.gameOver(), 'material'); }
{ const c = new Chess(); for (const m of 'Nf3 Nf6 Ng1 Ng8 Nf3 Nf6 Ng1 Ng8'.split(' ')) c.play(m); eq('threefold', c.gameOver(), 'repetition'); }
{ const c = new Chess(); for (const m of 'e4 a6 e5 d5'.split(' ')) c.play(m); eq('ep fen', c.fen().split(' ')[3], 'd6'); eq('ep san', c.san(c.parseMove('exd6')), 'exd6'); c.play('exd6'); eq('ep removes pawn', c.fen().split(' ')[0], 'rnbqkbnr/1pp1pppp/p2P4/8/8/8/PPPP1PPP/RNBQKBNR'); c.undo(); eq('ep undo', c.fen().split(' ')[0], 'rnbqkbnr/1pp1pppp/p7/3pP3/8/8/PPPP1PPP/RNBQKBNR'); }
{ const c = new Chess(); c.play('e4'); eq('no ep when not capturable', c.fen().split(' ')[3], '-'); }
// PGN
{ const pgn = `[Event "Test"]\n[Title "Legal || Legal mate"]\n\n{ intro text [%cal Ge2e4,Rd1h5] [%csl Gf7] } 1. e4 e5 2. Nf3 d6 3. Bc4 Bg4?! { pin } (3... Nc6 4. Nc3 { fine } (4. d3 Be7)) 4. Nc3 g6? 5. Nxe5! Bxd1?? $4 (5... dxe5 6. Qxg4 { white is a pawn up }) 6. Bxf7+ Ke7 7. Nd5# 1-0\n\n[Event "Second"]\n[FEN "6k1/5ppp/8/8/8/8/8/R5K1 w - - 0 1"]\n[SetUp "1"]\n\n1. Ra8# *\n\n[Event "Broken"]\n\n1. e4 e5 2. Ke3 Nc6 (2... d5 3. Qh5) 3. d4 *`;
  const g = parsePgn(pgn);
  eq('pgn games', g.length, 3);
  eq('pgn moves', g[0].line.map(n => n.san).join(' '), 'e4 e5 Nf3 d6 Bc4 Bg4 Nc3 g6 Nxe5 Bxd1 Bxf7+ Ke7 Nd5#');
  eq('pgn intro', g[0].intro, 'intro text'); eq('pgn arrows', g[0].introArrows.length + ':' + g[0].introMarks.length, '2:1');
  eq('pgn nag', g[0].line[5].nag + ',' + g[0].line[7].nag + ',' + g[0].line[8].nag + ',' + g[0].line[9].nag, '6,2,1,4');
  eq('pgn var', g[0].line[5].vars[0].map(n => n.san).join(' '), 'Nc6 Nc3'); eq('pgn nested var', g[0].line[5].vars[0][1].vars[0].map(n => n.san).join(' '), 'd3 Be7');
  eq('pgn var comment', g[0].line[9].vars[0][1].comment, 'white is a pawn up'); eq('pgn errors', g[0].errors.length, 0);
  eq('pgn fen game', g[1].line[0].san, 'Ra8#'); eq('pgn result', g[0].result + ' ' + g[1].result, '1-0 *');
  eq('pgn broken keeps prefix', g[2].line.map(n => n.san).join(' '), 'e4 e5'); eq('pgn broken error', g[2].errors.length, 1); }
console.log(fail ? fail + ' FAILED' : 'ALL PASSED');
