/* Plays every lesson to the end through the real UI, following the lesson line, and checks each one finishes. */
const { chromium } = require('playwright'); const path = require('path');
(async () => { const b = await chromium.launch(); const page = await b.newPage({ viewport: { width: 390, height: 800 } }); const errs = [];
  page.on('pageerror', e => errs.push(e.message));
  await page.goto('file://' + path.join(__dirname, '../dist/index.html') + '#lessons'); await page.waitForSelector('.seg');
  const sq = async name => { const bb = await page.locator('.bd').boundingBox(); const o = await page.evaluate(() => HCC._board.orient); const f = name.charCodeAt(0) - 97, r = 8 - +name[1]; const x = o === 'w' ? f : 7 - f, y = o === 'w' ? r : 7 - r; return [bb.x + (x + .5) * bb.width / 8, bb.y + (y + .5) * bb.height / 8]; };
  const courses = await page.evaluate(() => HCC.content.courses.map(c => ({ track: c.track, n: c.units.length, units: c.units.map(u => ({ title: u.title, line: u.line.map(x => x.uci) })) })));
  let done = 0, bad = 0;
  for (const track of ['educational', 'competitive']) { const list = courses.filter(c => c.track === track);
    for (let ci = 0; ci < list.length; ci++) for (let ui = 0; ui < list[ci].n; ui++) {
      await page.locator('.tabs button').nth(1).click(); await page.locator('.tabs button').nth(1).click();
      await page.locator('.seg button').nth(track === 'educational' ? 0 : 1).click(); await page.locator('.card.tap').nth(ci).click(); await page.locator('.unit').nth(ui).click(); await page.waitForSelector('.bd');
      const line = list[ci].units[ui].line; let finished = false;
      for (let guard = 0; guard < 80 && !finished; guard++) {
        if (await page.locator('.result').count()) { finished = true; break; }
        const cont = page.getByRole('button', { name: 'التالي', exact: true });
        if (await cont.count()) { await cont.click(); await page.waitForTimeout(260); continue; }
        const st = await page.evaluate(() => ({ n: HCC._board.chess.history().length, movable: HCC._board.movable }));
        if (!st.movable) { await page.waitForTimeout(200); continue; }
        const u = line[st.n]; for (const s of [u.slice(0, 2), u.slice(2, 4)]) { const [x, y] = await sq(s); await page.mouse.click(x, y); }
        if (u.length === 5) await page.locator('.bd-promo button').nth('qrbn'.indexOf(u[4])).click();
        await page.waitForTimeout(260);
      }
      if (finished) done++; else { bad++; console.log('STUCK', track, list[ci].units[ui].title); }
    } }
  const stars = await page.evaluate(() => Object.values(HCC.store.data.progress));
  console.log('lessons finished', done, 'stuck', bad, '| three-star results', stars.filter(s => s === 3).length, 'of', stars.length, '| page errors', errs.length, errs.slice(0, 3).join(' | '));
  await b.close(); process.exit(bad || errs.length || done !== 29 ? 1 : 0); })().catch(e => { console.error('CRASH', e); process.exit(1); });
