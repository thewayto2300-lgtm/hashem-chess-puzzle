/*
 * Hashem Chess Puzzle — chess rules core.
 * Original implementation (0x88 board). Runs in a page, a Web Worker and Node.
 * Squares: index = row * 16 + file, row 0 = rank 8, so a8 = 0, h8 = 7, a1 = 112, h1 = 119.
 * Pieces: white 1..6 (P N B R Q K), black = white + 8. Colour = piece & 8.
 * Moves are packed ints: from | to << 7 | promo << 14 | flags << 17.
 */
(function (root) {
  'use strict';

  var PAWN = 1, KNIGHT = 2, BISHOP = 3, ROOK = 4, QUEEN = 5, KING = 6;
  var WHITE = 0, BLACK = 8;
  var F_CAPTURE = 1, F_DOUBLE = 2, F_EP = 4, F_KCASTLE = 8, F_QCASTLE = 16, F_PROMO = 32;
  var START_FEN = 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1';

  var KNIGHT_OFF = [-33, -31, -18, -14, 14, 18, 31, 33];
  var KING_OFF = [-17, -16, -15, -1, 1, 15, 16, 17];
  var BISHOP_OFF = [-17, -15, 15, 17];
  var ROOK_OFF = [-16, -1, 1, 16];
  var LETTERS = ' PNBRQK';
  var FEN_CHARS = { P: 1, N: 2, B: 3, R: 4, Q: 5, K: 6, p: 9, n: 10, b: 11, r: 12, q: 13, k: 14 };
  var FEN_OUT = '.PNBRQK..pnbrqk';

  // Castling rights: 1 = white king side, 2 = white queen side, 4 = black king side, 8 = black queen side.
  var CASTLE_MASK = new Int8Array(128);
  for (var i = 0; i < 128; i++) CASTLE_MASK[i] = 15;
  CASTLE_MASK[112] = 15 & ~2; CASTLE_MASK[119] = 15 & ~1; CASTLE_MASK[116] = 15 & ~3;
  CASTLE_MASK[0] = 15 & ~8; CASTLE_MASK[7] = 15 & ~4; CASTLE_MASK[4] = 15 & ~12;

  // Zobrist keys from a fixed-seed generator, so hashes are stable between runs.
  var seed = 0x9e3779b9;
  function rnd() {
    seed = (seed + 0x6d2b79f5) | 0;
    var t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return (t ^ (t >>> 14)) | 0;
  }
  var Z_LO = new Int32Array(15 * 128), Z_HI = new Int32Array(15 * 128);
  for (i = 0; i < 15 * 128; i++) { Z_LO[i] = rnd(); Z_HI[i] = rnd(); }
  var ZC_LO = new Int32Array(16), ZC_HI = new Int32Array(16);
  for (i = 0; i < 16; i++) { ZC_LO[i] = rnd(); ZC_HI[i] = rnd(); }
  var ZE_LO = new Int32Array(8), ZE_HI = new Int32Array(8);
  for (i = 0; i < 8; i++) { ZE_LO[i] = rnd(); ZE_HI[i] = rnd(); }
  var ZS_LO = rnd(), ZS_HI = rnd();

  function mv(from, to, promo, flags) { return from | (to << 7) | (promo << 14) | (flags << 17); }
  function mFrom(m) { return m & 127; }
  function mTo(m) { return (m >> 7) & 127; }
  function mPromo(m) { return (m >> 14) & 7; }
  function mFlags(m) { return m >> 17; }

  function sqName(sq) { return 'abcdefgh'.charAt(sq & 7) + (8 - (sq >> 4)); }
  function sqIndex(name) {
    if (!/^[a-h][1-8]$/.test(name)) return -1;
    return (8 - parseInt(name.charAt(1), 10)) * 16 + (name.charCodeAt(0) - 97);
  }
  function uci(m) {
    var p = mPromo(m);
    return sqName(mFrom(m)) + sqName(mTo(m)) + (p ? ' pnbrq'.charAt(p) : '');
  }

  function Chess(fen) {
    this.board = new Int8Array(128);
    this.kingSq = [-1, -1];
    this.turn = WHITE; this.castling = 0; this.ep = -1; this.half = 0; this.full = 1;
    this.lo = 0; this.hi = 0;
    this.uMove = []; this.uCap = []; this.uCastle = []; this.uEp = []; this.uHalf = []; this.uLo = []; this.uHi = [];
    this.startFen = START_FEN;
    var err = this.load(fen || START_FEN);
    if (err) throw new Error(err);
  }

  /** Loads a FEN. Returns '' on success or a message describing what is wrong with it. */
  Chess.prototype.load = function (fen) {
    var parts = String(fen).trim().split(/\s+/);
    if (parts.length < 1 || !parts[0]) return 'empty FEN';
    var rows = parts[0].split('/');
    if (rows.length !== 8) return 'FEN needs 8 ranks';
    var b = new Int8Array(128), kings = [-1, -1], kingCount = [0, 0];
    for (var r = 0; r < 8; r++) {
      var f = 0;
      for (var k = 0; k < rows[r].length; k++) {
        var ch = rows[r].charAt(k);
        if (ch >= '1' && ch <= '8') { f += parseInt(ch, 10); continue; }
        var p = FEN_CHARS[ch];
        if (!p || f > 7) return 'bad FEN rank ' + (8 - r);
        b[r * 16 + f] = p;
        if ((p & 7) === KING) { kings[p >> 3] = r * 16 + f; kingCount[p >> 3]++; }
        f++;
      }
      if (f !== 8) return 'bad FEN rank ' + (8 - r);
    }
    if (kingCount[0] > 1 || kingCount[1] > 1) return 'more than one king';
    var turn = parts[1] === 'b' ? BLACK : WHITE;
    var cs = parts[2] || '-', castling = 0;
    if (cs.indexOf('K') >= 0 && b[116] === 6 && b[119] === 4) castling |= 1;
    if (cs.indexOf('Q') >= 0 && b[116] === 6 && b[112] === 4) castling |= 2;
    if (cs.indexOf('k') >= 0 && b[4] === 14 && b[7] === 12) castling |= 4;
    if (cs.indexOf('q') >= 0 && b[4] === 14 && b[0] === 12) castling |= 8;
    var ep = parts[3] && parts[3] !== '-' ? sqIndex(parts[3]) : -1;
    this.board = b; this.kingSq = kings; this.turn = turn; this.castling = castling;
    this.half = parseInt(parts[4], 10) || 0; this.full = parseInt(parts[5], 10) || 1;
    this.ep = -1;
    if (ep >= 0 && this.epCapturable(ep, turn)) this.ep = ep;
    this.uMove = []; this.uCap = []; this.uCastle = []; this.uEp = []; this.uHalf = []; this.uLo = []; this.uHi = [];
    this.computeHash();
    // The side that just moved must not be left in check.
    if (this.kingSq[(turn ^ 8) >> 3] >= 0 && this.attacked(this.kingSq[(turn ^ 8) >> 3], turn)) return 'side not to move is in check';
    this.startFen = this.fen();
    return '';
  };

  /** True when a pawn of `side` stands next to the en-passant square and could take there. */
  Chess.prototype.epCapturable = function (ep, side) {
    var b = this.board, from = side === WHITE ? ep + 16 : ep - 16, pawn = side | PAWN;
    var behind = side === WHITE ? ep + 16 : ep - 16;
    if (b[ep] || b[behind] !== ((side ^ 8) | PAWN)) return false;
    return (!((from - 1) & 0x88) && b[from - 1] === pawn) || (!((from + 1) & 0x88) && b[from + 1] === pawn);
  };

  Chess.prototype.computeHash = function () {
    var lo = 0, hi = 0, b = this.board;
    for (var sq = 0; sq < 120; sq++) {
      if (sq & 0x88) { sq += 7; continue; }
      if (b[sq]) { lo ^= Z_LO[b[sq] * 128 + sq]; hi ^= Z_HI[b[sq] * 128 + sq]; }
    }
    lo ^= ZC_LO[this.castling]; hi ^= ZC_HI[this.castling];
    if (this.ep >= 0) { lo ^= ZE_LO[this.ep & 7]; hi ^= ZE_HI[this.ep & 7]; }
    if (this.turn === BLACK) { lo ^= ZS_LO; hi ^= ZS_HI; }
    this.lo = lo; this.hi = hi;
  };

  Chess.prototype.fen = function () {
    var b = this.board, out = '';
    for (var r = 0; r < 8; r++) {
      var empty = 0;
      for (var f = 0; f < 8; f++) {
        var p = b[r * 16 + f];
        if (!p) { empty++; continue; }
        if (empty) { out += empty; empty = 0; }
        out += FEN_OUT.charAt(p);
      }
      if (empty) out += empty;
      if (r < 7) out += '/';
    }
    var c = '';
    if (this.castling & 1) c += 'K';
    if (this.castling & 2) c += 'Q';
    if (this.castling & 4) c += 'k';
    if (this.castling & 8) c += 'q';
    return out + (this.turn === WHITE ? ' w ' : ' b ') + (c || '-') + ' ' +
      (this.ep >= 0 ? sqName(this.ep) : '-') + ' ' + this.half + ' ' + this.full;
  };

  Chess.prototype.pieceAt = function (sq) { return this.board[sq]; };

  /** Is `sq` attacked by a piece of colour `by`? */
  Chess.prototype.attacked = function (sq, by) {
    var b = this.board, i, t, p, off;
    if (by === WHITE) {
      t = sq + 15; if (!(t & 0x88) && b[t] === 1) return true;
      t = sq + 17; if (!(t & 0x88) && b[t] === 1) return true;
    } else {
      t = sq - 15; if (!(t & 0x88) && b[t] === 9) return true;
      t = sq - 17; if (!(t & 0x88) && b[t] === 9) return true;
    }
    var knight = by | KNIGHT, king = by | KING, bishop = by | BISHOP, rook = by | ROOK, queen = by | QUEEN;
    for (i = 0; i < 8; i++) {
      t = sq + KNIGHT_OFF[i]; if (!(t & 0x88) && b[t] === knight) return true;
      t = sq + KING_OFF[i]; if (!(t & 0x88) && b[t] === king) return true;
    }
    for (i = 0; i < 4; i++) {
      off = BISHOP_OFF[i]; t = sq + off;
      while (!(t & 0x88)) { p = b[t]; if (p) { if (p === bishop || p === queen) return true; break; } t += off; }
      off = ROOK_OFF[i]; t = sq + off;
      while (!(t & 0x88)) { p = b[t]; if (p) { if (p === rook || p === queen) return true; break; } t += off; }
    }
    return false;
  };

  Chess.prototype.inCheck = function (color) {
    if (color === undefined) color = this.turn;
    var k = this.kingSq[color >> 3];
    return k >= 0 && this.attacked(k, color ^ 8);
  };

  /** Pseudo-legal moves. With capturesOnly, only captures and promotions (for quiescence search). */
  Chess.prototype.genPseudo = function (capturesOnly) {
    var moves = [], b = this.board, us = this.turn, them = us ^ 8, sq, to, tp, i, off, p, t;
    for (sq = 0; sq < 120; sq++) {
      if (sq & 0x88) { sq += 7; continue; }
      p = b[sq];
      if (!p || (p & 8) !== us) continue;
      t = p & 7;
      if (t === PAWN) {
        var dir = us === WHITE ? -16 : 16, startRow = us === WHITE ? 6 : 1, promoRow = us === WHITE ? 0 : 7;
        to = sq + dir;
        if (!(to & 0x88) && !b[to]) {
          if ((to >> 4) === promoRow) {
            moves.push(mv(sq, to, QUEEN, F_PROMO), mv(sq, to, KNIGHT, F_PROMO), mv(sq, to, ROOK, F_PROMO), mv(sq, to, BISHOP, F_PROMO));
          } else if (!capturesOnly) {
            moves.push(mv(sq, to, 0, 0));
            if ((sq >> 4) === startRow && !b[to + dir]) moves.push(mv(sq, to + dir, 0, F_DOUBLE));
          }
        }
        for (i = -1; i <= 1; i += 2) {
          to = sq + dir + i;
          if (to & 0x88) continue;
          tp = b[to];
          if (tp) {
            if ((tp & 8) !== them) continue;
            if ((to >> 4) === promoRow) {
              moves.push(mv(sq, to, QUEEN, F_PROMO | F_CAPTURE), mv(sq, to, KNIGHT, F_PROMO | F_CAPTURE),
                mv(sq, to, ROOK, F_PROMO | F_CAPTURE), mv(sq, to, BISHOP, F_PROMO | F_CAPTURE));
            } else moves.push(mv(sq, to, 0, F_CAPTURE));
          } else if (to === this.ep) moves.push(mv(sq, to, 0, F_CAPTURE | F_EP));
        }
      } else if (t === KNIGHT || t === KING) {
        var offs = t === KNIGHT ? KNIGHT_OFF : KING_OFF;
        for (i = 0; i < 8; i++) {
          to = sq + offs[i];
          if (to & 0x88) continue;
          tp = b[to];
          if (!tp) { if (!capturesOnly) moves.push(mv(sq, to, 0, 0)); }
          else if ((tp & 8) === them) moves.push(mv(sq, to, 0, F_CAPTURE));
        }
        if (t === KING && !capturesOnly) {
          if (us === WHITE && sq === 116) {
            if ((this.castling & 1) && !b[117] && !b[118] && b[119] === 4 &&
              !this.attacked(116, them) && !this.attacked(117, them) && !this.attacked(118, them)) moves.push(mv(116, 118, 0, F_KCASTLE));
            if ((this.castling & 2) && !b[115] && !b[114] && !b[113] && b[112] === 4 &&
              !this.attacked(116, them) && !this.attacked(115, them) && !this.attacked(114, them)) moves.push(mv(116, 114, 0, F_QCASTLE));
          } else if (us === BLACK && sq === 4) {
            if ((this.castling & 4) && !b[5] && !b[6] && b[7] === 12 &&
              !this.attacked(4, them) && !this.attacked(5, them) && !this.attacked(6, them)) moves.push(mv(4, 6, 0, F_KCASTLE));
            if ((this.castling & 8) && !b[3] && !b[2] && !b[1] && b[0] === 12 &&
              !this.attacked(4, them) && !this.attacked(3, them) && !this.attacked(2, them)) moves.push(mv(4, 2, 0, F_QCASTLE));
          }
        }
      } else {
        var s = t === BISHOP ? 0 : (t === ROOK ? 4 : 0), e = t === BISHOP ? 4 : 8;
        for (i = s; i < e; i++) {
          off = KING_OFF_SLIDE[i]; to = sq + off;
          while (!(to & 0x88)) {
            tp = b[to];
            if (!tp) { if (!capturesOnly) moves.push(mv(sq, to, 0, 0)); }
            else { if ((tp & 8) === them) moves.push(mv(sq, to, 0, F_CAPTURE)); break; }
            to += off;
          }
        }
      }
    }
    return moves;
  };
  // Diagonals first (0..3), then straight lines (4..7): bishops use 0..3, rooks 4..7, queens all.
  var KING_OFF_SLIDE = [-17, -15, 15, 17, -16, -1, 1, 16];

  Chess.prototype.make = function (m) {
    var b = this.board, from = m & 127, to = (m >> 7) & 127, promo = (m >> 14) & 7, flags = m >> 17;
    var us = this.turn, p = b[from], cap = b[to], lo = this.lo, hi = this.hi, k;
    this.uMove.push(m); this.uCastle.push(this.castling); this.uEp.push(this.ep); this.uHalf.push(this.half);
    this.uLo.push(lo); this.uHi.push(hi);
    k = p * 128 + from; lo ^= Z_LO[k]; hi ^= Z_HI[k];
    b[from] = 0;
    if (flags & F_EP) {
      var csq = us === WHITE ? to + 16 : to - 16;
      cap = b[csq]; b[csq] = 0;
      k = cap * 128 + csq; lo ^= Z_LO[k]; hi ^= Z_HI[k];
    } else if (cap) { k = cap * 128 + to; lo ^= Z_LO[k]; hi ^= Z_HI[k]; }
    this.uCap.push(cap);
    var np = promo ? (us | promo) : p;
    b[to] = np; k = np * 128 + to; lo ^= Z_LO[k]; hi ^= Z_HI[k];
    if ((p & 7) === KING) {
      this.kingSq[us >> 3] = to;
      var rook = us | ROOK;
      if (flags & F_KCASTLE) {
        b[to + 1] = 0; b[to - 1] = rook;
        k = rook * 128 + to + 1; lo ^= Z_LO[k]; hi ^= Z_HI[k];
        k = rook * 128 + to - 1; lo ^= Z_LO[k]; hi ^= Z_HI[k];
      } else if (flags & F_QCASTLE) {
        b[to - 2] = 0; b[to + 1] = rook;
        k = rook * 128 + to - 2; lo ^= Z_LO[k]; hi ^= Z_HI[k];
        k = rook * 128 + to + 1; lo ^= Z_LO[k]; hi ^= Z_HI[k];
      }
    }
    var oc = this.castling, nc = oc & CASTLE_MASK[from] & CASTLE_MASK[to];
    if (nc !== oc) { lo ^= ZC_LO[oc] ^ ZC_LO[nc]; hi ^= ZC_HI[oc] ^ ZC_HI[nc]; this.castling = nc; }
    if (this.ep >= 0) { lo ^= ZE_LO[this.ep & 7]; hi ^= ZE_HI[this.ep & 7]; }
    this.ep = -1;
    if (flags & F_DOUBLE) {
      var epSq = (from + to) >> 1;
      if (this.epCapturable(epSq, us ^ 8)) { this.ep = epSq; lo ^= ZE_LO[epSq & 7]; hi ^= ZE_HI[epSq & 7]; }
    }
    this.half = ((p & 7) === PAWN || cap) ? 0 : this.half + 1;
    if (us === BLACK) this.full++;
    this.turn = us ^ 8;
    this.lo = lo ^ ZS_LO; this.hi = hi ^ ZS_HI;
  };

  Chess.prototype.undo = function () {
    var m = this.uMove.pop();
    if (m === undefined) return 0;
    var b = this.board, from = m & 127, to = (m >> 7) & 127, promo = (m >> 14) & 7, flags = m >> 17;
    var us = this.turn ^ 8, cap = this.uCap.pop();
    this.turn = us;
    var p = promo ? (us | PAWN) : b[to];
    b[from] = p; b[to] = 0;
    if (flags & F_EP) b[us === WHITE ? to + 16 : to - 16] = cap; else b[to] = cap;
    if ((p & 7) === KING) {
      this.kingSq[us >> 3] = from;
      if (flags & F_KCASTLE) { b[to - 1] = 0; b[to + 1] = us | ROOK; }
      else if (flags & F_QCASTLE) { b[to + 1] = 0; b[to - 2] = us | ROOK; }
    }
    this.castling = this.uCastle.pop(); this.ep = this.uEp.pop(); this.half = this.uHalf.pop();
    this.lo = this.uLo.pop(); this.hi = this.uHi.pop();
    if (us === BLACK) this.full--;
    return m;
  };

  /** Pass the move (used by the search only). */
  Chess.prototype.makeNull = function () {
    this.uMove.push(0); this.uCap.push(0); this.uCastle.push(this.castling); this.uEp.push(this.ep); this.uHalf.push(this.half);
    this.uLo.push(this.lo); this.uHi.push(this.hi);
    if (this.ep >= 0) { this.lo ^= ZE_LO[this.ep & 7]; this.hi ^= ZE_HI[this.ep & 7]; this.ep = -1; }
    this.half++;
    this.turn ^= 8; this.lo ^= ZS_LO; this.hi ^= ZS_HI;
  };
  Chess.prototype.undoNull = function () {
    this.uMove.pop(); this.uCap.pop();
    this.castling = this.uCastle.pop(); this.ep = this.uEp.pop(); this.half = this.uHalf.pop();
    this.lo = this.uLo.pop(); this.hi = this.uHi.pop();
    this.turn ^= 8;
  };

  Chess.prototype.legalMoves = function () {
    var pseudo = this.genPseudo(false), out = [], us = this.turn;
    for (var i = 0; i < pseudo.length; i++) {
      this.make(pseudo[i]);
      if (!this.inCheck(us)) out.push(pseudo[i]);
      this.undo();
    }
    return out;
  };

  Chess.prototype.isCheckmate = function () { return this.inCheck() && this.legalMoves().length === 0; };
  Chess.prototype.isStalemate = function () { return !this.inCheck() && this.legalMoves().length === 0; };

  /** How many earlier positions in this game equal the current one. */
  Chess.prototype.repetitions = function () {
    var n = 0, len = this.uLo.length, stop = Math.max(0, len - this.half);
    for (var i = len - 2; i >= stop; i -= 2) if (this.uLo[i] === this.lo && this.uHi[i] === this.hi) n++;
    return n;
  };

  Chess.prototype.insufficientMaterial = function () {
    var b = this.board, minors = 0, bishopsLight = 0, bishopsDark = 0, knights = 0;
    for (var sq = 0; sq < 120; sq++) {
      if (sq & 0x88) { sq += 7; continue; }
      var t = b[sq] & 7;
      if (!t || t === KING) continue;
      if (t === PAWN || t === ROOK || t === QUEEN) return false;
      minors++;
      if (t === KNIGHT) knights++;
      else if (((sq >> 4) + (sq & 7)) & 1) bishopsDark++; else bishopsLight++;
    }
    if (minors <= 1) return true;
    return knights === 0 && (bishopsLight === 0 || bishopsDark === 0);
  };

  /** '' while the game goes on, otherwise 'checkmate', 'stalemate', 'repetition', 'fifty' or 'material'. */
  Chess.prototype.gameOver = function () {
    if (this.legalMoves().length === 0) return this.inCheck() ? 'checkmate' : 'stalemate';
    if (this.insufficientMaterial()) return 'material';
    if (this.repetitions() >= 2) return 'repetition';
    if (this.half >= 100) return 'fifty';
    return '';
  };

  /** Standard algebraic notation for a legal move in the current position. */
  Chess.prototype.san = function (m) {
    var from = m & 127, to = (m >> 7) & 127, promo = (m >> 14) & 7, flags = m >> 17, s;
    if (flags & F_KCASTLE) s = 'O-O';
    else if (flags & F_QCASTLE) s = 'O-O-O';
    else {
      var t = this.board[from] & 7;
      s = '';
      if (t !== PAWN) {
        s = LETTERS.charAt(t);
        var legal = this.legalMoves(), sameFile = false, sameRank = false, other = false;
        for (var i = 0; i < legal.length; i++) {
          var o = legal[i], of = o & 127;
          if (of === from || ((o >> 7) & 127) !== to || (this.board[of] & 7) !== t) continue;
          other = true;
          if ((of & 7) === (from & 7)) sameFile = true;
          if ((of >> 4) === (from >> 4)) sameRank = true;
        }
        if (other) {
          if (!sameFile) s += sqName(from).charAt(0);
          else if (!sameRank) s += sqName(from).charAt(1);
          else s += sqName(from);
        }
      } else if (flags & F_CAPTURE) s = sqName(from).charAt(0);
      if (flags & F_CAPTURE) s += 'x';
      s += sqName(to);
      if (promo) s += '=' + LETTERS.charAt(promo);
    }
    this.make(m);
    if (this.inCheck()) s += this.legalMoves().length === 0 ? '#' : '+';
    this.undo();
    return s;
  };

  /** Finds the legal move written as SAN ("Nf3", "exd5", "O-O", "e8=Q") or as coordinates ("e2e4", "e7e8q"). Returns 0 if none or ambiguous. */
  Chess.prototype.parseMove = function (text) {
    var s = String(text).trim().replace(/[+#!?]+$/g, '').replace(/\s*e\.p\.$/, '');
    if (!s) return 0;
    var legal = this.legalMoves(), i, m, found = 0;
    if (/^(O-O-O|0-0-0)$/i.test(s) || /^(O-O|0-0)$/i.test(s)) {
      var want = s.length > 3 ? F_QCASTLE : F_KCASTLE;
      for (i = 0; i < legal.length; i++) if (mFlags(legal[i]) & want) return legal[i];
      return 0;
    }
    var c = /^([a-h][1-8])[-x]?([a-h][1-8])=?([qrbnQRBN])?$/.exec(s);
    if (c) {
      var cf = sqIndex(c[1]), ct = sqIndex(c[2]), cp = c[3] ? ' pnbrq'.indexOf(c[3].toLowerCase()) : 0;
      for (i = 0; i < legal.length; i++) {
        m = legal[i];
        if (mFrom(m) !== cf || mTo(m) !== ct) continue;
        var pr = mPromo(m);
        // Without a promotion letter, a pawn reaching the last rank becomes a queen.
        if (pr === (cp || (pr ? QUEEN : 0))) return m;
      }
    }
    var a = /^([NBRQK])?([a-h])?([1-8])?x?([a-h][1-8])(?:=?([NBRQ]))?$/.exec(s);
    if (!a) return 0;
    var type = a[1] ? LETTERS.indexOf(a[1]) : PAWN, to = sqIndex(a[4]), promo = a[5] ? LETTERS.indexOf(a[5]) : 0;
    for (i = 0; i < legal.length; i++) {
      m = legal[i];
      var from = mFrom(m);
      if (mTo(m) !== to || (this.board[from] & 7) !== type) continue;
      if (mFlags(m) & (F_KCASTLE | F_QCASTLE)) continue;
      if (mPromo(m) !== promo) continue;
      if (a[2] && sqName(from).charAt(0) !== a[2]) continue;
      if (a[3] && sqName(from).charAt(1) !== a[3]) continue;
      if (type === PAWN && !a[2] && (from & 7) !== (to & 7)) continue;
      if (found) return 0;
      found = m;
    }
    return found;
  };

  /** Plays a move given as SAN or coordinates. Returns the packed move, or 0 if it is not legal. */
  Chess.prototype.play = function (text) {
    var m = this.parseMove(text);
    if (m) this.make(m);
    return m;
  };

  Chess.prototype.history = function () { return this.uMove.slice(); };

  Chess.prototype.perft = function (depth) {
    if (depth === 0) return 1;
    var moves = this.genPseudo(false), n = 0, us = this.turn;
    for (var i = 0; i < moves.length; i++) {
      this.make(moves[i]);
      if (!this.inCheck(us)) n += depth === 1 ? 1 : this.perft(depth - 1);
      this.undo();
    }
    return n;
  };

  // ---------------------------------------------------------------- PGN

  var NAG_OF = { '!': 1, '?': 2, '!!': 3, '??': 4, '!?': 5, '?!': 6 };

  /** Pulls [%cal ...] arrows and [%csl ...] square marks out of a comment and returns the clean text. */
  function readComment(raw) {
    var arrows = [], marks = [];
    var text = raw.replace(/\[%(\w+)\s+([^\]]*)\]/g, function (_, cmd, body) {
      if (cmd === 'cal' || cmd === 'csl') {
        body.split(',').forEach(function (item) {
          item = item.trim();
          var col = item.charAt(0).toUpperCase(), rest = item.slice(1);
          if (cmd === 'cal' && /^[a-h][1-8][a-h][1-8]$/.test(rest)) arrows.push({ color: col, from: rest.slice(0, 2), to: rest.slice(2) });
          if (cmd === 'csl' && /^[a-h][1-8]$/.test(rest)) marks.push({ color: col, sq: rest });
        });
      }
      return '';
    }).replace(/\s+/g, ' ').trim();
    return { text: text, arrows: arrows, marks: marks };
  }

  /**
   * Parses PGN text into games: { headers, fen, intro, introArrows, introMarks, line, result, errors }.
   * `line` is a list of nodes { m, san, uci, comment, arrows, marks, nag, pre, vars }, where `vars`
   * holds alternative lines that start from the same position as the node.
   */
  function parsePgn(text) {
    var games = [], re = /\[\s*(\w+)\s*"((?:[^"\\]|\\.)*)"\s*\]|\{([^}]*)\}|;([^\n]*)|(\()|(\))|\$(\d+)|(1-0|0-1|1\/2-1\/2|\*)|(\d+\.(?:\.\.)?|\.\.\.?)|([A-Za-z0][A-Za-z0-9=+#\-]*)([!?]{1,2})?|%[^\n]*/g;
    var game = null, chess = null, frames = null, skipLine = false, skipParens = 0, tok;

    function begin() {
      game = { headers: {}, fen: START_FEN, intro: '', introArrows: [], introMarks: [], line: [], result: '*', errors: [] };
      chess = null; frames = null; skipLine = false; skipParens = 0;
      games.push(game);
    }
    function ensureBoard() {
      if (chess) return;
      try { chess = new Chess(game.headers.FEN || START_FEN); }
      catch (e) { game.errors.push('FEN: ' + e.message); chess = new Chess(); skipLine = true; }
      game.fen = chess.fen();
      frames = [{ line: game.line, made: 0, last: null, redo: 0, pre: null, parent: null }];
    }

    text = String(text).replace(/\r/g, '').replace(/^\uFEFF/, '');
    while ((tok = re.exec(text))) {
      if (tok[1] !== undefined) {
        if (!game || frames || game.done) begin();
        game.headers[tok[1]] = tok[2].replace(/\\(.)/g, '$1');
        continue;
      }
      if (tok[0].charAt(0) === '%') continue;
      if (!game || game.done) begin();
      if (tok[8] !== undefined) { game.result = tok[8]; game.done = true; continue; }
      ensureBoard();
      var f = frames[frames.length - 1];
      if (tok[5]) {                                   // "(" opens a variation
        if (skipLine || skipParens > 0) { skipParens++; continue; }
        if (!f.last) { skipParens = 1; continue; }
        var redo = chess.undo(); f.made--;
        var varLine = [];
        f.last.vars.push(varLine);
        frames.push({ line: varLine, made: 0, last: null, redo: redo, pre: null, parent: f });
      } else if (tok[6]) {                            // ")" closes it
        if (skipParens > 0) { skipParens--; continue; }
        if (frames.length === 1) continue;
        while (f.made > 0) { chess.undo(); f.made--; }
        frames.pop();
        chess.make(f.redo); f.parent.made++;
        skipLine = false;
      } else if (skipLine || skipParens > 0) {
        continue;
      } else if (tok[3] !== undefined || tok[4] !== undefined) {
        var c = readComment(tok[3] !== undefined ? tok[3] : tok[4]);
        if (f.last) {
          if (c.text) f.last.comment = f.last.comment ? f.last.comment + ' ' + c.text : c.text;
          f.last.arrows = f.last.arrows.concat(c.arrows); f.last.marks = f.last.marks.concat(c.marks);
        } else if (frames.length === 1) {
          if (c.text) game.intro = game.intro ? game.intro + ' ' + c.text : c.text;
          game.introArrows = game.introArrows.concat(c.arrows); game.introMarks = game.introMarks.concat(c.marks);
        } else if (c.text) f.pre = f.pre ? f.pre + ' ' + c.text : c.text;
      } else if (tok[7] !== undefined) {
        if (f.last && !f.last.nag) f.last.nag = parseInt(tok[7], 10);
      } else if (tok[10] !== undefined) {
        var m = chess.parseMove(tok[10]);
        if (!m) {
          game.errors.push('Illegal or unclear move "' + tok[10] + '" after ' + (f.last ? f.last.san : 'the start'));
          skipLine = true;                            // ignore the rest of this line
          continue;
        }
        var node = { m: m, san: chess.san(m), uci: uci(m), comment: '', arrows: [], marks: [], nag: tok[11] ? NAG_OF[tok[11]] : 0, pre: f.pre || '', vars: [] };
        f.pre = null;
        chess.make(m); f.made++;
        f.line.push(node); f.last = node;
      }
    }
    games.forEach(function (g) { delete g.done; });
    return games.filter(function (g) { return g.line.length || Object.keys(g.headers).length; });
  }

  var api = {
    Chess: Chess, parsePgn: parsePgn, START_FEN: START_FEN,
    PAWN: PAWN, KNIGHT: KNIGHT, BISHOP: BISHOP, ROOK: ROOK, QUEEN: QUEEN, KING: KING, WHITE: WHITE, BLACK: BLACK,
    F_CAPTURE: F_CAPTURE, F_DOUBLE: F_DOUBLE, F_EP: F_EP, F_KCASTLE: F_KCASTLE, F_QCASTLE: F_QCASTLE, F_PROMO: F_PROMO,
    mFrom: mFrom, mTo: mTo, mPromo: mPromo, mFlags: mFlags, sqName: sqName, sqIndex: sqIndex, uci: uci
  };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  root.HCChess = api;
})(typeof self !== 'undefined' ? self : (typeof globalThis !== 'undefined' ? globalThis : this));
