/*
 * Hashem Chess Puzzle — built-in engine.
 * A small alpha-beta searcher used for play against the computer, for showing why a wrong
 * puzzle move fails, and for analysis when Stockfish is not bundled.
 * Runs inside a Web Worker (see the message handler at the bottom) and in Node for tests.
 */
(function (root) {
  'use strict';
  var C = root.HCChess || (typeof require !== 'undefined' ? require('./chess.js') : null);
  var Chess = C.Chess;

  var VALUE = [0, 100, 320, 330, 500, 900, 0];
  var MATE = 30000, INF = 32000;

  // Piece-square tables from White's side, row 0 = rank 8 (the widely used "simplified evaluation" values).
  var PST = [null,
    [0, 0, 0, 0, 0, 0, 0, 0, 50, 50, 50, 50, 50, 50, 50, 50, 10, 10, 20, 30, 30, 20, 10, 10, 5, 5, 10, 25, 25, 10, 5, 5,
      0, 0, 0, 20, 20, 0, 0, 0, 5, -5, -10, 0, 0, -10, -5, 5, 5, 10, 10, -20, -20, 10, 10, 5, 0, 0, 0, 0, 0, 0, 0, 0],
    [-50, -40, -30, -30, -30, -30, -40, -50, -40, -20, 0, 0, 0, 0, -20, -40, -30, 0, 10, 15, 15, 10, 0, -30, -30, 5, 15, 20, 20, 15, 5, -30,
      -30, 0, 15, 20, 20, 15, 0, -30, -30, 5, 10, 15, 15, 10, 5, -30, -40, -20, 0, 5, 5, 0, -20, -40, -50, -40, -30, -30, -30, -30, -40, -50],
    [-20, -10, -10, -10, -10, -10, -10, -20, -10, 0, 0, 0, 0, 0, 0, -10, -10, 0, 5, 10, 10, 5, 0, -10, -10, 5, 5, 10, 10, 5, 5, -10,
      -10, 0, 10, 10, 10, 10, 0, -10, -10, 10, 10, 10, 10, 10, 10, -10, -10, 5, 0, 0, 0, 0, 5, -10, -20, -10, -10, -10, -10, -10, -10, -20],
    [0, 0, 0, 0, 0, 0, 0, 0, 5, 10, 10, 10, 10, 10, 10, 5, -5, 0, 0, 0, 0, 0, 0, -5, -5, 0, 0, 0, 0, 0, 0, -5,
      -5, 0, 0, 0, 0, 0, 0, -5, -5, 0, 0, 0, 0, 0, 0, -5, -5, 0, 0, 0, 0, 0, 0, -5, 0, 0, 0, 5, 5, 0, 0, 0],
    [-20, -10, -10, -5, -5, -10, -10, -20, -10, 0, 0, 0, 0, 0, 0, -10, -10, 0, 5, 5, 5, 5, 0, -10, -5, 0, 5, 5, 5, 5, 0, -5,
      0, 0, 5, 5, 5, 5, 0, -5, -10, 5, 5, 5, 5, 5, 0, -10, -10, 0, 5, 0, 0, 0, 0, -10, -20, -10, -10, -5, -5, -10, -10, -20],
    [-30, -40, -40, -50, -50, -40, -40, -30, -30, -40, -40, -50, -50, -40, -40, -30, -30, -40, -40, -50, -50, -40, -40, -30, -30, -40, -40, -50, -50, -40, -40, -30,
      -20, -30, -30, -40, -40, -30, -30, -20, -10, -20, -20, -20, -20, -20, -20, -10, 20, 20, 0, 0, 0, 0, 20, 20, 20, 30, 10, 0, 0, 10, 30, 20]
  ];
  var KING_END = [-50, -40, -30, -20, -20, -30, -40, -50, -30, -20, -10, 0, 0, -10, -20, -30, -30, -10, 20, 30, 30, 20, -10, -30, -30, -10, 30, 40, 40, 30, -10, -30,
    -30, -10, 30, 40, 40, 30, -10, -30, -30, -10, 20, 30, 30, 20, -10, -30, -30, -30, 0, 0, 0, 0, -30, -30, -50, -30, -30, -30, -30, -30, -30, -50];

  var TT_BITS = 18, TT_SIZE = 1 << TT_BITS, TT_MASK = TT_SIZE - 1;

  function Engine() {
    this.c = new Chess();
    this.ttLo = new Int32Array(TT_SIZE); this.ttHi = new Int32Array(TT_SIZE);
    this.ttMove = new Int32Array(TT_SIZE); this.ttScore = new Int16Array(TT_SIZE);
    this.ttDepth = new Int8Array(TT_SIZE); this.ttFlag = new Int8Array(TT_SIZE);
    this.history = new Int32Array(15 * 128);
    this.killers = [];
    this.nodes = 0; this.deadline = 0; this.stopped = false;
  }

  /** Static score in centipawns from the side to move's point of view. */
  Engine.prototype.evaluate = function () {
    var c = this.c, b = c.board, mg = 0, eg = 0, phase = 0, mat = [0, 0], pawns = 0, sq, p, t, idx, v;
    for (sq = 0; sq < 120; sq++) {
      if (sq & 0x88) { sq += 7; continue; }
      p = b[sq]; if (!p) continue;
      t = p & 7;
      if (p & 8) {
        idx = (7 - (sq >> 4)) * 8 + (sq & 7);
        if (t === 6) { mg -= PST[6][idx]; eg -= KING_END[idx]; }
        else { v = VALUE[t] + PST[t][idx]; mg -= v; eg -= v; mat[1] += VALUE[t]; }
      } else {
        idx = (sq >> 4) * 8 + (sq & 7);
        if (t === 6) { mg += PST[6][idx]; eg += KING_END[idx]; }
        else { v = VALUE[t] + PST[t][idx]; mg += v; eg += v; mat[0] += VALUE[t]; }
      }
      if (t === 1) pawns++;
      else if (t === 2 || t === 3) phase += 1; else if (t === 4) phase += 2; else if (t === 5) phase += 4;
    }
    if (phase > 24) phase = 24;
    var score = ((mg * phase + eg * (24 - phase)) / 24) | 0;
    // With a big material edge and few pawns, push the losing king to the edge and bring our king closer.
    var diff = mat[0] - mat[1];
    if (pawns <= 2 && (diff >= 400 || diff <= -400) && c.kingSq[0] >= 0 && c.kingSq[1] >= 0) {
      var win = diff > 0 ? 0 : 1, lk = c.kingSq[1 - win], wk = c.kingSq[win];
      var lf = lk & 7, lr = lk >> 4, edge = Math.max(3 - lf, lf - 4) + Math.max(3 - lr, lr - 4);
      var dist = Math.abs((wk & 7) - lf) + Math.abs((wk >> 4) - lr);
      var bonus = 12 * edge + 5 * (14 - dist);
      score += win === 0 ? bonus : -bonus;
    }
    return c.turn === 0 ? score : -score;
  };

  Engine.prototype.orderScore = function (m, ttMove, ply) {
    if (m === ttMove) return 1000000;
    var b = this.c.board, flags = m >> 17, from = m & 127, to = (m >> 7) & 127;
    if (flags & 1) {
      var victim = (flags & 4) ? 1 : (b[to] & 7);
      return 100000 + VALUE[victim] * 10 - VALUE[b[from] & 7] + ((flags & 32) ? 9000 : 0);
    }
    if (flags & 32) return 90000 + ((m >> 14) & 7);
    var k = this.killers[ply];
    if (k && (k[0] === m || k[1] === m)) return 80000;
    return this.history[b[from] * 128 + to];
  };

  Engine.prototype.sorted = function (moves, ttMove, ply) {
    var n = moves.length, scores = new Array(n), i, j, s, m;
    for (i = 0; i < n; i++) scores[i] = this.orderScore(moves[i], ttMove, ply);
    for (i = 1; i < n; i++) {
      s = scores[i]; m = moves[i]; j = i - 1;
      while (j >= 0 && scores[j] < s) { scores[j + 1] = scores[j]; moves[j + 1] = moves[j]; j--; }
      scores[j + 1] = s; moves[j + 1] = m;
    }
    return moves;
  };

  Engine.prototype.quiesce = function (alpha, beta, ply) {
    var c = this.c;
    this.nodes++;
    var inCheck = c.inCheck();
    var stand = -INF;
    if (!inCheck) {
      stand = this.evaluate();
      if (stand >= beta) return stand;
      if (stand > alpha) alpha = stand;
      if (ply > 48) return stand;
    }
    var moves = this.sorted(c.genPseudo(!inCheck), 0, ply), us = c.turn, best = stand, legal = 0;
    for (var i = 0; i < moves.length; i++) {
      c.make(moves[i]);
      if (c.inCheck(us)) { c.undo(); continue; }
      legal++;
      var score = -this.quiesce(-beta, -alpha, ply + 1);
      c.undo();
      if (score > best) { best = score; if (score > alpha) { alpha = score; if (alpha >= beta) break; } }
    }
    if (inCheck && !legal) return -MATE + ply;
    return best;
  };

  Engine.prototype.search = function (depth, alpha, beta, ply, allowNull) {
    var c = this.c;
    if (this.stopped) return 0;
    if ((++this.nodes & 2047) === 0 && Date.now() > this.deadline) { this.stopped = true; return 0; }
    if (ply > 0 && (c.half >= 100 || c.repetitions() > 0 || c.insufficientMaterial())) return 0;
    var inCheck = c.inCheck();
    if (inCheck) depth++;
    if (depth <= 0) return this.quiesce(alpha, beta, ply);
    if (ply > 60) return this.evaluate();

    var idx = c.lo & TT_MASK, ttMove = 0, alpha0 = alpha;
    if (this.ttLo[idx] === c.lo && this.ttHi[idx] === c.hi) {
      ttMove = this.ttMove[idx];
      if (ply > 0 && this.ttDepth[idx] >= depth) {
        var ts = this.ttScore[idx];
        if (ts > MATE - 200) ts -= ply; else if (ts < -MATE + 200) ts += ply;
        var tf = this.ttFlag[idx];
        if (tf === 0) return ts;
        if (tf === 1 && ts >= beta) return ts;
        if (tf === 2 && ts <= alpha) return ts;
      }
    }

    if (allowNull && !inCheck && depth >= 3 && ply > 0 && beta < MATE - 200 && this.hasPieces(c.turn)) {
      c.makeNull();
      var ns = -this.search(depth - 3, -beta, -beta + 1, ply + 1, false);
      c.undoNull();
      if (this.stopped) return 0;
      if (ns >= beta) return beta;
    }

    var moves = this.sorted(c.genPseudo(false), ttMove, ply), us = c.turn, best = -INF, bestMove = 0, legal = 0;
    for (var i = 0; i < moves.length; i++) {
      var m = moves[i];
      c.make(m);
      if (c.inCheck(us)) { c.undo(); continue; }
      legal++;
      var score;
      if (legal === 1) score = -this.search(depth - 1, -beta, -alpha, ply + 1, true);
      else {
        score = -this.search(depth - 1, -alpha - 1, -alpha, ply + 1, true);
        if (score > alpha && score < beta) score = -this.search(depth - 1, -beta, -alpha, ply + 1, true);
      }
      c.undo();
      if (this.stopped) return 0;
      if (score > best) {
        best = score; bestMove = m;
        if (score > alpha) {
          alpha = score;
          if (alpha >= beta) {
            if (!((m >> 17) & 1)) {
              var k = this.killers[ply] || (this.killers[ply] = [0, 0]);
              if (k[0] !== m) { k[1] = k[0]; k[0] = m; }
              this.history[c.board[m & 127] * 128 + ((m >> 7) & 127)] += depth * depth;
            }
            break;
          }
        }
      }
    }
    if (!legal) return inCheck ? -MATE + ply : 0;
    var store = best;
    if (store > MATE - 200) store += ply; else if (store < -MATE + 200) store -= ply;
    this.ttLo[idx] = c.lo; this.ttHi[idx] = c.hi; this.ttMove[idx] = bestMove; this.ttScore[idx] = store;
    this.ttDepth[idx] = depth > 127 ? 127 : depth; this.ttFlag[idx] = best >= beta ? 1 : (best <= alpha0 ? 2 : 0);
    return best;
  };

  Engine.prototype.hasPieces = function (color) {
    var b = this.c.board;
    for (var sq = 0; sq < 120; sq++) {
      if (sq & 0x88) { sq += 7; continue; }
      var p = b[sq];
      if (p && (p & 8) === color && (p & 7) > 1 && (p & 7) < 6) return true;
    }
    return false;
  };

  /** Follows the hash table from the current position to list the expected line. */
  Engine.prototype.pv = function (first, max) {
    var c = this.c, line = [], made = 0, m = first;
    while (m && line.length < max) {
      var legal = c.legalMoves();
      if (legal.indexOf(m) < 0) break;
      line.push(C.uci(m)); c.make(m); made++;
      if (c.repetitions() > 0) break;
      var idx = c.lo & TT_MASK;
      m = (this.ttLo[idx] === c.lo && this.ttHi[idx] === c.hi) ? this.ttMove[idx] : 0;
    }
    while (made--) c.undo();
    return line;
  };

  Engine.prototype.setPosition = function (fen, moves) {
    var err = this.c.load(fen || C.START_FEN);
    if (err) throw new Error(err);
    if (moves) for (var i = 0; i < moves.length; i++) if (!this.c.play(moves[i])) throw new Error('illegal move ' + moves[i]);
  };

  function scoreInfo(score) {
    if (score > MATE - 200) return { mate: Math.ceil((MATE - score) / 2) };
    if (score < -MATE + 200) return { mate: -Math.ceil((MATE + score) / 2) };
    return { cp: score };
  }

  /**
   * Searches the current position.
   * opts: { depth, movetime (ms), noise (centipawns of random error, for weaker levels), onInfo }.
   * Returns { move (uci or null), cp | mate, depth, pv }.
   */
  Engine.prototype.think = function (opts) {
    opts = opts || {};
    var c = this.c, maxDepth = opts.depth || 64, t0 = Date.now();
    this.deadline = t0 + (opts.movetime || 600000);
    this.stopped = false; this.nodes = 0; this.killers = [];
    for (var h = 0; h < this.history.length; h++) this.history[h] = 0;
    var legal = c.legalMoves();
    if (!legal.length) return { move: null, depth: 0, pv: [], cp: 0, over: c.inCheck() ? 'checkmate' : 'stalemate' };

    if (opts.noise) {
      // Weak levels: score every move at a fixed shallow depth, blur the scores, play the best blurred one.
      var bestM = legal[0], bestS = -Infinity, trueS = 0;
      for (var i = 0; i < legal.length; i++) {
        c.make(legal[i]);
        var s = -this.search(maxDepth - 1, -INF, INF, 1, true);
        c.undo();
        var blurred = s + (Math.random() * 2 - 1) * opts.noise;
        if (s > MATE - 200) blurred = s;                 // never talk itself out of a mate it has found
        if (blurred > bestS) { bestS = blurred; bestM = legal[i]; trueS = s; }
      }
      var r0 = scoreInfo(trueS); r0.move = C.uci(bestM); r0.depth = maxDepth; r0.pv = [C.uci(bestM)]; r0.nodes = this.nodes;
      return r0;
    }

    var result = { move: C.uci(legal[0]), cp: 0, depth: 0, pv: [C.uci(legal[0])] };
    for (var d = 1; d <= maxDepth; d++) {
      var score = this.search(d, -INF, INF, 0, false);
      if (this.stopped) break;
      var idx = c.lo & TT_MASK, bm = (this.ttLo[idx] === c.lo && this.ttHi[idx] === c.hi) ? this.ttMove[idx] : 0;
      if (!bm || legal.indexOf(bm) < 0) break;
      result = scoreInfo(score);
      result.move = C.uci(bm); result.depth = d; result.pv = this.pv(bm, 12); result.nodes = this.nodes; result.time = Date.now() - t0;
      if (opts.onInfo) opts.onInfo(result);
      if (result.mate !== undefined && Math.abs(result.mate) * 2 <= d) break;   // a forced mate will not get shorter
      if (opts.movetime && Date.now() - t0 > opts.movetime * 0.55) break;       // no time for another full depth
    }
    return result;
  };

  /** Strength settings for play against the computer. */
  var LEVELS = [null,
    { depth: 1, noise: 240 }, { depth: 2, noise: 130 }, { depth: 3, noise: 60 },
    { depth: 4, noise: 20 }, { depth: 7, movetime: 800 }, { depth: 14, movetime: 2500 }
  ];

  var api = { Engine: Engine, LEVELS: LEVELS };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  root.HCEngine = api;

  // Worker protocol: { id, cmd: 'go', fen, moves, level | depth | movetime | noise, info } -> info* then best.
  if (typeof WorkerGlobalScope !== 'undefined' && root instanceof WorkerGlobalScope) {
    var engine = new Engine();
    root.onmessage = function (e) {
      var q = e.data;
      if (q.cmd !== 'go') return;
      try {
        engine.setPosition(q.fen, q.moves);
        var o = q.level ? Object.assign({}, LEVELS[q.level]) : { depth: q.depth, movetime: q.movetime, noise: q.noise };
        if (q.info) o.onInfo = function (r) { root.postMessage({ id: q.id, type: 'info', result: r }); };
        root.postMessage({ id: q.id, type: 'best', result: engine.think(o) });
      } catch (err) {
        root.postMessage({ id: q.id, type: 'error', message: String(err && err.message || err) });
      }
    };
  }
})(typeof self !== 'undefined' ? self : (typeof globalThis !== 'undefined' ? globalThis : this));
