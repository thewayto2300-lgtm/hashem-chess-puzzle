/* Hashem Chess Puzzle — engine clients: the built-in engine in a worker, and Stockfish (UCI) when its files are bundled. */
(function (root) {
  'use strict';
  var HCC = root.HCC;

  // ---------------------------------------------------------------- built-in engine
  var local = HCC.local = {
    w: null, failed: false, seq: 0, jobs: {}, sync: null,
    ensure: function () {
      if (this.w || this.failed) return;
      try {
        var src = document.getElementById('chess-js').textContent + '\n' + document.getElementById('engine-js').textContent;
        var url = URL.createObjectURL(new Blob([src], { type: 'text/javascript' })), self = this;
        this.w = new Worker(url);
        this.w.onmessage = function (e) {
          var msg = e.data, job = self.jobs[msg.id];
          if (!job) return;
          if (msg.type === 'info') { if (job.onInfo) job.onInfo(msg.result); return; }
          delete self.jobs[msg.id];
          if (msg.type === 'best') job.resolve(msg.result); else job.reject(new Error(msg.message));
        };
        this.w.onerror = function () { self.failed = true; self.w = null; self.rerunAll(); };
      } catch (e) { this.failed = true; this.w = null; }
    },
    /** q: { fen, moves, level | depth, movetime, noise }. Resolves with the engine's result. */
    go: function (q, onInfo) {
      var self = this;
      this.ensure();
      return new Promise(function (resolve, reject) {
        var id = ++self.seq;
        q.id = id; q.cmd = 'go'; q.info = !!onInfo;
        self.jobs[id] = { q: q, onInfo: onInfo, resolve: resolve, reject: reject };
        if (self.w) self.w.postMessage(q); else self.runSync(id);
      });
    },
    /** Fallback when workers are unavailable: think on the main thread. */
    runSync: function (id) {
      var self = this;
      setTimeout(function () {
        var job = self.jobs[id];
        if (!job) return;
        delete self.jobs[id];
        try {
          var E = root.HCEngine, q = job.q;
          self.sync = self.sync || new E.Engine();
          self.sync.setPosition(q.fen, q.moves);
          var o = q.level ? Object.assign({}, E.LEVELS[q.level]) : { depth: q.depth, movetime: Math.min(q.movetime || 1500, 1500), noise: q.noise };
          if (job.onInfo) o.onInfo = job.onInfo;
          job.resolve(self.sync.think(o));
        } catch (e) { job.reject(e); }
      }, 30);
    },
    rerunAll: function () { for (var id in this.jobs) this.runSync(id); },
    /** Drops whatever the worker is doing (used when the analysed position changes). */
    cancel: function () {
      if (this.w) { this.w.terminate(); this.w = null; }
      this.jobs = {};
    }
  };

  // ---------------------------------------------------------------- Stockfish (optional)
  var sf = HCC.sf = {
    state: 'unknown', name: 'Stockfish', w: null, cur: null, next: null, thinking: false, ready: null,
    post: function (s) { this.w.postMessage(s); },
    /** Looks for engine/engine.json ({ "worker": "<file>.js" }) next to the app. Resolves true when Stockfish answers. */
    init: function () {
      if (this.ready) return this.ready;
      var self = this;
      this.state = 'loading';
      this.ready = new Promise(function (resolve) {
        var settled = false;
        function done(ok) { if (settled) return; settled = true; self.state = ok ? 'ready' : 'none'; if (!ok && self.w) { try { self.w.terminate(); } catch (e) { /* ignore */ } self.w = null; } resolve(ok); }
        fetch('engine/engine.json').then(function (r) { if (!r.ok) throw new Error('none'); return r.json(); }).then(function (cfg) {
          if (!cfg || !/^[\w.\-]+\.js$/.test(cfg.worker || '')) throw new Error('bad config');
          self.w = new Worker('engine/' + cfg.worker);
          self.w.onerror = function () { done(false); };
          self.w.onmessage = function (e) {
            var line = typeof e.data === 'string' ? e.data : '';
            if (line.indexOf('id name ') === 0) self.name = line.slice(8).trim();
            else if (line === 'uciok') self.post('isready');
            else if (line === 'readyok' && !settled) done(true);
            else self.onLine(line);
          };
          self.post('uci');
          setTimeout(function () { done(false); }, 20000);
        }).catch(function () { done(false); });
      });
      return this.ready;
    },
    onLine: function (line) {
      var c = this.cur;
      if (line.indexOf('bestmove') === 0) {
        this.thinking = false; this.cur = null;
        if (c && !c.cancelled && c.onBest) c.onBest(line.split(' ')[1]);
        if (this.next) this.start(this.next);
        return;
      }
      if (!c || c.cancelled || !c.onInfo || line.indexOf('info') !== 0 || line.indexOf(' pv ') < 0) return;
      if (/\b(lowerbound|upperbound)\b/.test(line)) return;
      var d = /\bdepth (\d+)/.exec(line), mp = /\bmultipv (\d+)/.exec(line), sc = /\bscore (cp|mate) (-?\d+)/.exec(line), pv = / pv (.+)$/.exec(line);
      if (!d || !sc || !pv) return;
      var info = { depth: +d[1], multipv: mp ? +mp[1] : 1, pv: pv[1].trim().split(/\s+/) };
      info[sc[1]] = +sc[2];
      c.onInfo(info);
    },
    /** req: { fen, moves, go: 'go depth 20', options: { name: value }, onInfo, onBest } */
    request: function (req) {
      if (this.state !== 'ready') return false;
      if (this.thinking) { if (this.cur) this.cur.cancelled = true; this.next = req; this.post('stop'); }
      else this.start(req);
      return true;
    },
    start: function (req) {
      this.next = null; this.cur = req;
      for (var k in (req.options || {})) this.post('setoption name ' + k + ' value ' + req.options[k]);
      this.post('position fen ' + req.fen + (req.moves && req.moves.length ? ' moves ' + req.moves.join(' ') : ''));
      this.post(req.go);
      this.thinking = true;
    },
    stop: function () {
      this.next = null;
      if (this.thinking) { if (this.cur) this.cur.cancelled = true; this.post('stop'); }
    }
  };

  // ---------------------------------------------------------------- what the screens use

  /** A move for the computer opponent. Levels 1-6 use the built-in engine, 7-8 Stockfish. Resolves with a coordinate move. */
  HCC.engineMove = function (fen, moves, level) {
    if (level >= 7 && sf.state === 'ready') {
      return new Promise(function (resolve) {
        sf.request({ fen: fen, moves: moves, go: 'go movetime ' + (level === 7 ? 500 : 1500), options: { MultiPV: 1, 'Skill Level': level === 7 ? 8 : 20 }, onBest: resolve });
      });
    }
    return local.go({ fen: fen, moves: moves, level: Math.min(level, 6) }).then(function (r) { return r.move; });
  };

  /** The best reply the built-in engine sees (used to show why a puzzle move fails). */
  HCC.quickReply = function (fen) {
    return local.go({ fen: fen, depth: 5, movetime: 700 }).then(function (r) { return r.move; });
  };

  /**
   * Continuous analysis. cb receives { engine, depth, lines: [{ cp | mate, pv }] } with scores from the side to move.
   * Call HCC.stopAnalysis() before leaving the screen.
   */
  HCC.analyse = function (fen, moves, cb) {
    HCC.stopAnalysis();
    if (sf.state === 'ready') {
      var lines = [];
      sf.request({
        fen: fen, moves: moves, go: 'go depth 22', options: { MultiPV: 3, 'Skill Level': 20 },
        onInfo: function (i) {
          lines[i.multipv - 1] = i;
          cb({ engine: sf.name, depth: i.depth, lines: lines.filter(Boolean) });
        }
      });
      return;
    }
    local.cancel();
    local.go({ fen: fen, moves: moves, depth: 12, movetime: 5000 }, function (r) {
      cb({ engine: '', depth: r.depth, lines: [r] });
    }).catch(function () { /* cancelled */ });
  };
  HCC.stopAnalysis = function () {
    if (sf.state === 'ready') sf.stop();
    local.cancel();
  };
})(window);
