/* Hashem Chess Puzzle — screens: home, lessons, puzzles, play, analysis, settings. */
(function (root) {
  'use strict';
  var HCC = root.HCC, C = root.HCChess, h = HCC.h, t = HCC.t, pick = HCC.pick, store = HCC.store, content = HCC.content, icon = HCC.icon;
  var TABS = [['home', 'home'], ['lessons', 'book'], ['puzzles', 'bolt'], ['play', 'pawn'], ['analysis', 'chart']];
  var topEl, mainEl, tabsEl, sheetEl = null;
  var state = { tab: 'home', lessons: { track: 'educational', course: null, unit: -1 }, pzFilter: 'all', analysis: null, cleanup: null, backFn: null };

  // ---------------------------------------------------------------- shell
  function btn(label, cls, onclick, ic) {
    return h('button', { type: 'button', class: 'btn' + (cls ? ' ' + cls : ''), onclick: onclick }, ic ? icon(ic) : null, label);
  }
  function iconBtn(ic, label, onclick, cls) {
    return h('button', { type: 'button', class: 'icon-btn', 'aria-label': label, title: label, onclick: onclick }, icon(ic, cls));
  }
  function setTop(o) {
    HCC.clear(topEl);
    state.backFn = o && o.back || null;
    if (o && o.back) {
      topEl.appendChild(iconBtn('back', t('close'), o.back, 'flip-rtl'));
      topEl.appendChild(h('div', { class: 'title', text: o.title || '' }));
    } else {
      topEl.appendChild(HCC.mark());
      topEl.appendChild(h('div', { class: 'name ltr', text: HCC.APP.name }));
    }
    topEl.appendChild(h('button', { type: 'button', class: 'lang-btn', 'aria-label': t('language'), text: store.data.lang === 'ar' ? 'EN' : 'ع', onclick: function () {
      store.data.lang = store.data.lang === 'ar' ? 'en' : 'ar'; store.save(); HCC.applyLang(); renderTabs(); render();
    } }));
    topEl.appendChild(iconBtn('sliders', t('settings'), settingsSheet));
  }
  function renderTabs() {
    HCC.clear(tabsEl);
    TABS.forEach(function (tab) {
      tabsEl.appendChild(h('button', { type: 'button', 'aria-current': state.tab === tab[0] ? 'page' : null, onclick: function () { go(tab[0]); } }, icon(tab[1]), h('span', { text: t(tab[0]) })));
    });
  }
  function go(tab) {
    if (state.tab === tab) { if (tab === 'lessons') { state.lessons.course = null; state.lessons.unit = -1; } render(); return; }
    state.tab = tab;
    try { if (location.hash !== '#' + tab) location.hash = tab; } catch (e) { /* hash not available */ }
    renderTabs(); render();
  }
  function leave() {
    if (state.cleanup) { try { state.cleanup(); } catch (e) { /* ignore */ } state.cleanup = null; }
    state.backFn = null;
  }
  function render() {
    leave();
    document.body.className = store.data.theme && store.data.theme !== 'blue' ? 'theme-' + store.data.theme : '';
    HCC.clear(mainEl); mainEl.scrollTop = 0;
    ({ home: homeView, lessons: lessonsView, puzzles: puzzlesView, play: playView, analysis: analysisView }[state.tab] || homeView)();
  }
  function timersBox() {
    var ids = [];
    return { later: function (fn, ms) { ids.push(setTimeout(fn, ms)); }, clear: function () { ids.forEach(clearTimeout); ids = []; } };
  }
  function stars(n) { return '★★★'.slice(0, n) + '☆☆☆'.slice(0, 3 - n); }
  function chev() { return icon('next', 'chev flip-rtl'); }
  function bar(done, total) { return h('div', { class: 'bar' }, h('i', { style: 'width:' + (total ? Math.round(done / total * 100) : 0) + '%' })); }
  function sayBox() {
    var el = h('div', { class: 'say', 'aria-live': 'polite' });
    el.say = function (kind, text, who) {
      el.className = 'say' + (kind ? ' ' + kind : '');
      HCC.clear(el);
      el.appendChild(h('span', { class: 'who', text: who || t('coach') }));
      el.appendChild(document.createTextNode(text || ''));
    };
    return el;
  }
  function moveFromUci(u) { return C.sqIndex(u.slice(0, 2)) | (C.sqIndex(u.slice(2, 4)) << 7); }

  // ---------------------------------------------------------------- home
  function homeView() {
    setTop();
    var next = content.nextUnit(), pz = store.data.puzzle, page = h('div', { class: 'page' });
    var started = Object.keys(store.data.progress).length > 0;
    if (next) {
      var pr = content.progressOf(next.course.units);
      page.appendChild(h('section', { class: 'hero' },
        h('span', { class: 'eyebrow', text: t(started ? 'continueLearning' : 'startLearning') }),
        h('h2', { text: pick(next.course.units[next.index].title) }),
        h('p', { class: 'muted', text: pick(next.course.title) + ' · ' + (next.index + 1) + ' ' + t('of') + ' ' + pr.total }),
        bar(pr.done, pr.total),
        h('div', { class: 'btns' }, btn(t('start'), 'primary', function () { state.lessons = { track: next.course.track, course: next.course, unit: next.index }; go('lessons'); }))));
    } else {
      page.appendChild(h('section', { class: 'hero' }, h('span', { class: 'eyebrow', text: t('lessons') }), h('h2', { text: t('allDone') }),
        h('div', { class: 'btns' }, btn(t('review'), 'primary', function () { go('lessons'); }))));
    }
    page.appendChild(h('div', { class: 'grid2' },
      h('button', { type: 'button', class: 'card tap', style: 'flex-direction:column;align-items:flex-start;gap:4px', onclick: function () { go('puzzles'); } },
        h('span', { class: 'eyebrow', text: t('puzzleRating') }), h('span', { class: 'big', text: String(pz.rating) }),
        h('span', { class: 'muted', text: pz.solved + ' ' + t('solved') })),
      h('button', { type: 'button', class: 'card tap', style: 'flex-direction:column;align-items:flex-start;gap:4px', onclick: function () { go('play'); } },
        h('span', { class: 'eyebrow', text: t('play') }), h('h3', { text: t('playComputer') }), h('span', { class: 'muted', text: t('playSub') }))));
    [['educational', 'trackEdu', 'trackEduSub'], ['competitive', 'trackComp', 'trackCompSub']].forEach(function (tr) {
      var units = [];
      content.track(tr[0]).forEach(function (c) { units = units.concat(c.units); });
      var p = content.progressOf(units);
      page.appendChild(h('button', { type: 'button', class: 'card tap', onclick: function () { state.lessons = { track: tr[0], course: null, unit: -1 }; go('lessons'); } },
        h('div', { class: 'grow', style: 'display:flex;flex-direction:column;gap:6px' },
          h('h3', { text: t(tr[1]) }), h('span', { class: 'muted', text: t(tr[2]) }), bar(p.done, p.total),
          h('span', { class: 'muted', text: p.done + ' ' + t('of') + ' ' + p.total + ' ' + t('units') })), chev()));
    });
    page.appendChild(h('button', { type: 'button', class: 'card tap', onclick: function () { go('analysis'); } },
      h('div', { class: 'grow' }, h('h3', { text: t('analysisBoard') }), h('span', { class: 'muted', text: t('analysisSub') })), chev()));
    page.appendChild(h('p', { class: 'muted center', text: t('tagline') }));
    mainEl.appendChild(page);
  }

  // ---------------------------------------------------------------- lessons
  function lessonsView() {
    var L = state.lessons;
    if (L.course && L.unit >= 0 && L.course.units[L.unit]) return lessonPlayer(L.course, L.unit);
    if (L.course) return courseView(L.course);
    setTop();
    var page = h('div', { class: 'page' });
    page.appendChild(h('div', { class: 'seg', role: 'group' },
      h('button', { type: 'button', 'aria-pressed': String(L.track === 'educational'), text: t('trackEdu'), onclick: function () { L.track = 'educational'; render(); } }),
      h('button', { type: 'button', 'aria-pressed': String(L.track === 'competitive'), text: t('trackComp'), onclick: function () { L.track = 'competitive'; render(); } })));
    page.appendChild(h('p', { class: 'muted', text: t(L.track === 'educational' ? 'trackEduSub' : 'trackCompSub') }));
    var courses = content.track(L.track);
    if (!courses.length) page.appendChild(h('div', { class: 'note', text: t('noLessons') }));
    courses.forEach(function (c) {
      var p = content.progressOf(c.units);
      page.appendChild(h('button', { type: 'button', class: 'card tap', onclick: function () { L.course = c; L.unit = -1; render(); } },
        h('div', { class: 'grow', style: 'display:flex;flex-direction:column;gap:6px' },
          h('h3', { text: pick(c.title) }), bar(p.done, p.total),
          h('span', { class: 'muted', text: p.done + ' ' + t('of') + ' ' + p.total + ' ' + t('units') })), chev()));
    });
    mainEl.appendChild(page);
  }

  function courseView(course) {
    var L = state.lessons;
    setTop({ title: pick(course.title), back: function () { L.course = null; render(); } });
    var list = h('div', { class: 'list' }), prog = store.data.progress;
    course.units.forEach(function (u, i) {
      var st = prog[u.id] || 0;
      list.appendChild(h('button', { type: 'button', class: 'unit' + (st ? ' done' : ''), onclick: function () { L.unit = i; render(); } },
        h('span', { class: 'num' }, st ? icon('check') : String(i + 1)),
        h('span', { class: 'grow', text: pick(u.title) }),
        st ? h('span', { class: 'stars', text: stars(st) }) : chev()));
    });
    list.querySelectorAll('.num svg').forEach(function (s) { s.setAttribute('style', 'width:16px;height:16px;fill:none;stroke:currentColor;stroke-width:3;stroke-linecap:round;stroke-linejoin:round'); });
    mainEl.appendChild(h('div', { class: 'page' }, list));
  }

  function lessonPlayer(course, index) {
    var L = state.lessons, unit = course.units[index], line = unit.line, chess = new C.Chess(unit.fen);
    var i = 0, mistakes = 0, hints = 0, hintStage = 0, locked = true, prompt = { text: '', arrows: [], marks: [] }, T = timersBox();
    setTop({ title: pick(unit.title), back: function () { L.unit = -1; render(); } });
    state.cleanup = T.clear;
    var host = h('div'), board = new HCC.Board(host, { onMove: onUser });
    var statusEl = h('div', { class: 'status' }), say = sayBox(), btns = h('div', { class: 'btns' }), resultEl = h('div');
    board.chess = chess; board.setOrient(unit.heroWhite ? 'w' : 'b'); HCC._board = board;
    mainEl.appendChild(h('div', { class: 'work' }, h('div', { class: 'board-wrap' }, host), statusEl, say, btns, resultEl));

    function status(note) {
      HCC.clear(statusEl);
      statusEl.appendChild(h('span', { class: 'dot ' + (unit.heroWhite ? 'w' : 'b') }));
      statusEl.appendChild(h('span', { class: 'grow', text: unit.watch ? pick(course.title) : t(unit.heroWhite ? 'youWhite' : 'youBlack') }));
      if (note) statusEl.appendChild(h('span', { class: 'pill bad', text: note }));
      statusEl.appendChild(h('span', { class: 'pill ltr', text: Math.min(i, line.length) + ' / ' + line.length }));
    }
    function buttons(list) { HCC.clear(btns); list.forEach(function (b) { btns.appendChild(b); }); }
    function showPrompt(text, arrows, marks) {
      prompt = { text: text, arrows: arrows || [], marks: marks || [] };
      say.say('', text || t(unit.watch ? 'watch' : 'yourMove'));
      board.draw(prompt.arrows, prompt.marks);
    }
    function waitUser() {
      locked = false; hintStage = 0; board.hintSq = -1;
      board.movable = unit.heroWhite ? 'w' : 'b';
      board.paint();
      buttons([btn(t('hint'), '', hint, 'bulb')]);
    }
    function hint() {
      if (locked || i >= line.length) return;
      var m = line[i].m;
      hints++; hintStage++;
      if (hintStage === 1) board.setHint(C.mFrom(m));
      else board.draw(prompt.arrows.concat([{ color: 'B', from: C.sqName(C.mFrom(m)), to: C.sqName(C.mTo(m)) }]), prompt.marks);
    }
    /** Plays the next lesson move for the opponent (or for either side in watch mode). */
    function autoMove() {
      var node = line[i];
      locked = true; board.movable = null; board.hintSq = -1;
      chess.make(node.m); i++;
      board.arrows = []; board.marks = [];
      board.update({ last: node.m, animate: true });
      status();
      var text = pick(node.comment);
      if (i >= line.length) { if (text) say.say('', text); board.draw(node.arrows, node.marks); finish(); return; }
      showPrompt(unit.watch ? (text || node.san) : text, node.arrows, node.marks);
      if (unit.watch) buttons([btn(t('cont'), 'primary', autoMove)]); else waitUser();
    }
    function accept(m, arrows, marks) {
      chess.make(m);
      locked = true; board.movable = null; board.hintSq = -1;
      board.arrows = arrows || []; board.marks = marks || [];
      board.update({ last: m, animate: true }); board.blink(C.mTo(m), 'good');
    }
    function onUser(m) {
      if (locked || i >= line.length) return;
      var node = line[i], text;
      if (m === node.m) {
        accept(m, node.arrows, node.marks); i++; status();
        text = pick(node.comment);
        if (i >= line.length) { say.say('good', text || t('wellDone'), t('right')); finish(); return; }
        if (text) { say.say('good', text, t('right')); buttons([btn(t('cont'), 'primary', autoMove)]); }
        else { buttons([]); T.later(autoMove, 450); }
        return;
      }
      var v = node.vars.filter(function (x) { return x.length && x[0].m === m; })[0];
      var bad = v && (v[0].nag === 2 || v[0].nag === 4 || v[0].nag === 6);
      if (v && !bad) {
        text = pick(v[0].comment);
        if (i === line.length - 1) { accept(m, v[0].arrows, v[0].marks); i = line.length; status(); say.say('good', text || t('wellDone'), t('right')); finish(); }
        else { board.update(); say.say('', (text ? text + ' ' : '') + t('alsoGood')); }
        return;
      }
      mistakes++;
      if (!v) { board.update(); board.blink(C.mTo(m), 'bad'); status(t('notLessonMove')); return; }
      // An annotated mistake: play it and its punishment, then let the student try again.
      var prevLast = i > 0 ? line[i - 1].m : 0, made = 0, k = 0;
      locked = true; board.movable = null; buttons([]);
      (function playVar() {
        var n = v[k], vt = pick(n.comment);
        chess.make(n.m); made++;
        board.arrows = n.arrows; board.marks = n.marks;
        board.update({ last: n.m, animate: true });
        if (k === 0) board.blink(C.mTo(n.m), 'bad');
        if (vt || k === 0) say.say('bad', vt || t('notLessonMove'), t('wrong'));
        k++;
        if (k < v.length) { T.later(playVar, 1000); return; }
        buttons([btn(t('retry'), 'primary', function () {
          while (made-- > 0) chess.undo();
          board.arrows = []; board.marks = [];
          board.update({ last: prevLast });
          showPrompt(prompt.text, prompt.arrows, prompt.marks); status(); waitUser();
        }, 'undo')]);
      })();
    }
    function finish() {
      locked = true; board.movable = null; buttons([]);
      var st = mistakes + hints === 0 ? 3 : (mistakes + hints <= 2 ? 2 : 1);
      if (st > (store.data.progress[unit.id] || 0)) store.data.progress[unit.id] = st;
      store.save();
      var actions = h('div', { class: 'btns' });
      if (index + 1 < course.units.length) actions.appendChild(btn(t('nextLesson'), 'primary', function () { L.unit = index + 1; render(); }));
      actions.appendChild(btn(t('restart'), '', function () { render(); }, 'redo'));
      actions.appendChild(btn(t('backToList'), '', function () { L.unit = -1; render(); }));
      HCC.clear(resultEl);
      resultEl.appendChild(h('div', { class: 'result' }, h('h3', { text: t('lessonDone') }), h('div', { class: 'stars', text: stars(st) }), actions));
      T.later(function () { resultEl.scrollIntoView({ block: 'end', behavior: 'smooth' }); }, 150);
    }

    board.update(); status();
    var intro = pick(unit.intro);
    var heroFirst = !unit.watch && ((chess.turn === 0) === unit.heroWhite);
    showPrompt(intro, unit.introArrows, unit.introMarks);
    if (!line.length) { finish(); return; }
    if (heroFirst) waitUser();
    else if (intro || unit.watch) buttons([btn(t('cont'), 'primary', autoMove)]);
    else T.later(autoMove, 600);
  }

  // ---------------------------------------------------------------- puzzles
  // Lichess theme keys, grouped for the theme picker. [Arabic, English]
  var THEME_GROUPS = [
    ['tactics', ['تكتيك', 'Tactics'], {
      fork: ['الشوكة', 'Fork'], pin: ['التسمير', 'Pin'], skewer: ['السيخ', 'Skewer'],
      discoveredAttack: ['الهجوم المكشوف', 'Discovered attack'], doubleCheck: ['الكش المزدوج', 'Double check'],
      hangingPiece: ['قطعة بلا حماية', 'Hanging piece'], trappedPiece: ['قطعة محاصرة', 'Trapped piece'],
      sacrifice: ['التضحية', 'Sacrifice'], deflection: ['إبعاد المدافع', 'Deflection'], attraction: ['الجذب', 'Attraction'],
      capturingDefender: ['أسر المدافع', 'Capture the defender'], interference: ['التداخل', 'Interference'],
      clearance: ['إخلاء الطريق', 'Clearance'], xRayAttack: ['هجوم الأشعة', 'X-ray attack'],
      intermezzo: ['النقلة الوسيطة', 'Intermezzo'], quietMove: ['النقلة الهادئة', 'Quiet move'],
      zugzwang: ['إجبار النقلة (زوجزوانج)', 'Zugzwang'], defensiveMove: ['نقلة دفاعية', 'Defensive move'],
      exposedKing: ['ملك مكشوف', 'Exposed king'], kingsideAttack: ['هجوم على جناح الملك', 'Kingside attack'],
      queensideAttack: ['هجوم على جناح الوزير', 'Queenside attack'], attackingF2F7: ['الهجوم على f2 و f7', 'Attacking f2/f7'],
      advancedPawn: ['بيدق متقدم', 'Advanced pawn'], promotion: ['الترقية', 'Promotion'],
      underPromotion: ['الترقية لقطعة أقل', 'Underpromotion'], enPassant: ['الأخذ بالتجاوز', 'En passant'], castling: ['التبييت', 'Castling']
    }],
    ['mates', ['كش مات', 'Checkmates'], {
      mate: ['كل أنواع المات', 'Any checkmate'], mateIn1: ['مات في نقلة', 'Mate in 1'], mateIn2: ['مات في نقلتين', 'Mate in 2'],
      mateIn3: ['مات في 3 نقلات', 'Mate in 3'], mateIn4: ['مات في 4 نقلات', 'Mate in 4'], mateIn5: ['مات في 5 نقلات أو أكثر', 'Mate in 5+'],
      backRankMate: ['مات الصف الأخير', 'Back-rank mate'], smotheredMate: ['المات المخنوق', 'Smothered mate'],
      anastasiaMate: ['مات أناستازيا', 'Anastasia mate'], arabianMate: ['المات العربي', 'Arabian mate'],
      bodenMate: ['مات بودن', 'Boden mate'], doubleBishopMate: ['مات الفيلين', 'Double bishop mate'],
      dovetailMate: ['مات ذيل الحمامة', 'Dovetail mate'], hookMate: ['مات الخطّاف', 'Hook mate']
    }],
    ['phases', ['مراحل المباراة', 'Game phase'], {
      opening: ['الافتتاح', 'Opening'], middlegame: ['وسط المباراة', 'Middlegame'], endgame: ['النهايات', 'Endgame']
    }],
    ['endings', ['أنواع النهايات', 'Endgame types'], {
      pawnEndgame: ['نهايات البيادق', 'Pawn endgame'], rookEndgame: ['نهايات الطوابي', 'Rook endgame'],
      bishopEndgame: ['نهايات الأفيال', 'Bishop endgame'], knightEndgame: ['نهايات الأحصنة', 'Knight endgame'],
      queenEndgame: ['نهايات الوزير', 'Queen endgame'], queenRookEndgame: ['نهايات الوزير والطابية', 'Queen and rook endgame']
    }],
    ['length', ['طول الحل', 'Solution length'], {
      oneMove: ['نقلة واحدة', 'One move'], short: ['قصير (نقلتان)', 'Short'], long: ['طويل (3 نقلات)', 'Long'], veryLong: ['طويل جدًا', 'Very long']
    }]
  ];
  var THEME_LABEL = {};
  THEME_GROUPS.forEach(function (g) { for (var k in g[2]) THEME_LABEL[k] = g[2][k]; });
  // Levels by puzzle rating. [min, max) and [Arabic, English]
  var LEVELS = [
    [0, 800, ['مبتدئ', 'Beginner']], [800, 1100, ['سهل', 'Easy']], [1100, 1400, ['متوسط', 'Intermediate']],
    [1400, 1700, ['فوق المتوسط', 'Upper intermediate']], [1700, 2000, ['متقدم', 'Advanced']],
    [2000, 2300, ['قوي', 'Strong']], [2300, 9999, ['خبير', 'Expert']]
  ];
  function lang2(pair) { return pair[store.data.lang === 'ar' ? 0 : 1]; }
  function themeName(k) { var l = THEME_LABEL[k]; return l ? lang2(l) : k; }
  function levelOf(r) { for (var i = 0; i < LEVELS.length; i++) if (r < LEVELS[i][1]) return i; return LEVELS.length - 1; }

  function puzzlesView() {
    setTop();
    var pz = store.data.puzzle, all = content.puzzles, T = timersBox(), token = 0;
    var cur = null, chess = null, idx = 0, rated = false, failed = false, locked = true, hintStage = 0, shown = 0, side = 'w';
    state.cleanup = function () { T.clear(); token++; };
    if (state.pzLevel === undefined) state.pzLevel = store.data.pzLevel === undefined ? 'auto' : store.data.pzLevel;
    if (state.pzFilter === 'all' && store.data.pzFilter) state.pzFilter = store.data.pzFilter;
    var counts = {};
    all.forEach(function (p) { p.themes.forEach(function (th) { if (THEME_LABEL[th]) counts[th] = (counts[th] || 0) + 1; }); });
    if (state.pzFilter !== 'all' && !counts[state.pzFilter]) state.pzFilter = 'all';

    var ratingEl = h('span', { class: 'big' }), statsEl = h('div', { class: 'row wrap' });
    var themeSel = h('select', { id: 'pz-theme', 'aria-label': t('pzTheme') }), levelSel = h('select', { id: 'pz-level', 'aria-label': t('pzLevel') });
    var poolEl = h('div', { class: 'muted' });
    var host = h('div'), board = new HCC.Board(host, { onMove: onUser }), statusEl = h('div', { class: 'status' }), say = sayBox(), btns = h('div', { class: 'btns' });
    HCC._board = board;
    mainEl.appendChild(h('div', { class: 'work' },
      h('div', { class: 'row' }, h('div', { class: 'grow' }, h('span', { class: 'eyebrow', text: t('puzzleRating') }), h('div', null, ratingEl)), statsEl),
      h('div', { class: 'pz-filters' },
        h('label', { class: 'field', for: 'pz-theme' }, h('span', { text: t('pzTheme') }), themeSel),
        h('label', { class: 'field', for: 'pz-level' }, h('span', { text: t('pzLevel') }), levelSel)),
      poolEl, h('div', { class: 'board-wrap' }, host), statusEl, say, btns));

    function header(delta) {
      ratingEl.textContent = String(pz.rating);
      HCC.clear(statsEl);
      if (delta) statsEl.appendChild(h('span', { class: 'pill ltr ' + (delta > 0 ? 'good' : 'bad'), text: (delta > 0 ? '+' : '') + delta }));
      statsEl.appendChild(h('span', { class: 'pill', text: pz.solved + ' ' + t('solved') }));
      if (pz.streak > 1) statsEl.appendChild(h('span', { class: 'pill accent', text: t('streak') + ' ' + pz.streak }));
    }
    function byTheme() { return state.pzFilter === 'all' ? all : all.filter(function (p) { return p.themes.indexOf(state.pzFilter) >= 0; }); }
    function renderFilters() {
      HCC.clear(themeSel);
      themeSel.appendChild(h('option', { value: 'all', text: t('all') + ' (' + all.length + ')' }));
      THEME_GROUPS.forEach(function (g) {
        var og = h('optgroup', { label: lang2(g[1]) });
        Object.keys(g[2]).forEach(function (k) { if (counts[k]) og.appendChild(h('option', { value: k, text: themeName(k) + ' (' + counts[k] + ')' })); });
        if (og.children.length) themeSel.appendChild(og);
      });
      themeSel.value = state.pzFilter;
      var levelCounts = LEVELS.map(function () { return 0; });
      byTheme().forEach(function (p) { levelCounts[levelOf(p.rating)]++; });
      HCC.clear(levelSel);
      levelSel.appendChild(h('option', { value: 'auto', text: t('pzAuto') }));
      LEVELS.forEach(function (L, i) {
        if (!levelCounts[i]) return;
        var range = i === LEVELS.length - 1 ? L[0] + '+' : L[0] + '–' + (L[1] - 1);
        levelSel.appendChild(h('option', { value: String(i), text: lang2(L[2]) + ' \u2066' + range + '\u2069 (' + levelCounts[i] + ')' }));
      });
      if (state.pzLevel !== 'auto' && !levelCounts[+state.pzLevel]) state.pzLevel = 'auto';
      levelSel.value = String(state.pzLevel);
      renderPoolInfo();
    }
    function renderPoolInfo() {
      var list = pool(), done = 0;
      list.forEach(function (p) { if (pz.done[p.id]) done++; });
      poolEl.textContent = t('pzProgress', { d: done, n: list.length });
    }
    themeSel.addEventListener('change', function () { state.pzFilter = themeSel.value; store.data.pzFilter = state.pzFilter; store.save(); renderFilters(); nextPuzzle(); });
    levelSel.addEventListener('change', function () { state.pzLevel = levelSel.value; store.data.pzLevel = state.pzLevel; store.save(); renderPoolInfo(); nextPuzzle(); });
    function pool() {
      var list = byTheme();
      if (state.pzLevel === 'auto') return list;
      var L = LEVELS[+state.pzLevel];
      return list.filter(function (p) { return p.rating >= L[0] && p.rating < L[1]; });
    }
    function choose() {
      var list = pool();
      if (!list.length) return null;
      var fresh = list.filter(function (p) { return !pz.done[p.id] && (!cur || p.id !== cur.id); });
      if (!fresh.length) fresh = list.filter(function (p) { return !cur || p.id !== cur.id; });
      if (!fresh.length) fresh = list;
      if (state.pzLevel !== 'auto') return fresh[Math.floor(Math.random() * fresh.length)];
      var target = pz.rating + Math.random() * 160 - 80;
      fresh = fresh.slice().sort(function (a, b) { return Math.abs(a.rating - target) - Math.abs(b.rating - target); });
      return fresh[Math.floor(Math.random() * Math.min(6, fresh.length))];
    }
    function goalText() {
      var n = 0;
      cur.themes.forEach(function (th) { var m = /^mateIn(\d)$/.exec(th); if (m) n = +m[1]; });
      return n ? t('mateIn', { n: n }) : t('findBest');
    }
    function status() {
      HCC.clear(statusEl);
      statusEl.appendChild(h('span', { class: 'dot ' + side }));
      statusEl.appendChild(h('span', { class: 'grow', text: t(side === 'w' ? 'whiteToMove' : 'blackToMove') }));
      statusEl.appendChild(h('span', { class: 'pill accent', text: goalText() }));
      statusEl.appendChild(h('span', { class: 'pill ltr', text: String(cur.rating) }));
    }
    function buttons(done) {
      HCC.clear(btns);
      if (!done) { btns.appendChild(btn(t('hint'), '', hint, 'bulb')); btns.appendChild(btn(t('solution'), '', solution, 'eye')); }
      btns.appendChild(btn(t('nextPuzzle'), done ? 'primary' : '', nextPuzzle));
    }
    function rate(win) {
      if (rated) return 0;
      rated = true;
      var exp = 1 / (1 + Math.pow(10, (cur.rating - pz.rating) / 400)), k = pz.solved + pz.failed < 20 ? 40 : 20;
      var delta = Math.round(k * ((win ? 1 : 0) - exp));
      if (win && delta < 1) delta = 1;
      pz.rating = Math.max(100, pz.rating + delta);
      if (win) { pz.solved++; pz.streak++; } else { pz.failed++; pz.streak = 0; failed = true; }
      if (pz.rating > pz.best) pz.best = pz.rating;
      pz.done[cur.id] = win ? 1 : 2;
      renderPoolInfo();
      store.save(); header(delta);
      return delta;
    }
    function nextPuzzle() {
      T.clear(); token++;
      var p = choose();
      if (!p) { cur = null; HCC.clear(statusEl); HCC.clear(btns); say.say('', t('noPuzzles')); board.chess = new C.Chess('8/8/8/8/8/8/8/8 w - - 0 1'); board.movable = null; board.lastMove = 0; board.update(); return; }
      cur = p; chess = new C.Chess(p.fen); idx = 0; rated = false; failed = false; hintStage = 0;
      side = chess.turn === 0 ? 'w' : 'b';
      board.chess = chess; board.setOrient(side); board.arrows = []; board.marks = []; board.hintSq = -1;
      shown = p.last ? moveFromUci(p.last) : 0;
      board.update({ last: shown });
      locked = false; board.movable = side;
      status(); say.say('', goalText() + '.'); buttons(false); header();
    }
    function complete() {
      locked = true; board.movable = null; board.hintSq = -1; board.paint();
      rate(true);
      say.say(failed ? '' : 'good', t(failed ? 'puzzleFailed' : 'puzzleSolved'), failed ? t('solution') : t('right'));
      buttons(true);
    }
    function reply() {
      var m = chess.play(cur.moves[idx]);
      idx++; shown = m;
      board.update({ last: m, animate: true });
    }
    function onUser(m) {
      if (locked || !cur) return;
      var want = cur.moves[idx], mine = token;
      chess.make(m);
      var mate = chess.isCheckmate();
      board.hintSq = -1; board.arrows = [];
      if (C.uci(m) === want || mate) {
        shown = m; idx++;
        board.update({ last: m, animate: true }); board.blink(C.mTo(m), 'good');
        if (mate || idx >= cur.moves.length) { complete(); return; }
        locked = true; board.movable = null;
        T.later(function () { reply(); locked = false; board.movable = side; }, 500);
        return;
      }
      rate(false);
      locked = true; board.movable = null;
      board.update({ last: m, animate: true }); board.blink(C.mTo(m), 'bad');
      function rewind(n) {
        while (n-- > 0) chess.undo();
        board.arrows = [];
        board.update({ last: shown });
        locked = false; board.movable = side;
      }
      if (chess.gameOver()) { say.say('bad', t('notBest'), t('wrong')); T.later(function () { rewind(1); }, 1000); return; }
      HCC.quickReply(chess.fen()).then(function (u) {
        if (mine !== token) return;
        var rm = u && chess.parseMove(u);
        if (!rm) { say.say('bad', t('notBest'), t('wrong')); rewind(1); return; }
        var san = chess.san(rm);
        chess.make(rm);
        board.arrows = [{ color: 'R', from: u.slice(0, 2), to: u.slice(2, 4) }];
        board.update({ last: rm, animate: true });
        say.say('bad', t('refuted', { m: san }), t('wrong'));
        T.later(function () { rewind(2); }, 1700);
      }).catch(function () { if (mine === token) { say.say('bad', t('notBest'), t('wrong')); rewind(1); } });
    }
    function hint() {
      if (locked || !cur) return;
      rate(false);
      var u = cur.moves[idx];
      hintStage++;
      if (hintStage === 1) board.setHint(C.sqIndex(u.slice(0, 2)));
      else board.draw([{ color: 'B', from: u.slice(0, 2), to: u.slice(2, 4) }], []);
    }
    function solution() {
      if (locked || !cur) return;
      rate(false);
      locked = true; board.movable = null; board.hintSq = -1; board.arrows = [];
      say.say('', t('showing'), t('solution'));
      HCC.clear(btns);
      (function step() {
        if (idx >= cur.moves.length || chess.gameOver()) { buttons(true); return; }
        reply();
        T.later(step, 900);
      })();
    }
    renderFilters(); header(); nextPuzzle();
  }

  // ---------------------------------------------------------------- play
  function playView() {
    setTop();
    var g = store.data.play;
    if (!g) return playSetup();
    var chess, T = timersBox(), token = 0;
    try { chess = new C.Chess(g.fen); g.moves.forEach(function (u) { if (!chess.play(u)) throw new Error('bad move'); }); }
    catch (e) { store.data.play = null; store.save(); return playSetup(); }
    state.cleanup = function () { T.clear(); token++; };
    var host = h('div'), board = new HCC.Board(host, { onMove: onUser });
    var statusEl = h('div', { class: 'status' }), movesEl = h('div', { class: 'moves' }), btns = h('div', { class: 'btns' }), resultEl = h('div');
    board.chess = chess; board.setOrient(g.you); HCC._board = board;
    mainEl.appendChild(h('div', { class: 'work' }, statusEl, h('div', { class: 'board-wrap' }, host), movesEl, btns, resultEl));

    function myTurn() { return (chess.turn === 0) === (g.you === 'w'); }
    function sanList() {
      var c = new C.Chess(g.fen), out = [];
      g.moves.forEach(function (u) { var m = c.parseMove(u); out.push(c.san(m)); c.make(m); });
      return { list: out, blackFirst: g.fen.split(' ')[1] === 'b', first: parseInt(g.fen.split(' ')[5], 10) || 1 };
    }
    function drawMoves() {
      var s = sanList();
      HCC.clear(movesEl);
      s.list.forEach(function (san, k) {
        var ply = k + (s.blackFirst ? 1 : 0);
        if (ply % 2 === 0 || k === 0) movesEl.appendChild(h('span', { class: 'n', text: (s.first + Math.floor(ply / 2)) + (ply % 2 ? '…' : '.') }));
        movesEl.appendChild(h('span', { class: 'm' + (k === s.list.length - 1 ? ' cur' : ''), text: san }));
      });
      movesEl.scrollTop = movesEl.scrollHeight;
    }
    function status(text, cls) {
      HCC.clear(statusEl);
      statusEl.appendChild(h('span', { class: 'dot ' + (chess.turn === 0 ? 'w' : 'b') }));
      statusEl.appendChild(h('span', { class: 'grow', text: text }));
      statusEl.appendChild(h('span', { class: 'pill' + (cls ? ' ' + cls : ''), text: t('level') + ' ' + g.level + ' · ' + t('lvl' + g.level) }));
    }
    function buttons(over) {
      HCC.clear(btns);
      if (!over) {
        btns.appendChild(btn(t('takeback'), '', takeback, 'undo'));
        btns.appendChild(btn(t('resign'), 'danger', function () { g.result = 'resign'; store.save(); sync(); }, 'flag'));
      }
      btns.appendChild(btn(t('flipBoard'), '', function () { board.flip(); }, 'flip'));
      if (over) btns.appendChild(btn(t('newGame'), 'primary', function () { store.data.play = null; store.save(); render(); }));
    }
    function showResult(over) {
      var title, why;
      if (over === 'resign') { title = t('youLose'); why = t('byResign'); }
      else if (over === 'checkmate') { title = t(myTurn() ? 'youLose' : 'youWin'); why = t('byMate'); }
      else { title = t('draw'); why = t({ stalemate: 'byStalemate', repetition: 'byRepetition', fifty: 'byFifty', material: 'byMaterial' }[over]); }
      HCC.clear(resultEl);
      resultEl.appendChild(h('div', { class: 'result' }, h('h3', { text: title }), h('p', { text: why }),
        h('div', { class: 'btns' }, btn(t('analyseGame'), 'primary', function () {
          state.analysis = { fen: g.fen, moves: g.moves.slice(), cursor: g.moves.length, engine: true };
          go('analysis');
        }, 'chart'))));
      status(t('gameOver'));
    }
    function sync() {
      drawMoves();
      var over = g.result || chess.gameOver();
      HCC.clear(resultEl);
      if (over) { board.movable = null; board.paint(); buttons(true); showResult(over); return; }
      buttons(false);
      if (myTurn()) { board.movable = g.you; board.paint(); status(t('yourTurn')); }
      else think();
    }
    function think() {
      var mine = ++token, t0 = Date.now();
      board.movable = null; board.paint();
      status(t('thinking'));
      HCC.engineMove(g.fen, g.moves.slice(), g.level).then(function (u) {
        if (mine !== token || !u) return;
        T.later(function () {
          if (mine !== token) return;
          var m = chess.play(u);
          if (!m) return;
          g.moves.push(u); store.save();
          board.update({ last: m, animate: true });
          sync();
        }, Math.max(0, 450 - (Date.now() - t0)));
      }).catch(function () { /* engine restarted: sync() runs again when the screen is rebuilt */ });
    }
    function onUser(m) {
      if (!myTurn() || g.result) return;
      g.moves.push(C.uci(m)); chess.make(m); store.save();
      board.update({ last: m, animate: true });
      sync();
    }
    function takeback() {
      if (!g.moves.length) return;
      token++; T.clear();
      var n = myTurn() ? 2 : 1;
      if (g.moves.length < n) n = g.moves.length;
      while (n-- > 0) { chess.undo(); g.moves.pop(); }
      if (!myTurn() && g.moves.length) { chess.undo(); g.moves.pop(); }
      store.save();
      var hist = chess.history();
      board.update({ last: hist.length ? hist[hist.length - 1] : 0 });
      sync();
    }
    var hist0 = chess.history();
    board.update({ last: hist0.length ? hist0[hist0.length - 1] : 0 });
    sync();
  }

  function playSetup() {
    var choice = { color: 'w', level: (store.data.lastLevel || 2) }, maxLevel = HCC.sf.state === 'ready' ? 8 : 6;
    if (choice.level > maxLevel) choice.level = maxLevel;
    var page = h('div', { class: 'page' }), seg = h('div', { class: 'seg', role: 'group' }), levelName = h('strong'), levelNote = h('span', { class: 'pill accent ltr' });
    function drawSeg() {
      HCC.clear(seg);
      [['w', 'white'], ['b', 'black'], ['r', 'random']].forEach(function (o) {
        seg.appendChild(h('button', { type: 'button', 'aria-pressed': String(choice.color === o[0]), text: t(o[1]), onclick: function () { choice.color = o[0]; drawSeg(); } }));
      });
    }
    function drawLevel() { levelName.textContent = t('lvl' + choice.level); levelNote.textContent = choice.level + ' / ' + maxLevel; }
    var range = h('input', { type: 'range', id: 'play-level', min: '1', max: String(maxLevel), step: '1', value: String(choice.level), oninput: function () { choice.level = +range.value; drawLevel(); } });
    drawSeg(); drawLevel();
    page.appendChild(h('section', { class: 'hero' }, h('span', { class: 'eyebrow', text: t('play') }), h('h2', { text: t('playComputer') }), h('p', { class: 'muted', text: t(HCC.sf.state === 'ready' ? 'stockfishOn' : 'playSub') })));
    page.appendChild(h('div', { class: 'card', style: 'display:flex;flex-direction:column;gap:14px' },
      h('div', { class: 'field' }, h('label', { text: t('color') }), seg),
      h('div', { class: 'field' }, h('label', { for: 'play-level', text: t('level') }), h('div', { class: 'level' }, range, levelNote), levelName),
      btn(t('start'), 'primary', function () {
        var you = choice.color === 'r' ? (Math.random() < 0.5 ? 'w' : 'b') : choice.color;
        store.data.lastLevel = choice.level;
        store.data.play = { fen: C.START_FEN, moves: [], you: you, level: choice.level, result: null };
        store.save(); render();
      })));
    mainEl.appendChild(page);
  }

  // ---------------------------------------------------------------- analysis
  function fmtScore(line, whiteToMove) {
    var sign = whiteToMove ? 1 : -1;
    if (line.mate !== undefined) return (line.mate * sign > 0 ? '#' : '-#') + Math.abs(line.mate);
    var v = line.cp * sign / 100;
    return (v > 0 ? '+' : '') + v.toFixed(2);
  }
  function analysisView() {
    setTop();
    var A = state.analysis || (state.analysis = { fen: C.START_FEN, moves: [], cursor: 0, engine: true });
    var chess = new C.Chess(A.fen), sans = [], lastInfo = null;
    state.cleanup = function () { HCC.stopAnalysis(); };
    var host = h('div'), board = new HCC.Board(host, { onMove: onUser });
    var evalFill = h('i', { style: 'width:50%' }), headEl = h('div', { class: 'status' }), linesEl = h('div', { class: 'lines' }), movesEl = h('div', { class: 'moves' }), tools = h('div', { class: 'btns' });
    board.chess = chess; board.movable = 'both'; HCC._board = board;
    var nav = h('div', { class: 'navrow' },
      btn('', '', function () { goTo(0); }, 'first'), btn('', '', function () { goTo(A.cursor - 1); }, 'back'),
      btn('', '', function () { goTo(A.cursor + 1); }, 'next'), btn('', '', function () { goTo(A.moves.length); }, 'last'));
    ['first', 'back', 'next', 'last'].forEach(function (n, k) { nav.children[k].setAttribute('aria-label', n); });
    mainEl.appendChild(h('div', { class: 'work' }, h('div', { class: 'evalbar' }, evalFill), h('div', { class: 'board-wrap' }, host), nav,
      h('div', { class: 'card', style: 'padding:10px 12px;display:flex;flex-direction:column;gap:6px' }, headEl, linesEl), movesEl, tools));

    function rebuild() {
      chess.load(A.fen); sans = [];
      var c = new C.Chess(A.fen), ok = true;
      A.moves.forEach(function (u, k) {
        if (!ok) return;
        var m = c.parseMove(u);
        if (!m) { ok = false; A.moves = A.moves.slice(0, k); return; }
        sans.push(c.san(m)); c.make(m);
      });
      if (A.cursor > A.moves.length) A.cursor = A.moves.length;
      if (A.cursor < 0) A.cursor = 0;
      for (var i = 0; i < A.cursor; i++) chess.play(A.moves[i]);
    }
    function drawMoves() {
      HCC.clear(movesEl);
      var blackFirst = A.fen.split(' ')[1] === 'b', first = parseInt(A.fen.split(' ')[5], 10) || 1;
      sans.forEach(function (san, k) {
        var ply = k + (blackFirst ? 1 : 0);
        if (ply % 2 === 0 || k === 0) movesEl.appendChild(h('span', { class: 'n', text: (first + Math.floor(ply / 2)) + (ply % 2 ? '…' : '.') }));
        movesEl.appendChild(h('button', { type: 'button', class: 'm' + (k === A.cursor - 1 ? ' cur' : ''), text: san, onclick: function () { goTo(k + 1); } }));
      });
      var cur = movesEl.querySelector('.cur');
      if (cur) movesEl.scrollTop = Math.max(0, cur.offsetTop - movesEl.clientHeight / 2);   // scroll the list only, never the page
    }
    function drawEngine() {
      HCC.clear(headEl); HCC.clear(linesEl);
      var over = chess.gameOver(), white = chess.turn === 0;
      headEl.appendChild(icon('cpu', 'chev'));
      if (over) {
        headEl.appendChild(h('span', { class: 'grow', text: t(over === 'checkmate' ? 'checkmate' : (over === 'stalemate' ? 'stalemate' : 'draw')) }));
        evalFill.style.width = over === 'checkmate' ? (white ? '0%' : '100%') : '50%';
        return;
      }
      if (!A.engine) { headEl.appendChild(h('span', { class: 'grow muted', text: t('engineOff') })); return; }
      var info = lastInfo;
      headEl.appendChild(h('span', { class: 'grow', text: info && info.engine ? info.engine : (HCC.sf.state === 'ready' ? HCC.sf.name : t('builtin')) }));
      if (!info || !info.lines.length) { headEl.appendChild(h('span', { class: 'pill', text: '…' })); return; }
      headEl.appendChild(h('span', { class: 'pill ltr', text: t('depth') + ' ' + info.depth }));
      var best = info.lines[0], wcp = best.mate !== undefined ? (best.mate * (white ? 1 : -1) > 0 ? 9999 : -9999) : best.cp * (white ? 1 : -1);
      evalFill.style.width = Math.max(3, Math.min(97, 50 + 50 * Math.tanh(wcp / 450))) + '%';
      info.lines.forEach(function (ln) {
        var c = new C.Chess(chess.fen()), parts = [];
        (ln.pv || []).slice(0, 8).forEach(function (u, k) {
          var m = c.parseMove(u);
          if (!m) return;
          if (c.turn === 0) parts.push(c.full + '.'); else if (k === 0) parts.push(c.full + '…');
          parts.push(c.san(m)); c.make(m);
        });
        linesEl.appendChild(h('div', { class: 'ln' }, h('span', { class: 'sc', text: fmtScore(ln, white) }), h('span', { class: 'pv', text: parts.join(' ') })));
      });
    }
    function startEngine() {
      lastInfo = null;
      HCC.stopAnalysis();
      if (!A.engine || chess.gameOver()) return;
      var fen = chess.fen();
      HCC.analyse(A.fen, A.moves.slice(0, A.cursor), function (info) {
        if (chess.fen() !== fen) return;
        lastInfo = info; drawEngine();
      });
    }
    function drawTools() {
      HCC.clear(tools);
      tools.appendChild(btn(t('flipBoard'), '', function () { board.flip(); }, 'flip'));
      tools.appendChild(btn(t(A.engine ? 'engineOff' : 'engineOn'), '', function () { A.engine = !A.engine; drawTools(); startEngine(); drawEngine(); }, 'cpu'));
      tools.appendChild(btn(t('setup'), '', setupSheet, 'upload'));
    }
    function refresh(animate) {
      var hist = chess.history();
      board.update({ last: hist.length ? hist[hist.length - 1] : 0, animate: !!animate });
      drawMoves(); startEngine(); drawEngine();
    }
    function goTo(n) {
      if (n < 0 || n > A.moves.length || n === A.cursor) return;
      var forward = n === A.cursor + 1;
      A.cursor = n; rebuild(); refresh(forward);
    }
    function onUser(m) {
      var u = C.uci(m);
      if (A.moves[A.cursor] !== u) { A.moves = A.moves.slice(0, A.cursor); A.moves.push(u); }
      A.cursor++; rebuild(); refresh(true);
    }
    function setupSheet() {
      var area = h('textarea', { id: 'setup-text', dir: 'ltr', spellcheck: 'false' }), msg = h('div');
      openSheet(t('setup'), [
        h('div', { class: 'field' }, h('label', { for: 'setup-text', text: t('pasteFenPgn') }), area), msg,
        h('div', { class: 'btns' },
          btn(t('load'), 'primary', function () {
            var text = area.value.trim(), c = new C.Chess(), err = text ? c.load(text) : 'empty';
            if (!err) { A.fen = c.fen(); A.moves = []; A.cursor = 0; }
            else {
              var games = text ? C.parsePgn(text) : [];
              if (!games.length || !games[0].line.length) { HCC.clear(msg); msg.appendChild(h('div', { class: 'note bad', text: t('badInput') })); return; }
              A.fen = games[0].fen; A.moves = games[0].line.map(function (n) { return n.uci; }); A.cursor = A.moves.length;
            }
            closeSheet(); rebuild(); refresh();
          }),
          btn(t('startPos'), '', function () { A.fen = C.START_FEN; A.moves = []; A.cursor = 0; closeSheet(); rebuild(); refresh(); }),
          btn(t('cancel'), 'ghost', closeSheet))
      ]);
    }
    rebuild(); drawTools(); refresh();
  }

  // ---------------------------------------------------------------- sheets
  function openSheet(title, children) {
    closeSheet();
    var box = h('div', { class: 'sheet', role: 'dialog', 'aria-label': title },
      h('div', { class: 'row' }, h('h2', { class: 'grow', text: title }), h('button', { type: 'button', class: 'icon-btn', 'aria-label': t('close'), onclick: closeSheet }, icon('close'))), children);
    sheetEl = h('div', { class: 'sheet-bg', onclick: function (e) { if (e.target === sheetEl) closeSheet(); } }, box);
    document.body.appendChild(sheetEl);
  }
  function closeSheet() { if (sheetEl) { document.body.removeChild(sheetEl); sheetEl = null; } }

  function settingsSheet() {
    var d = store.data, importMsg = h('div'), importList = h('div', { class: 'list' }), resetBox = h('div', { class: 'btns' });
    function seg(options, current, pickFn) {
      var s = h('div', { class: 'seg', role: 'group' });
      options.forEach(function (o) { s.appendChild(h('button', { type: 'button', 'aria-pressed': String(current === o[0]), text: o[1], onclick: function () { pickFn(o[0]); } })); });
      return s;
    }
    function reopen() { render(); settingsSheet(); }
    function drawImports() {
      HCC.clear(importList);
      (d.imports || []).forEach(function (im, k) {
        importList.appendChild(h('div', { class: 'unit' }, h('span', { class: 'grow ltr', text: im.name }),
          btn(t('remove'), 'danger', function () { d.imports.splice(k, 1); store.save(); content.load().then(reopen); })));
      });
    }
    function note(cls, text) { importMsg.appendChild(h('div', { class: 'note' + (cls ? ' ' + cls : ''), text: text })); }
    var kindSel = h('select', { id: 'import-kind' },
      h('option', { value: 'lessons-edu', text: t('kLessonsEdu') }), h('option', { value: 'lessons-comp', text: t('kLessonsComp') }),
      h('option', { value: 'puzzles-pgn', text: t('kPuzzlesPgn') }), h('option', { value: 'puzzles-csv', text: t('kPuzzlesCsv') }));
    var fileIn = h('input', { type: 'file', id: 'import-file', accept: '.pgn,.csv,.txt,text/plain,text/csv,application/x-chess-pgn', style: 'position:absolute;opacity:0;width:1px;height:1px', onchange: function () {
      var file = fileIn.files && fileIn.files[0];
      HCC.clear(importMsg);
      if (!file) return;
      if (file.size > 8 * 1024 * 1024) { note('bad', t('importBig')); fileIn.value = ''; return; }
      var reader = new FileReader(), kind = kindSel.value;
      reader.onload = function () {
        var res;
        try { res = content.ingest(kind, file.name, String(reader.result)); } catch (e) { res = { count: 0, bad: 0 }; }
        fileIn.value = '';
        if (!res.count) { note('bad', t('importErr')); return; }
        var entry = { kind: kind, name: file.name, text: String(reader.result) };
        if (kind === 'puzzles-csv') {   // keep only what the app needs; the raw CSV is much larger
          entry.kind = 'puzzles-json';
          entry.text = JSON.stringify(res.puzzles.map(function (p) { return [p.id, p.fen, p.moves.join(' '), p.rating, p.themes.join(' '), p.last || '']; }));
        }
        d.imports = d.imports || []; d.imports.push(entry);
        if (!store.save()) { d.imports.pop(); note('bad', t('storageFull')); }
        note('good', t('imported', { n: res.count, f: file.name }));
        if (res.bad) note('', t('importWarn', { n: res.bad }));
        drawImports(); render();
      };
      reader.onerror = function () { note('bad', t('importErr')); };
      reader.readAsText(file);
    } });
    function drawReset(confirming) {
      HCC.clear(resetBox);
      if (!confirming) { resetBox.appendChild(btn(t('resetProgress'), 'danger', function () { drawReset(true); })); return; }
      resetBox.appendChild(h('div', { class: 'note bad', style: 'flex:1 1 100%', text: t('resetAsk') }));
      resetBox.appendChild(btn(t('resetYes'), 'danger', function () { store.reset(); reopen(); }));
      resetBox.appendChild(btn(t('cancel'), '', function () { drawReset(false); }));
    }
    var A = HCC.APP, about = h('div', { class: 'card' },
      h('div', { class: 'kv' }, h('span', { text: A.name, class: 'ltr' }), h('span', { class: 'ltr', text: t('version') + ' ' + A.version })),
      A.academy ? h('div', { class: 'kv' }, h('span', { text: t('academy') }), h('span', { class: 'ltr', text: A.academy })) : null,
      h('div', { class: 'kv' }, h('span', { text: t('engine') }), h('span', { text: HCC.sf.state === 'ready' ? HCC.sf.name : t('builtin') })),
      h('div', { class: 'kv' }, h('span', { text: t('lessons') }), h('span', { class: 'ltr', text: String(content.courses.reduce(function (n, c) { return n + c.units.length; }, 0)) })),
      h('div', { class: 'kv' }, h('span', { text: t('puzzles') }), h('span', { class: 'ltr', text: String(content.puzzles.length) })));
    var contact = [];
    if (A.facebook) contact.push(h('a', { class: 'btn', href: A.facebook, target: '_blank', rel: 'noopener', text: t('facebookPage') }));
    if (A.phone) contact.push(h('a', { class: 'btn ltr', href: 'tel:' + A.phone, text: t('phone') + ' ' + A.phone }));
    if (A.whatsapp) contact.push(h('a', { class: 'btn ltr', href: 'https://wa.me/' + A.whatsapp.replace(/\D/g, ''), target: '_blank', rel: 'noopener', text: t('whatsapp') + ' ' + A.whatsapp }));
    drawImports(); drawReset(false);
    openSheet(t('settings'), [
      h('div', { class: 'field' }, h('label', { text: t('language') }), seg([['ar', 'العربية'], ['en', 'English']], d.lang, function (v) { d.lang = v; store.save(); HCC.applyLang(); renderTabs(); reopen(); })),
      h('div', { class: 'field' }, h('label', { text: t('boardColors') }), seg([['blue', t('blue')], ['wood', t('wood')], ['green', t('green')], ['slate', t('slate')]], d.theme || 'blue', function (v) { d.theme = v; store.save(); reopen(); })),
      h('label', { class: 'row', for: 'set-coords' }, h('input', { type: 'checkbox', id: 'set-coords', checked: d.coords ? true : null, style: 'width:20px;height:20px;accent-color:var(--accent-ink)', onchange: function (e) { d.coords = e.target.checked; store.save(); render(); } }), h('span', { text: t('coords') })),
      h('div', { class: 'card', style: 'display:flex;flex-direction:column;gap:10px' },
        h('h3', { text: t('addContent') }), h('p', { class: 'muted', text: t('addContentSub') }),
        h('div', { class: 'field' }, h('label', { for: 'import-kind', text: t('kind') }), kindSel),
        h('label', { class: 'btn dark', for: 'import-file' }, icon('upload'), t('chooseFile')), fileIn, importMsg, importList),
      resetBox,
      h('div', { class: 'field' }, h('label', { text: t('about') }), about),
      contact.length ? h('div', { class: 'field' }, h('label', { text: t('contact') }), h('div', { class: 'btns' }, contact)) : null,
      h('div', { class: 'field' }, h('label', { text: t('privacy') }), h('p', { class: 'muted', text: t('privacyText') })),
      btn(t('licenses'), '', licensesSheet)
    ]);
  }

  /** GPL notices: what the app contains, where its source is, and the full licence text. */
  function licensesSheet() {
    var A = HCC.APP, full = h('pre', { class: 'lic-text', dir: 'ltr' });
    var link = function (href, text) { return h('a', { class: 'btn', href: href, target: '_blank', rel: 'noopener', text: text }); };
    openSheet(t('licenses'), [
      h('p', { text: t('licIntro') }),
      A.sourceUrl ? link(A.sourceUrl, t('sourceCode')) : h('div', { class: 'note', text: t('sourcePending') }),
      h('div', { class: 'card', style: 'display:flex;flex-direction:column;gap:8px' },
        h('p', { text: t('licStockfish') }),
        h('div', { class: 'btns' }, link('https://github.com/official-stockfish/Stockfish', t('licSfSource')), link('https://github.com/nmrugg/stockfish.js/releases/tag/v19.0.1', t('licSfjsSource')))),
      h('p', { class: 'muted', text: t('licPuzzles') }),
      h('p', { class: 'muted', text: t('licContent') }),
      h('p', { class: 'muted', text: t('licNoWarranty') }),
      h('details', null, h('summary', { text: t('licFull') }), full)
    ]);
    full.textContent = t('loading');
    fetch('engine/COPYING.txt').then(function (r) { return r.ok ? r.text() : Promise.reject(); })
      .then(function (txt) { full.textContent = txt; })
      .catch(function () { full.textContent = 'GNU General Public License v3: https://www.gnu.org/licenses/gpl-3.0.html'; });
  }

  // ---------------------------------------------------------------- start
  /** Used by the Android shell for the system Back button. Returns false when the app should close. */
  HCC.back = function () {
    if (sheetEl) { closeSheet(); return true; }
    if (state.backFn) { state.backFn(); return true; }
    if (state.tab !== 'home') { go('home'); return true; }
    return false;
  };

  HCC.start = function () {
    store.load(); HCC.applyLang();
    var app = document.getElementById('app');
    HCC.clear(app);
    topEl = h('header', { class: 'top' }); mainEl = h('main'); tabsEl = h('nav', { class: 'tabs' });
    app.appendChild(topEl); app.appendChild(mainEl); app.appendChild(tabsEl);
    var want = (location.hash || '').replace('#', '');
    if (TABS.some(function (x) { return x[0] === want; })) state.tab = want;
    window.addEventListener('hashchange', function () {
      var tab = (location.hash || '').replace('#', '');
      if (tab !== state.tab && TABS.some(function (x) { return x[0] === tab; })) { state.tab = tab; renderTabs(); render(); }
    });
    setTop(); renderTabs();
    content.load().then(function () { render(); });
    // When Stockfish turns out to be bundled, refresh the screens that offer it.
    HCC.sf.init().then(function (ok) { if (ok && !sheetEl && (state.tab === 'analysis' || (state.tab === 'play' && !store.data.play))) render(); });
  };
})(window);
