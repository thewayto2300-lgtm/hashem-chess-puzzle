/* Hashem Chess Puzzle — small UI toolkit: DOM helper, icons, languages, saved state. */
(function (root) {
  'use strict';
  var HCC = root.HCC = {};

  HCC.APP = {
    name: 'Hashem Chess Puzzle',
    academy: 'Hashem Chess Castle',      // the academy behind the app, shown on the About sheet
    version: '1.0.0',
    // Academy contact details shown on the About sheet. Leave a field empty to hide it.
    facebook: 'https://www.facebook.com/profile.php?id=61569383516230',
    phone: '',
    whatsapp: '+20 1208238221',
    sourceUrl: 'https://github.com/thewayto2300-lgtm/hashem-chess-puzzle'        // where the app's source code is published (needed if Stockfish is bundled, see README)
  };

  /** h('div', {class: 'x', onclick: fn}, child, 'text', [more]) */
  HCC.h = function (tag, attrs) {
    var el = document.createElement(tag), k;
    if (attrs) for (k in attrs) {
      var v = attrs[k];
      if (v === null || v === undefined || v === false) continue;
      if (k === 'class') el.className = v;
      else if (k === 'text') el.textContent = v;
      else if (k === 'style') el.style.cssText = v;
      else if (k.slice(0, 2) === 'on' && typeof v === 'function') el.addEventListener(k.slice(2), v);
      else el.setAttribute(k, v === true ? '' : v);
    }
    for (var i = 2; i < arguments.length; i++) add(el, arguments[i]);
    return el;
  };
  function add(el, c) {
    if (c === null || c === undefined || c === false) return;
    if (Array.isArray(c)) { c.forEach(function (x) { add(el, x); }); return; }
    el.appendChild(c.nodeType ? c : document.createTextNode(String(c)));
  }
  HCC.clear = function (el) { while (el.firstChild) el.removeChild(el.firstChild); return el; };

  var ICONS = {
    home: 'M3 11l9-8 9 8M5 10v10h14V10M10 20v-6h4v6',
    book: 'M4 5a2 2 0 0 1 2-2h13v16H6a2 2 0 0 0-2 2zM4 19V5M9 8h6',
    bolt: 'M13 2L4 14h7l-1 8 9-12h-7z',
    pawn: 'M12 3a3 3 0 0 1 2 5.2c2 1 2 3 .5 4 .3 3 1.8 5 3.5 6.3V21H6v-2.5c1.7-1.3 3.2-3.3 3.5-6.3-1.5-1-1.5-3 .5-4A3 3 0 0 1 12 3z',
    chart: 'M4 20V10M10 20V4M16 20v-8M21 20H3',
    sliders: 'M4 6h10M18 6h2M4 12h4M12 12h8M4 18h12M14 4v4M8 10v4M16 16v4',
    back: 'M15 5l-7 7 7 7',
    next: 'M9 5l7 7-7 7',
    first: 'M18 5l-7 7 7 7M7 5v14',
    last: 'M6 5l7 7-7 7M17 5v14',
    flip: 'M7 4v16M7 4L4 7M7 4l3 3M17 20V4M17 20l-3-3M17 20l3-3',
    bulb: 'M9 18h6M10 21h4M12 3a6 6 0 0 0-4 10.5c.7.7 1 1.5 1 2.5h6c0-1 .3-1.8 1-2.5A6 6 0 0 0 12 3z',
    undo: 'M8 7L4 11l4 4M4 11h11a5 5 0 0 1 0 10h-3',
    check: 'M5 12l5 5 9-10',
    close: 'M6 6l12 12M18 6L6 18',
    redo: 'M20 11a8 8 0 1 0-2.3 5.7M20 4v7h-7',
    flag: 'M5 21V4M5 4h11l-2 4 2 4H5',
    cpu: 'M6 6h12v12H6zM9 9h6v6H9zM4 9h2M4 15h2M18 9h2M18 15h2M9 4v2M15 4v2M9 18v2M15 18v2',
    eye: 'M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12zM12 9a3 3 0 1 0 0 6 3 3 0 0 0 0-6z',
    upload: 'M12 16V4M12 4L7 9M12 4l5 5M4 16v4h16v-4'
  };
  HCC.icon = function (name, cls) {
    var s = document.createElementNS('http://www.w3.org/2000/svg', 'svg'), p = document.createElementNS('http://www.w3.org/2000/svg', 'path');
    s.setAttribute('viewBox', '0 0 24 24'); s.setAttribute('aria-hidden', 'true');
    if (cls) s.setAttribute('class', cls);
    p.setAttribute('d', ICONS[name] || ''); s.appendChild(p);
    return s;
  };
  /** The academy mark for the top bar. The image comes from src/logo.js, which tools/make-brand-assets.py builds from brand/logo.png. */
  HCC.mark = function () {
    var L = root.HCC_LOGO || {};
    return HCC.h('img', { class: 'mark', src: L.src || '', width: L.width || null, height: L.height || null, alt: '' });
  };

  // ---------------------------------------------------------------- saved state
  var KEY = 'hcc.v1';
  function defaults() {
    return {
      lang: 'ar', theme: 'blue', coords: true,
      progress: {},                       // unit id -> stars (1..3)
      puzzle: { rating: 800, best: 800, solved: 0, failed: 0, streak: 0, done: {} },
      play: null, last: null, imports: []
    };
  }
  HCC.store = {
    data: defaults(),
    load: function () {
      try {
        var raw = root.localStorage.getItem(KEY);
        if (raw) { var d = JSON.parse(raw), base = defaults(); for (var k in d) base[k] = d[k]; if (!base.puzzle || !base.puzzle.done) base.puzzle = defaults().puzzle; this.data = base; }
      } catch (e) { /* storage unavailable: keep everything in memory */ }
    },
    save: function () {
      try { root.localStorage.setItem(KEY, JSON.stringify(this.data)); return true; } catch (e) { return false; }
    },
    reset: function () { var lang = this.data.lang, imports = this.data.imports; this.data = defaults(); this.data.lang = lang; this.data.imports = imports; this.save(); }
  };

  // ---------------------------------------------------------------- languages
  var STR = {
    ar: {
      tagline: 'الشطرنج.. أكثر من مجرد لعبة',
      home: 'الرئيسية', lessons: 'الدروس', puzzles: 'الألغاز', play: 'اللعب', analysis: 'التحليل', settings: 'الإعدادات',
      continueLearning: 'أكمل التعلّم', startLearning: 'ابدأ التعلّم', allDone: 'أنهيت كل الدروس المتاحة', review: 'راجع الدروس',
      puzzleRating: 'تقييمك في الألغاز', solved: 'محلول', trainNow: 'تدرّب الآن',
      trackEdu: 'المنهج التعليمي', trackComp: 'المنهج التنافسي',
      trackEduSub: 'قواعد اللعبة وفوائدها', trackCompSub: 'الاستعداد للبطولات والفوز بها',
      playComputer: 'العب ضد الكمبيوتر', playSub: '6 مستويات من المبتدئ إلى المتقدم', analysisBoard: 'لوحة التحليل', analysisSub: 'حلّل أي وضع أو مباراة بالمحرك',
      units: 'درس', of: 'من', lesson: 'الدرس', course: 'الكورس',
      coach: 'المدرب', yourMove: 'دورك. ابحث عن أفضل نقلة.', watch: 'اضغط «التالي» لمتابعة النقلات.',
      cont: 'التالي', hint: 'تلميح', retry: 'حاول مرة أخرى', restart: 'إعادة', nextLesson: 'الدرس التالي', backToList: 'قائمة الدروس',
      notLessonMove: 'ليست هذه النقلة. حاول مرة أخرى.', alsoGood: 'نقلة جيدة أيضًا، لكن الدرس يتابع نقلة أخرى. ابحث عنها.',
      wrong: 'خطأ', right: 'صحيح', wellDone: 'أحسنت!', lessonDone: 'أنهيت الدرس', noLessons: 'لا توجد دروس في هذا المنهج بعد. أضف ملفات PGN من الإعدادات.',
      whiteToMove: 'الدور على الأبيض', blackToMove: 'الدور على الأسود', youWhite: 'أنت تلعب بالأبيض', youBlack: 'أنت تلعب بالأسود',
      mateIn: 'كش مات في {n}', findBest: 'ابحث عن أفضل نقلة', rating: 'التقييم', streak: 'متتالية',
      solution: 'الحل', nextPuzzle: 'اللغز التالي', puzzleSolved: 'حل صحيح', puzzleFailed: 'لم تُحل من أول محاولة',
      refuted: 'نقلتك تسمح بالرد {m}. حاول مرة أخرى.', notBest: 'ليست أفضل نقلة. حاول مرة أخرى.', showing: 'هذا هو الحل.',
      all: 'الكل', noPuzzles: 'لا توجد ألغاز في هذا القسم.',
      pzTheme: 'الموضوع', pzLevel: 'المستوى', pzAuto: 'حسب تقييمي (تلقائي)', pzProgress: 'حللت {d} من {n} لغز هنا',
      newGame: 'مباراة جديدة', takeback: 'تراجع', resign: 'انسحاب', flipBoard: 'اقلب الرقعة', level: 'المستوى', color: 'لونك', white: 'أبيض', black: 'أسود', random: 'عشوائي',
      start: 'ابدأ', thinking: 'الكمبيوتر يفكر…', yourTurn: 'دورك', analyseGame: 'حلّل المباراة',
      youWin: 'فزت بالمباراة!', youLose: 'فاز الكمبيوتر', draw: 'تعادل', byMate: 'بالكش مات', byStalemate: 'بالخنق', byRepetition: 'بتكرار الوضع', byFifty: 'بقاعدة الخمسين نقلة', byMaterial: 'لعدم كفاية القطع', byResign: 'بالانسحاب',
      lvl1: 'مبتدئ جدًا', lvl2: 'مبتدئ', lvl3: 'هاوٍ', lvl4: 'متوسط', lvl5: 'جيد', lvl6: 'متقدم', lvl7: 'Stockfish متوسط', lvl8: 'Stockfish كامل القوة',
      engine: 'المحرك', engineOn: 'تشغيل المحرك', engineOff: 'إيقاف المحرك', builtin: 'المحرك المدمج', depth: 'العمق', setup: 'إدخال وضع',
      pasteFenPgn: 'الصق FEN أو PGN', load: 'تحميل', startPos: 'وضع البداية', cancel: 'إلغاء', badInput: 'تعذّرت قراءة النص. تأكد أنه FEN أو PGN صحيح.',
      gameOver: 'انتهت المباراة', checkmate: 'كش مات', stalemate: 'خنق',
      language: 'اللغة', boardColors: 'ألوان الرقعة', blue: 'أزرق', wood: 'خشبي', green: 'أخضر', slate: 'رمادي', coords: 'إظهار الإحداثيات',
      addContent: 'إضافة محتوى', addContentSub: 'أضف دروسًا أو ألغازًا من ملفاتك. تُحفظ على هذا الجهاز فقط.',
      kind: 'نوع الملف', kLessonsEdu: 'دروس PGN للمنهج التعليمي', kLessonsComp: 'دروس PGN للمنهج التنافسي', kPuzzlesPgn: 'ألغاز PGN', kPuzzlesCsv: 'ألغاز Lichess بصيغة CSV',
      chooseFile: 'اختر ملفًا', imported: 'تمت الإضافة: {n} عنصر من «{f}».', importErr: 'لم نجد محتوى صالحًا في الملف.', importBig: 'الملف أكبر من 8 ميجابايت. قسّمه أو استخدم أداة التحويل المرفقة مع المشروع.',
      importWarn: '{n} عنصر فيه نقلات غير صحيحة وتم اختصاره.', storageFull: 'مساحة التخزين ممتلئة، لم يُحفظ الملف.', remove: 'حذف',
      resetProgress: 'مسح التقدّم', resetAsk: 'سيُمسح تقدّمك في الدروس وتقييم الألغاز. متأكد؟', resetYes: 'نعم، امسح', done: 'تم',
      about: 'عن التطبيق', academy: 'الأكاديمية', version: 'الإصدار', contact: 'تواصل معنا', facebookPage: 'صفحة الأكاديمية على فيسبوك', phone: 'هاتف', whatsapp: 'واتساب',
      licenses: 'التراخيص والكود المصدري', sourceCode: 'الكود المصدري للتطبيق', sourcePending: 'رابط الكود المصدري للتطبيق هيتضاف هنا.',
      licIntro: 'التطبيق ده برنامج حر منشور برخصة GNU GPL الإصدار 3، لأنه بيستخدم محرك Stockfish المنشور بنفس الرخصة. من حقك تستخدمه وتنسخه وتعدّله وتوزّعه بشروط الرخصة، والكود المصدري الكامل متاح.',
      licStockfish: 'محرك Stockfish 19: حقوق النشر لمطوّري Stockfish (T. Romstad و M. Costalba و J. Kiiski و G. Linscott وباقي المساهمين). نسخة WebAssembly من مشروع Stockfish.js لـ Nathan Rugg و Chess.com. الشبكة العصبية للنسخة الخفيفة من Chris Bao (sscg13). الرخصة: GPLv3.',
      licPuzzles: 'الألغاز من قاعدة ألغاز Lichess (lichess.org) المنشورة برخصة CC0.',
      licContent: 'الدروس والشعار واسم الأكاديمية ملك Hashem Chess Castle.',
      licNoWarranty: 'البرنامج مقدَّم بدون أي ضمان، طبقًا للبندين 15 و16 من الرخصة.',
      licFull: 'نص رخصة GPLv3 كاملًا', licSfSource: 'كود Stockfish المصدري', licSfjsSource: 'كود Stockfish.js 19.0.1', loading: 'جاري التحميل…',
      privacy: 'الخصوصية', privacyText: 'التطبيق لا يجمع أي بيانات شخصية ولا يحتاج إلى الإنترنت. تقدّمك في الدروس والألغاز يُحفظ على جهازك فقط.',
      close: 'إغلاق', move: 'نقلة', moves: 'نقلات', puzzlesCount: '{n} لغز', stockfishOn: 'Stockfish يعمل', stockfishOff: 'Stockfish غير مضاف، يعمل المحرك المدمج'
    },
    en: {
      tagline: 'Chess… more than just a game',
      home: 'Home', lessons: 'Lessons', puzzles: 'Puzzles', play: 'Play', analysis: 'Analysis', settings: 'Settings',
      continueLearning: 'Continue learning', startLearning: 'Start learning', allDone: 'You finished every available lesson', review: 'Review lessons',
      puzzleRating: 'Your puzzle rating', solved: 'solved', trainNow: 'Train now',
      trackEdu: 'Educational track', trackComp: 'Competitive track',
      trackEduSub: 'The rules of the game and what it teaches', trackCompSub: 'Preparing for tournaments and winning them',
      playComputer: 'Play the computer', playSub: '6 levels from beginner to advanced', analysisBoard: 'Analysis board', analysisSub: 'Analyse any position or game with the engine',
      units: 'lessons', of: 'of', lesson: 'Lesson', course: 'Course',
      coach: 'Coach', yourMove: 'Your move. Find the best one.', watch: 'Press Next to follow the moves.',
      cont: 'Next', hint: 'Hint', retry: 'Try again', restart: 'Restart', nextLesson: 'Next lesson', backToList: 'Lesson list',
      notLessonMove: 'Not this move. Try again.', alsoGood: 'A good move too, but the lesson follows a different one. Look for it.',
      wrong: 'Wrong', right: 'Correct', wellDone: 'Well done!', lessonDone: 'Lesson complete', noLessons: 'No lessons in this track yet. Add PGN files from Settings.',
      whiteToMove: 'White to move', blackToMove: 'Black to move', youWhite: 'You play White', youBlack: 'You play Black',
      mateIn: 'Mate in {n}', findBest: 'Find the best move', rating: 'Rating', streak: 'Streak',
      solution: 'Solution', nextPuzzle: 'Next puzzle', puzzleSolved: 'Solved', puzzleFailed: 'Not solved first time',
      refuted: 'Your move allows {m}. Try again.', notBest: 'Not the best move. Try again.', showing: 'Here is the solution.',
      all: 'All', noPuzzles: 'No puzzles in this section.',
      pzTheme: 'Theme', pzLevel: 'Level', pzAuto: 'Match my rating (automatic)', pzProgress: 'Solved {d} of {n} puzzles here',
      newGame: 'New game', takeback: 'Take back', resign: 'Resign', flipBoard: 'Flip board', level: 'Level', color: 'Your colour', white: 'White', black: 'Black', random: 'Random',
      start: 'Start', thinking: 'Computer is thinking…', yourTurn: 'Your turn', analyseGame: 'Analyse the game',
      youWin: 'You won!', youLose: 'The computer won', draw: 'Draw', byMate: 'by checkmate', byStalemate: 'by stalemate', byRepetition: 'by repetition', byFifty: 'by the fifty-move rule', byMaterial: 'by insufficient material', byResign: 'by resignation',
      lvl1: 'First steps', lvl2: 'Beginner', lvl3: 'Casual', lvl4: 'Intermediate', lvl5: 'Strong', lvl6: 'Advanced', lvl7: 'Stockfish medium', lvl8: 'Stockfish full strength',
      engine: 'Engine', engineOn: 'Engine on', engineOff: 'Engine off', builtin: 'Built-in engine', depth: 'Depth', setup: 'Set up position',
      pasteFenPgn: 'Paste a FEN or PGN', load: 'Load', startPos: 'Starting position', cancel: 'Cancel', badInput: 'Could not read that text. Check that it is a valid FEN or PGN.',
      gameOver: 'Game over', checkmate: 'Checkmate', stalemate: 'Stalemate',
      language: 'Language', boardColors: 'Board colours', blue: 'Blue', wood: 'Wood', green: 'Green', slate: 'Slate', coords: 'Show coordinates',
      addContent: 'Add content', addContentSub: 'Add lessons or puzzles from your own files. They are saved on this device only.',
      kind: 'File type', kLessonsEdu: 'PGN lessons, educational track', kLessonsComp: 'PGN lessons, competitive track', kPuzzlesPgn: 'PGN puzzles', kPuzzlesCsv: 'Lichess puzzles (CSV)',
      chooseFile: 'Choose a file', imported: 'Added {n} items from "{f}".', importErr: 'No usable content was found in the file.', importBig: 'The file is larger than 8 MB. Split it, or use the conversion tool that ships with the project.',
      importWarn: '{n} items had illegal moves and were cut short.', storageFull: 'Storage is full, the file was not saved.', remove: 'Remove',
      resetProgress: 'Reset progress', resetAsk: 'This clears your lesson progress and puzzle rating. Are you sure?', resetYes: 'Yes, reset', done: 'Done',
      about: 'About', academy: 'Academy', version: 'Version', contact: 'Contact', facebookPage: 'The academy on Facebook', phone: 'Phone', whatsapp: 'WhatsApp',
      licenses: 'Licences and source code', sourceCode: 'App source code', sourcePending: 'The link to the app source code will appear here.',
      licIntro: 'This app is free software released under the GNU GPL version 3, because it includes the Stockfish engine, which uses the same licence. You may use, copy, change and share it under the licence terms, and the complete source code is available.',
      licStockfish: 'Stockfish 19 engine: copyright the Stockfish developers (T. Romstad, M. Costalba, J. Kiiski, G. Linscott and other contributors). WebAssembly build from Stockfish.js by Nathan Rugg and Chess.com. Lite network by Chris Bao (sscg13). Licence: GPLv3.',
      licPuzzles: 'Puzzles from the Lichess puzzle database (lichess.org), released under CC0.',
      licContent: 'The lessons, logo and academy name belong to Hashem Chess Castle.',
      licNoWarranty: 'The program comes with no warranty, as stated in sections 15 and 16 of the licence.',
      licFull: 'Full GPLv3 licence text', licSfSource: 'Stockfish source code', licSfjsSource: 'Stockfish.js 19.0.1 source', loading: 'Loading…',
      privacy: 'Privacy', privacyText: 'This app collects no personal data and does not need the internet. Your lesson and puzzle progress is stored on your device only.',
      close: 'Close', move: 'move', moves: 'moves', puzzlesCount: '{n} puzzles', stockfishOn: 'Stockfish is running', stockfishOff: 'Stockfish is not bundled, the built-in engine is used'
    }
  };
  HCC.t = function (key, vars) {
    var s = (STR[HCC.store.data.lang] || STR.ar)[key];
    if (s === undefined) s = STR.en[key] !== undefined ? STR.en[key] : key;
    if (vars) for (var k in vars) s = s.replace('{' + k + '}', vars[k]);
    return s;
  };
  /** Picks the current language from "عربي || English" text. Text without the separator is used as is. */
  HCC.pick = function (text) {
    if (!text) return '';
    var i = text.indexOf('||');
    if (i < 0) return text.trim();
    return (HCC.store.data.lang === 'ar' ? text.slice(0, i) : text.slice(i + 2)).trim();
  };
  HCC.applyLang = function () {
    var ar = HCC.store.data.lang === 'ar';
    document.documentElement.lang = ar ? 'ar' : 'en';
    document.documentElement.dir = ar ? 'rtl' : 'ltr';
  };
  HCC.hash = function (s) {
    var h = 5381;
    for (var i = 0; i < s.length; i++) h = ((h << 5) + h + s.charCodeAt(i)) | 0;
    return (h >>> 0).toString(36);
  };
})(window);
