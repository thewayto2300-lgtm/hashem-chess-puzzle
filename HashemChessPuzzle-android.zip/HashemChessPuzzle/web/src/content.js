/* Hashem Chess Puzzle — content: turns PGN files into courses, and puzzle files into the puzzle pool. */
(function (root) {
  'use strict';
  var HCC = root.HCC, C = root.HCChess;

  var content = HCC.content = { courses: [], puzzles: [], warnings: [] };

  /**
   * PGN conventions for lessons (see README):
   *   [Course "…"] groups games into a course, [Title "…"] names the lesson, [Track "educational" | "competitive"],
   *   [Hero "white" | "black"] is the side the student plays (default: the side to move), [Mode "watch"] steps through every move.
   *   Text may hold both languages as "عربي || English".
   */
  function lessonsFromPgn(text, sourceName, defaultTrack) {
    var games = C.parsePgn(text), byCourse = {}, order = [], bad = 0;
    games.forEach(function (g, n) {
      if (!g.line.length) return;
      if (g.errors.length) bad++;
      var hd = g.headers;
      var courseTitle = hd.Course || hd.StudyName || sourceName || hd.Event || 'PGN';
      var title = hd.Title || hd.ChapterName || (hd.White && hd.White !== '?' ? hd.White + (hd.Black && hd.Black !== '?' ? ' – ' + hd.Black : '') : '') || (hd.Event && hd.Event !== '?' ? hd.Event : '') || ('#' + (n + 1));
      var track = /^comp/i.test(hd.Track || defaultTrack || '') ? 'competitive' : 'educational';
      var key = track + '|' + courseTitle;
      if (!byCourse[key]) { byCourse[key] = { id: 'c' + HCC.hash(key), title: courseTitle, track: track, units: [], source: sourceName || '' }; order.push(key); }
      var whiteFirst = g.fen.split(' ')[1] !== 'b';
      var heroWhite = /^b/i.test(hd.Hero || '') ? false : (/^w/i.test(hd.Hero || '') ? true : whiteFirst);
      byCourse[key].units.push({
        id: 'u' + HCC.hash(key + '|' + title + '|' + g.fen + '|' + g.line.slice(0, 4).map(function (x) { return x.san; }).join(' ')),
        title: title, fen: g.fen, heroWhite: heroWhite, watch: /^watch/i.test(hd.Mode || ''),
        intro: g.intro, introArrows: g.introArrows, introMarks: g.introMarks, line: g.line
      });
    });
    return { courses: order.map(function (k) { return byCourse[k]; }), bad: bad };
  }

  /** Puzzles written as PGN: each game is one puzzle from its [FEN], the main line is the solution. */
  function puzzlesFromPgn(text, sourceName) {
    var out = [], bad = 0;
    C.parsePgn(text).forEach(function (g) {
      if (!g.line.length) return;
      if (g.errors.length) bad++;
      var hd = g.headers, moves = g.line.map(function (n) { return n.uci; });
      out.push({
        id: 'p' + HCC.hash(g.fen + moves.join('')), fen: g.fen, moves: moves,
        rating: parseInt(hd.Rating, 10) || 1200, themes: (hd.Themes || hd.Theme || '').split(/[\s,]+/).filter(Boolean),
        title: hd.Title || '', set: sourceName || 'pgn'
      });
    });
    return { puzzles: out, bad: bad };
  }

  /**
   * Lichess puzzle CSV: PuzzleId,FEN,Moves,Rating,RatingDeviation,Popularity,NbPlays,Themes,GameUrl,OpeningTags.
   * The first move in Moves is the opponent's; the puzzle starts after it.
   */
  function puzzlesFromLichessCsv(text, sourceName, limit) {
    var out = [], bad = 0, lines = text.split(/\r?\n/), c = new C.Chess();
    for (var i = 0; i < lines.length && out.length < (limit || 5000); i++) {
      var f = lines[i].split(',');
      if (f.length < 8 || f[0] === 'PuzzleId') continue;
      var moves = f[2].trim().split(/\s+/);
      if (moves.length < 2 || c.load(f[1])) { bad++; continue; }
      if (!c.play(moves[0])) { bad++; continue; }
      var fen = c.fen(), ok = true;
      for (var k = 1; k < moves.length; k++) if (!c.play(moves[k])) { ok = false; break; }
      if (!ok) { bad++; continue; }
      out.push({ id: 'L' + f[0], fen: fen, moves: moves.slice(1), rating: parseInt(f[3], 10) || 1500, themes: f[7].trim().split(/\s+/).filter(Boolean), last: moves[0], set: sourceName || 'lichess' });
    }
    return { puzzles: out, bad: bad };
  }

  /** Compact puzzle list produced by tools/import-lichess-puzzles.js and used for the built-in set: [[id, fen, "m1 m2", rating, "themes", last], …] */
  function puzzlesFromCompact(rows, setName) {
    return rows.map(function (r) {
      return { id: r[0], fen: r[1], moves: r[2].split(' '), rating: r[3], themes: r[4] ? r[4].split(' ') : [], last: r[5] || '', set: setName };
    });
  }

  function addCourses(list) {
    list.forEach(function (course) {
      var same = content.courses.filter(function (x) { return x.id === course.id; })[0];
      if (same) {
        var seen = {};
        same.units.forEach(function (u) { seen[u.id] = 1; });
        course.units.forEach(function (u) { if (!seen[u.id]) same.units.push(u); });
      } else content.courses.push(course);
    });
  }
  function addPuzzles(list) {
    var seen = {};
    content.puzzles.forEach(function (p) { seen[p.id] = 1; });
    list.forEach(function (p) { if (!seen[p.id]) { seen[p.id] = 1; content.puzzles.push(p); } });
  }

  /** Reads one file's text according to its kind. Returns { count, bad }. */
  content.ingest = function (kind, name, text) {
    var r;
    if (kind === 'lessons-edu' || kind === 'lessons-comp' || kind === 'lessons') {
      r = lessonsFromPgn(text, name.replace(/\.[^.]+$/, ''), kind === 'lessons-comp' ? 'competitive' : 'educational');
      addCourses(r.courses);
      return { count: r.courses.reduce(function (n, c) { return n + c.units.length; }, 0), bad: r.bad };
    }
    if (kind === 'puzzles-csv') r = puzzlesFromLichessCsv(text, name.replace(/\.[^.]+$/, ''), 5000);
    else if (kind === 'puzzles-json') r = { puzzles: puzzlesFromCompact(JSON.parse(text), name.replace(/\.[^.]+$/, '')), bad: 0 };
    else r = puzzlesFromPgn(text, name.replace(/\.[^.]+$/, ''));
    addPuzzles(r.puzzles);
    return { count: r.puzzles.length, bad: r.bad, puzzles: r.puzzles };
  };

  function kindOf(file, group) {
    if (/\.csv$/i.test(file)) return 'puzzles-csv';
    if (/\.json$/i.test(file)) return 'puzzles-json';
    return group === 'puzzles' ? 'puzzles-pgn' : 'lessons';
  }

  /**
   * Loads everything: the built-in set, files listed in content/index.json (bundled with the Android app),
   * and files the user imported on this device.
   */
  content.load = function () {
    content.courses = []; content.puzzles = []; content.warnings = [];
    (root.HCC_BUILTIN.lessons || []).forEach(function (f) { content.ingest('lessons', f.name, f.text); });
    addPuzzles(puzzlesFromCompact(root.HCC_BUILTIN.puzzles || [], 'builtin'));
    (HCC.store.data.imports || []).forEach(function (im) {
      try { content.ingest(im.kind, im.name, im.text); } catch (e) { content.warnings.push(im.name); }
    });
    return fetch('content/index.json').then(function (r) { if (!r.ok) throw new Error('none'); return r.json(); }).then(function (idx) {
      var files = [];
      ['lessons', 'puzzles'].forEach(function (group) {
        (idx[group] || []).forEach(function (file) { if (/^[\w.\-]+$/.test(file)) files.push({ file: file, group: group }); });
      });
      return Promise.all(files.map(function (f) {
        return fetch('content/' + f.file).then(function (r) { return r.ok ? r.text() : ''; }).catch(function () { return ''; });
      })).then(function (texts) {
        files.forEach(function (f, i) {            // ingest in the order the index lists them
          if (!texts[i]) { content.warnings.push(f.file); return; }
          try { content.ingest(kindOf(f.file, f.group), f.file, texts[i]); } catch (e) { content.warnings.push(f.file); }
        });
      });
    }).catch(function () { /* no bundled extras */ });
  };

  content.track = function (track) { return content.courses.filter(function (c) { return c.track === track; }); };
  content.progressOf = function (units) {
    var p = HCC.store.data.progress, done = 0;
    units.forEach(function (u) { if (p[u.id]) done++; });
    return { done: done, total: units.length };
  };
  /** The first unfinished lesson, educational track first. */
  content.nextUnit = function () {
    var p = HCC.store.data.progress, order = content.track('educational').concat(content.track('competitive'));
    for (var i = 0; i < order.length; i++) for (var k = 0; k < order[i].units.length; k++) if (!p[order[i].units[k].id]) return { course: order[i], index: k };
    return null;
  };
})(window);
