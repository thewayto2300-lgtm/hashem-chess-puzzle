/* Hashem Chess Puzzle — the board: draws a position, handles tap-tap and drag moves, promotion, highlights and arrows. */
(function (root) {
  'use strict';
  var HCC = root.HCC, C = root.HCChess, h = HCC.h;
  var SVGNS = 'http://www.w3.org/2000/svg';
  var ARROW = { G: '#22884e', R: '#c93a2c', Y: '#d0a41e', B: '#2a6fbe' };

  function pieceEl(p) {
    var d = h('div', { class: 'pc ' + (p & 8 ? 'b' : 'w') });
    var s = document.createElementNS(SVGNS, 'svg'), u = document.createElementNS(SVGNS, 'use');
    s.setAttribute('viewBox', '0 0 100 100');
    u.setAttribute('href', '#pc-' + (p & 7));
    s.appendChild(u); d.appendChild(s);
    return d;
  }

  /**
   * new Board(host, { onMove(move) })
   * board.chess   — the position to show (an HCChess.Chess)
   * board.movable — null, 'w', 'b' or 'both': whose pieces the user may move
   * board.orient  — 'w' or 'b': which side is at the bottom
   */
  function Board(host, opts) {
    this.host = host; this.opts = opts || {};
    this.chess = null; this.movable = null; this.orient = 'w';
    this.sel = -1; this.legal = []; this.lastMove = 0; this.drag = null; this.promo = null;
    this.arrows = []; this.marks = []; this.flash = null; this.hintSq = -1;
    host.classList.add('bd');
    this.sqLayer = h('div', { class: 'bd-sq' });
    this.pcLayer = h('div', { class: 'bd-pc' });
    this.ov = document.createElementNS(SVGNS, 'svg');
    this.ov.setAttribute('class', 'bd-ov'); this.ov.setAttribute('viewBox', '0 0 80 80');
    host.appendChild(this.sqLayer); host.appendChild(this.pcLayer); host.appendChild(this.ov);
    this.sqEls = {}; this.pcEls = {};
    this.buildSquares();
    var self = this;
    host.addEventListener('pointerdown', function (e) { self.down(e); });
    host.addEventListener('pointermove', function (e) { self.moveDrag(e); });
    host.addEventListener('pointerup', function (e) { self.up(e); });
    host.addEventListener('pointercancel', function () { if (self.drag) { self.drag = null; self.update(); } });
  }

  Board.prototype.buildSquares = function () {
    HCC.clear(this.sqLayer); this.sqEls = {};
    var coords = HCC.store.data.coords;
    for (var row = 0; row < 8; row++) for (var col = 0; col < 8; col++) {
      var sq = this.orient === 'w' ? row * 16 + col : (7 - row) * 16 + (7 - col);
      var dark = ((sq >> 4) + (sq & 7)) & 1;
      var el = h('div', { class: dark ? 'd' : 'l' });
      if (coords && row === 7) el.appendChild(h('span', { class: 'co f', text: 'abcdefgh'.charAt(sq & 7) }));
      if (coords && col === 0) el.appendChild(h('span', { class: 'co r', text: String(8 - (sq >> 4)) }));
      this.sqLayer.appendChild(el); this.sqEls[sq] = el;
    }
  };

  Board.prototype.xy = function (sq) {
    var f = sq & 7, r = sq >> 4;
    return this.orient === 'w' ? [f, r] : [7 - f, 7 - r];
  };
  Board.prototype.sqAt = function (x, y) {
    var r = this.host.getBoundingClientRect(), cx = Math.floor((x - r.left) / (r.width / 8)), cy = Math.floor((y - r.top) / (r.height / 8));
    if (cx < 0 || cx > 7 || cy < 0 || cy > 7) return -1;
    return this.orient === 'w' ? cy * 16 + cx : (7 - cy) * 16 + (7 - cx);
  };

  Board.prototype.flip = function () { this.orient = this.orient === 'w' ? 'b' : 'w'; this.buildSquares(); this.update(); };
  Board.prototype.setOrient = function (o) { if (o !== this.orient) { this.orient = o; this.buildSquares(); } };

  /** Redraws from this.chess. opts: { last: move to highlight, animate: slide the moved piece } */
  Board.prototype.update = function (opts) {
    opts = opts || {};
    if (opts.last !== undefined) this.lastMove = opts.last;
    var c = this.chess, sq, el, k;
    if (!c) return;
    this.sel = -1; this.legal = []; this.closePromo();
    HCC.clear(this.pcLayer); this.pcEls = {};
    for (sq = 0; sq < 120; sq++) {
      if (sq & 0x88) { sq += 7; continue; }
      var p = c.board[sq];
      if (!p) continue;
      el = pieceEl(p);
      var xy = this.xy(sq);
      el.style.left = (xy[0] * 12.5) + '%'; el.style.top = (xy[1] * 12.5) + '%';
      this.pcLayer.appendChild(el); this.pcEls[sq] = el;
    }
    if (opts.animate && this.lastMove) {
      var from = C.mFrom(this.lastMove), to = C.mTo(this.lastMove), a = this.xy(from), b = this.xy(to), mover = this.pcEls[to];
      if (mover) {
        mover.style.transform = 'translate(' + ((a[0] - b[0]) * 100) + '%,' + ((a[1] - b[1]) * 100) + '%)';
        mover.getBoundingClientRect();                    // commit the start position before animating
        mover.classList.add('anim'); mover.style.transform = '';
      }
    }
    this.paint();
  };

  /** Applies square highlights, target dots, marks and arrows without touching the pieces. */
  Board.prototype.paint = function () {
    var c = this.chess, sq, el, i;
    for (sq in this.sqEls) { el = this.sqEls[sq]; el.classList.remove('last', 'sel', 'tgt', 'cap', 'chk', 'hint', 'good', 'bad'); el.removeAttribute('data-mk'); }
    if (this.lastMove) { this.sqEls[C.mFrom(this.lastMove)].classList.add('last'); this.sqEls[C.mTo(this.lastMove)].classList.add('last'); }
    if (c.inCheck()) this.sqEls[c.kingSq[c.turn >> 3]].classList.add('chk');
    if (this.hintSq >= 0) this.sqEls[this.hintSq].classList.add('hint');
    if (this.flash) this.sqEls[this.flash.sq].classList.add(this.flash.kind);
    if (this.sel >= 0) {
      this.sqEls[this.sel].classList.add('sel');
      for (i = 0; i < this.legal.length; i++) {
        var m = this.legal[i];
        if (C.mFrom(m) !== this.sel) continue;
        el = this.sqEls[C.mTo(m)]; el.classList.add('tgt');
        if (C.mFlags(m) & C.F_CAPTURE) el.classList.add('cap');
      }
    }
    for (i = 0; i < this.marks.length; i++) { var ms = C.sqIndex(this.marks[i].sq); if (ms >= 0) this.sqEls[ms].setAttribute('data-mk', ARROW[this.marks[i].color] ? this.marks[i].color : 'G'); }
    HCC.clear(this.ov);
    for (i = 0; i < this.arrows.length; i++) this.drawArrow(this.arrows[i]);
  };

  Board.prototype.drawArrow = function (a) {
    var f = C.sqIndex(a.from), t = C.sqIndex(a.to);
    if (f < 0 || t < 0) return;
    var p = this.xy(f), q = this.xy(t), x1 = p[0] * 10 + 5, y1 = p[1] * 10 + 5, x2 = q[0] * 10 + 5, y2 = q[1] * 10 + 5;
    var dx = x2 - x1, dy = y2 - y1, len = Math.sqrt(dx * dx + dy * dy);
    if (!len) return;
    var ux = dx / len, uy = dy / len, hx = x2 - ux * 3.6, hy = y2 - uy * 3.6, col = ARROW[a.color] || ARROW.G;
    var line = document.createElementNS(SVGNS, 'line');
    line.setAttribute('x1', x1 + ux * 3); line.setAttribute('y1', y1 + uy * 3); line.setAttribute('x2', hx); line.setAttribute('y2', hy);
    line.setAttribute('stroke', col); line.setAttribute('stroke-width', '1.9'); line.setAttribute('stroke-linecap', 'round'); line.setAttribute('opacity', '.82');
    var head = document.createElementNS(SVGNS, 'polygon');
    head.setAttribute('points', [x2 - ux * 0.6, y2 - uy * 0.6, hx - uy * 2.3, hy + ux * 2.3, hx + uy * 2.3, hy - ux * 2.3].join(' '));
    head.setAttribute('fill', col); head.setAttribute('opacity', '.9');
    this.ov.appendChild(line); this.ov.appendChild(head);
  };

  /** Replaces the coach's arrows and circled squares. */
  Board.prototype.draw = function (arrows, marks) { this.arrows = arrows || []; this.marks = marks || []; this.paint(); };
  Board.prototype.setHint = function (sq) { this.hintSq = sq; this.paint(); };
  /** Briefly colours a square: kind is 'good' or 'bad'. */
  Board.prototype.blink = function (sq, kind) {
    var self = this, f = { sq: sq, kind: kind };
    this.flash = f; this.paint();
    setTimeout(function () { if (self.flash === f) { self.flash = null; self.paint(); } }, 700);
  };

  Board.prototype.mayMove = function (p) {
    if (!p || !this.movable || !this.chess) return false;
    var white = !(p & 8);
    if (white !== (this.chess.turn === 0)) return false;
    return this.movable === 'both' || (this.movable === 'w') === white;
  };
  Board.prototype.select = function (sq) {
    this.sel = sq;
    this.legal = sq >= 0 ? this.chess.legalMoves() : [];
    this.paint();
  };
  Board.prototype.movesTo = function (to) {
    var out = [];
    for (var i = 0; i < this.legal.length; i++) if (C.mFrom(this.legal[i]) === this.sel && C.mTo(this.legal[i]) === to) out.push(this.legal[i]);
    return out;
  };

  Board.prototype.down = function (e) {
    if (!this.movable || this.promo || !this.chess) return;
    var sq = this.sqAt(e.clientX, e.clientY);
    if (sq < 0) return;
    if (this.sel >= 0 && this.movesTo(sq).length) { this.attempt(sq); return; }
    if (this.mayMove(this.chess.board[sq])) {
      this.select(sq);
      this.drag = { sq: sq, x: e.clientX, y: e.clientY, el: this.pcEls[sq], moved: false, id: e.pointerId };
      try { this.host.setPointerCapture(e.pointerId); } catch (err) { /* older WebView */ }
    } else this.select(-1);
  };
  Board.prototype.moveDrag = function (e) {
    var d = this.drag;
    if (!d || !d.el) return;
    var dx = e.clientX - d.x, dy = e.clientY - d.y;
    if (!d.moved && dx * dx + dy * dy > 49) { d.moved = true; d.el.classList.remove('anim'); d.el.classList.add('drag'); }
    if (d.moved) d.el.style.transform = 'translate(' + dx + 'px,' + dy + 'px) scale(1.15)';
  };
  Board.prototype.up = function (e) {
    var d = this.drag;
    if (!d) return;
    this.drag = null;
    if (!d.moved) return;                       // a tap: the piece stays selected for tap-tap moves
    var sq = this.sqAt(e.clientX, e.clientY);
    if (sq >= 0 && this.movesTo(sq).length) this.attempt(sq);
    else this.update();
  };

  Board.prototype.attempt = function (to) {
    var options = this.movesTo(to), self = this;
    if (options.length === 1) { this.fire(options[0]); return; }
    // Several legal moves share from/to only for promotions: ask which piece.
    var white = this.chess.turn === 0, box = h('div');
    [C.QUEEN, C.ROOK, C.BISHOP, C.KNIGHT].forEach(function (t) {
      var mv = options.filter(function (m) { return C.mPromo(m) === t; })[0];
      if (!mv) return;
      box.appendChild(h('button', { type: 'button', 'aria-label': 'QRBN'.charAt([C.QUEEN, C.ROOK, C.BISHOP, C.KNIGHT].indexOf(t)), onclick: function () { self.closePromo(); self.fire(mv); } }, pieceEl((white ? 0 : 8) | t)));
    });
    this.promo = h('div', { class: 'bd-promo', onpointerdown: function (ev) { ev.stopPropagation(); if (ev.target === self.promo) { self.closePromo(); self.update(); } } }, box);
    this.host.appendChild(this.promo);
  };
  Board.prototype.closePromo = function () { if (this.promo) { this.host.removeChild(this.promo); this.promo = null; } };
  Board.prototype.fire = function (m) {
    this.sel = -1; this.legal = [];
    if (this.opts.onMove) this.opts.onMove(m);
  };

  HCC.Board = Board;
})(window);
