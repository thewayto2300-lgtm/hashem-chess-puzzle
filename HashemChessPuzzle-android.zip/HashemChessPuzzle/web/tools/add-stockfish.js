#!/usr/bin/env node
/*
 * Bundles Stockfish (WebAssembly build from the "stockfish" npm package) with the app.
 *
 *   cd web
 *   npm install stockfish
 *   node tools/add-stockfish.js            (optional: --flavor lite-single | single | asm)
 *
 * Copies the engine files to app/src/main/assets/www/engine/ and writes engine.json.
 * The single-threaded builds are used because they need no special server headers.
 * Stockfish is GPLv3: if you ship it, publish this app's source code and link it (see README.md).
 */
const fs = require('fs'), path = require('path');
const i = process.argv.indexOf('--flavor'), flavor = i >= 0 ? process.argv[i + 1] : 'lite-single';
const pkg = path.join(__dirname, '../node_modules/stockfish'), out = path.join(__dirname, '../../app/src/main/assets/www/engine');
if (!fs.existsSync(pkg)) { console.error('The stockfish package is not installed. Run "npm install stockfish" inside the web folder first.'); process.exit(1); }
function walk(dir, list) { for (const e of fs.readdirSync(dir, { withFileTypes: true })) { const p = path.join(dir, e.name); if (e.isDirectory()) { if (e.name !== 'node_modules') walk(p, list); } else list.push(p); } return list; }
const files = walk(pkg, []);
const suffix = flavor === 'asm' ? /-asm\.js$/ : (flavor === 'single' ? /stockfish[\w.-]*\d-single\.js$/ : /-lite-single\.js$/);
const js = files.filter(f => suffix.test(path.basename(f))).sort().pop();
if (!js) { console.error('No "' + flavor + '" engine file was found in ' + pkg + '. Files present: ' + files.filter(f => /\.js$/.test(f)).map(f => path.basename(f)).join(', ')); process.exit(1); }
const wasm = js.replace(/\.js$/, '.wasm');
if (flavor !== 'asm' && !fs.existsSync(wasm)) { console.error('Found ' + path.basename(js) + ' but not its .wasm file.'); process.exit(1); }
fs.mkdirSync(out, { recursive: true });
for (const old of fs.readdirSync(out)) if (/^stockfish.*\.(js|wasm)$/.test(old)) fs.unlinkSync(path.join(out, old));
const copied = [js].concat(flavor === 'asm' ? [] : [wasm]);
for (const f of copied) fs.copyFileSync(f, path.join(out, path.basename(f)));
const licence = files.find(f => /^(copying|license)(\.txt|\.md)?$/i.test(path.basename(f)));
if (licence) fs.copyFileSync(licence, path.join(out, 'STOCKFISH-LICENSE.txt'));
fs.writeFileSync(path.join(out, 'engine.json'), JSON.stringify({ worker: path.basename(js) }) + '\n');
const size = copied.reduce((n, f) => n + fs.statSync(f).size, 0);
console.log('Bundled ' + copied.map(f => path.basename(f)).join(' + ') + ' (' + (size / 1048576).toFixed(1) + ' MB).');
console.log('The app now offers Stockfish for analysis and as play levels 7-8.');
