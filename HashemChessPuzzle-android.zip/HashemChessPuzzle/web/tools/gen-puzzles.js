/*
 * Generates the starter puzzle set: mate-in-1 and mate-in-2 positions taken from engine self-play.
 * Every puzzle is checked by exhaustive search: exactly one first move forces the mate.
 * Usage: node tools/gen-puzzles.js <seed> <games> <out.json>
 */
const { Chess, uci, mFlags, mFrom, mTo } = require('../src/chess.js');
const { Engine, LEVELS } = require('../src/engine.js');

let seed = parseInt(process.argv[2] || '1', 10) >>> 0;
const GAMES = parseInt(process.argv[3] || '50', 10), OUT = process.argv[4] || 'puzzles.json';
Math.random = function () { seed = (seed + 0x6d2b79f5) | 0; let t = Math.imul(seed ^ (seed >>> 15), 1 | seed); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };

function matesInOne(c) { const out = []; for (const m of c.legalMoves()) { c.make(m); if (c.isCheckmate()) out.push(m); c.undo(); } return out; }
/** First moves after which every reply allows mate in one. Returns [{key, replies:[{reply, mates:[...]}]}]. */
function matesInTwo(c) {
  const keys = [];
  for (const m of c.legalMoves()) {
    c.make(m);
    const replies = c.legalMoves(); let ok = replies.length > 0; const lines = [];
    if (ok) for (const r of replies) { c.make(r); const ms = matesInOne(c); c.undo(); if (!ms.length) { ok = false; break; } lines.push({ reply: r, mates: ms }); }
    c.undo();
    if (ok) { keys.push({ key: m, lines }); if (keys.length > 1) break; }
  }
  return keys;
}
function material(c) { const v = [0, 1, 3, 3, 5, 9, 0]; let w = 0, b = 0; for (let sq = 0; sq < 120; sq++) { if (sq & 0x88) { sq += 7; continue; } const p = c.board[sq]; if (!p) continue; if (p & 8) b += v[p & 7]; else w += v[p & 7]; } return [w, b]; }

const e = new Engine(), puzzles = [], seen = new Set();
const t0 = Date.now();
for (let g = 0; g < GAMES; g++) {
  const c = new Chess(); const lw = 1 + Math.floor(Math.random() * 3), lb = 1 + Math.floor(Math.random() * 3);
  let gotM1 = false, gotM2 = false;
  for (let ply = 0; ply < 140; ply++) {
    if (c.gameOver()) break;
    if (ply >= 14) {
      const key = c.fen().split(' ').slice(0, 2).join(' ');
      const m1 = matesInOne(c);
      if (m1.length === 1 && !gotM1 && !seen.has(key)) {
        const m = m1[0], [w, b] = material(c), mine = c.turn === 0 ? w : b, theirs = c.turn === 0 ? b : w;
        if (mine - theirs <= 12 && mine + theirs >= 20) {       // skip crushing or bare positions
          const t = c.board[mFrom(m)] & 7; let checks = 0; for (const x of c.legalMoves()) { c.make(x); if (c.inCheck()) checks++; c.undo(); }
          let rating = 480 + (t === 2 || t === 3 || t === 1 ? 140 : 0) + (t === 5 ? 0 : 40) + Math.min(checks - 1, 6) * 35 + (c.inCheck() ? 90 : 0) + (mFlags(m) & 1 ? 0 : 30) + (theirs > mine ? 80 : 0);
          puzzles.push({ fen: c.fen(), moves: [uci(m)], rating: Math.round(rating / 10) * 10, themes: ['mateIn1'] });
          seen.add(key); gotM1 = true;
        }
      } else if (m1.length === 0 && !gotM2 && !seen.has(key)) {
        const keys = matesInTwo(c);
        if (keys.length === 1) {
          const k = keys[0], [w, b] = material(c), mine = c.turn === 0 ? w : b, theirs = c.turn === 0 ? b : w;
          if (mine - theirs <= 10 && mine + theirs >= 20 && k.lines.length >= 1) {
            // Main defence: prefer a reply with a single mating answer, then captures of the key piece.
            const scored = k.lines.map(l => ({ l, s: (l.mates.length === 1 ? 10 : 0) + (mTo(l.reply) === mTo(k.key) ? 5 : 0) + (mFlags(l.reply) & 1 ? 2 : 0) }));
            scored.sort((a, b2) => b2.s - a.s); const main = scored[0].l;
            c.make(k.key); const givesCheck = c.inCheck(); c.undo();
            const sac = c.attacked(mTo(k.key), c.turn ^ 8);
            let rating = 980 + (givesCheck ? 0 : 220) + (sac ? 120 : 0) + Math.min(k.lines.length, 8) * 25 + (theirs > mine ? 80 : 0);
            puzzles.push({ fen: c.fen(), moves: [uci(k.key), uci(main.reply), uci(main.mates[0])], rating: Math.round(rating / 10) * 10, themes: ['mateIn2'] });
            seen.add(key); gotM2 = true; gotM1 = true;
          }
        }
      }
    }
    e.setPosition(c.fen());
    const lvl = c.turn === 0 ? lw : lb;
    const opts = ply < 8 ? { depth: 2, noise: 60 } : Object.assign({}, LEVELS[lvl]);
    const r = e.think(opts); if (!r.move) break; c.play(r.move);
  }
}
require('fs').writeFileSync(OUT, JSON.stringify(puzzles));
console.log('seed', process.argv[2], 'games', GAMES, 'puzzles', puzzles.length, 'm1', puzzles.filter(p => p.themes[0] === 'mateIn1').length, 'm2', puzzles.filter(p => p.themes[0] === 'mateIn2').length, Math.round((Date.now() - t0) / 1000) + 's');
