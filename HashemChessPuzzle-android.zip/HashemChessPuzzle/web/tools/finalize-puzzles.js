/* Merges generated puzzle files, re-checks every puzzle from scratch and writes the compact built-in set. */
const fs = require('fs'), path = require('path');
const { Chess, uci } = require('../src/chess.js');
const files = process.argv.slice(2);
const mates = c => { const o = []; for (const m of c.legalMoves()) { c.make(m); if (c.isCheckmate()) o.push(m); c.undo(); } return o; };
const forced2 = c => { const keys = []; for (const m of c.legalMoves()) { c.make(m); const rs = c.legalMoves(); let ok = rs.length > 0; for (const r of rs) { c.make(r); const n = mates(c).length; c.undo(); if (!n) { ok = false; break; } } c.undo(); if (ok) keys.push(m); } return keys; };
const hash = s => { let h = 5381; for (let i = 0; i < s.length; i++) h = ((h << 5) + h + s.charCodeAt(i)) | 0; return (h >>> 0).toString(36); };
const seen = new Set(), out = []; let rejected = 0;
for (const f of files) for (const p of JSON.parse(fs.readFileSync(f, 'utf8'))) {
  const key = p.fen.split(' ').slice(0, 2).join(' '); if (seen.has(key)) continue; seen.add(key);
  const c = new Chess(p.fen); let ok = false;
  if (p.themes[0] === 'mateIn1') { const m = mates(c); ok = m.length === 1 && uci(m[0]) === p.moves[0] && p.moves.length === 1; }
  else { const k = forced2(c); ok = mates(c).length === 0 && k.length === 1 && uci(k[0]) === p.moves[0] && p.moves.length === 3;
    if (ok) { ok = !!c.play(p.moves[0]) && !!c.play(p.moves[1]) && !!c.play(p.moves[2]) && c.isCheckmate(); } }
  if (!ok) { rejected++; continue; }
  out.push(['b' + hash(p.fen), p.fen, p.moves.join(' '), p.rating, p.themes.join(' ')]);
}
out.sort((a, b) => a[3] - b[3]);
fs.writeFileSync(path.join(__dirname, '../src/content/puzzles.builtin.json'), JSON.stringify(out));
const m1 = out.filter(r => r[4] === 'mateIn1'), m2 = out.filter(r => r[4] === 'mateIn2');
console.log('kept', out.length, 'rejected', rejected, '| mateIn1', m1.length, 'ratings', m1[0][3], '-', m1[m1.length - 1][3], '| mateIn2', m2.length, 'ratings', m2[0][3], '-', m2[m2.length - 1][3]);
