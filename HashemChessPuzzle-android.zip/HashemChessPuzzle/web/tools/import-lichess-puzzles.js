#!/usr/bin/env node
/*
 * Takes a slice of the Lichess puzzle database (CC0) and bundles it with the app.
 *
 *   1. Download lichess_db_puzzle.csv.zst from https://database.lichess.org/#puzzles
 *   2. node tools/import-lichess-puzzles.js lichess_db_puzzle.csv.zst --count 1500 --min 600 --max 2000
 *
 * Options:
 *   --count N        how many puzzles to keep (default 1500)
 *   --min R --max R  rating range (default 600..2000); puzzles are spread evenly across it
 *   --themes a,b     keep only puzzles that have at least one of these Lichess themes (e.g. fork,pin,mateIn2)
 *   --popularity P   minimum Lichess popularity, -100..100 (default 80)
 *   --plays N        minimum number of plays (default 200)
 *   --name NAME      output file name without extension (default lichess)
 *
 * Writes app/src/main/assets/www/content/NAME.json and lists it in content/index.json.
 * A .zst file is read directly on Node 22.15+; on older Node, decompress it first (zstd -d, 7-Zip or PeaZip).
 */
const fs = require('fs'), path = require('path'), zlib = require('zlib'), readline = require('readline');
const { Chess } = require('../src/chess.js');

const args = process.argv.slice(2), input = args.find(a => !a.startsWith('--'));
const opt = (name, def) => { const i = args.indexOf('--' + name); return i >= 0 && args[i + 1] !== undefined ? args[i + 1] : def; };
if (!input || !fs.existsSync(input)) { console.error('Usage: node tools/import-lichess-puzzles.js <lichess_db_puzzle.csv[.zst]> [--count 1500] [--min 600] [--max 2000] [--themes fork,pin]'); process.exit(1); }
const COUNT = +opt('count', 1500), MIN = +opt('min', 600), MAX = +opt('max', 2000), POP = +opt('popularity', 80), PLAYS = +opt('plays', 200);
const THEMES = opt('themes', '').split(',').filter(Boolean), NAME = String(opt('name', 'lichess')).replace(/[^\w.-]/g, '_');
const outDir = path.join(__dirname, '../../app/src/main/assets/www/content');

let stream = fs.createReadStream(input);
if (/\.zst$/i.test(input)) {
  if (typeof zlib.createZstdDecompress !== 'function') { console.error('This Node version cannot read .zst files. Decompress the file first, then pass the .csv.'); process.exit(1); }
  stream = stream.pipe(zlib.createZstdDecompress());
}
const buckets = Math.max(1, Math.ceil((MAX - MIN) / 100)), perBucket = Math.ceil(COUNT / buckets), filled = new Array(buckets).fill(0);
const chess = new Chess(), rows = [];
let seen = 0, invalid = 0;
const rl = readline.createInterface({ input: stream, crlfDelay: Infinity });
rl.on('line', line => {
  if (rows.length >= COUNT) return;
  const f = line.split(',');
  if (f.length < 8 || f[0] === 'PuzzleId') return;
  seen++;
  const rating = +f[3], pop = +f[5], plays = +f[6], themes = f[7].trim().split(/\s+/).filter(Boolean);
  if (!(rating >= MIN && rating < MAX) || pop < POP || plays < PLAYS) return;
  if (THEMES.length && !THEMES.some(t => themes.includes(t))) return;
  const b = Math.min(buckets - 1, Math.floor((rating - MIN) / 100));
  if (filled[b] >= perBucket) return;
  const moves = f[2].trim().split(/\s+/);
  if (moves.length < 2 || chess.load(f[1]) || !chess.play(moves[0])) { invalid++; return; }
  const fen = chess.fen();
  for (let i = 1; i < moves.length; i++) if (!chess.play(moves[i])) { invalid++; return; }
  filled[b]++;
  rows.push(['L' + f[0], fen, moves.slice(1).join(' '), rating, themes.join(' '), moves[0]]);
  if (rows.length >= COUNT) { rl.close(); stream.destroy(); }
});
rl.on('close', () => {
  if (!rows.length) { console.error('No puzzle matched. Check the file and the filters.'); process.exit(1); }
  rows.sort((a, b) => a[3] - b[3]);
  fs.mkdirSync(outDir, { recursive: true });
  fs.writeFileSync(path.join(outDir, NAME + '.json'), JSON.stringify(rows));
  const idxFile = path.join(outDir, 'index.json');
  let idx = { lessons: [], puzzles: [] };
  try { idx = Object.assign(idx, JSON.parse(fs.readFileSync(idxFile, 'utf8'))); } catch (e) { /* new index */ }
  if (!idx.puzzles.includes(NAME + '.json')) idx.puzzles.push(NAME + '.json');
  fs.writeFileSync(idxFile, JSON.stringify(idx, null, 2) + '\n');
  console.log('Read ' + seen + ' puzzles, kept ' + rows.length + ' (ratings ' + rows[0][3] + '-' + rows[rows.length - 1][3] + ')' + (invalid ? ', skipped ' + invalid + ' unreadable' : '') + '.');
  console.log('Wrote content/' + NAME + '.json and updated content/index.json. Lichess puzzles are released under CC0.');
});
