/* Checks every lesson PGN: all moves legal, '#' really is mate, and for the competitive track the engine agrees with the first lesson move. */
const fs = require('fs'), path = require('path');
const { Chess, parsePgn } = require('../src/chess.js');
const { Engine } = require('../src/engine.js');
const dir = path.join(__dirname, '../src/content'); const e = new Engine(); let bad = 0, units = 0;
function walk(line, c, g, depth) { let made = 0;
  for (const n of line) { for (const v of n.vars) walk(v, c, g, depth + 1);
    const san = c.san(n.m); c.make(n.m); made++;
    if (/#$/.test(san) !== c.isCheckmate()) { bad++; console.log('  mate flag mismatch', san); } }
  while (made--) c.undo(); }
for (const f of fs.readdirSync(dir).filter(x => x.endsWith('.pgn')).sort()) {
  const games = parsePgn(fs.readFileSync(path.join(dir, f), 'utf8'));
  console.log(f, games.length, 'units');
  for (const g of games) { units++;
    const title = (g.headers.Title || '?').split('||').pop().trim();
    if (g.errors.length) { bad++; console.log('  ERR', title, g.errors); }
    if (!g.headers.Course || !g.headers.Title || !g.headers.Track) { bad++; console.log('  missing header', title); }
    if (!g.intro) { bad++; console.log('  no intro', title); }
    const c = new Chess(g.fen); walk(g.line, c, g, 0);
    const heroWhite = g.headers.Hero ? g.headers.Hero === 'white' : c.turn === 0;
    // every hero move should have a prompt before it (intro or previous comment) and feedback after it
    const c2 = new Chess(g.fen); let prev = g.intro;
    g.line.forEach((n, i) => { const hero = (c2.turn === 0) === heroWhite; if (hero && !n.comment && i === g.line.length - 1) { bad++; console.log('  last hero move without comment', title, n.san); } c2.make(n.m); });
    if (g.headers.Track === 'competitive') {
      e.setPosition(g.fen); const r = e.think({ depth: 7, movetime: 4000 }); const want = g.line[0].uci;
      const val = x => x.mate !== undefined ? (x.mate > 0 ? 30000 - x.mate * 2 : -30000 - x.mate * 2) : x.cp;
      e.setPosition(g.fen, [want]); const after = e.think({ depth: 6, movetime: 4000 }); const mine = -val(after);
      const mateLoss = r.mate !== undefined && r.mate > 0 && !(after.mate !== undefined && -after.mate + 1 <= r.mate && after.mate < 0);
      if (r.move !== want && (mateLoss || val(r) - mine > 60)) { bad++; console.log('  ENGINE DISAGREES', title, 'lesson', want, mine, 'engine', r.move, JSON.stringify(r)); }
      else console.log('  engine ok', title.padEnd(30), 'lesson', want, 'engine', r.move, r.mate !== undefined ? 'mate ' + r.mate : r.cp + 'cp');
    }
  }
}
// specific claims made in the lesson text
const claim = (name, ok) => { if (!ok) { bad++; console.log('  CLAIM FAILED', name); } };
let c = new Chess('7k/8/5K2/6Q1/8/8/8/8 w - - 0 1'); c.play('Qg6'); claim('Qg6 is stalemate', c.isStalemate());
c = new Chess('6k1/8/8/8/8/8/6P1/r6K w - - 0 1'); claim('Kh2 only move', c.legalMoves().length === 1 && c.san(c.legalMoves()[0]) === 'Kh2');
c = new Chess('4r1k1/8/8/8/8/8/3P1P2/3QKB2 w - - 0 1'); claim('only two blocks', c.legalMoves().map(m => c.san(m)).sort().join() === 'Be2,Qe2');
c = new Chess('k7/6R1/2K5/8/8/8/8/8 w - - 0 1'); c.play('Kb6'); claim('after Kb6 only Kb8', c.legalMoves().length === 1 && c.san(c.legalMoves()[0]) === 'Kb8');
c = new Chess('k7/6R1/2K5/8/8/8/8/8 w - - 0 1'); c.play('Kc7'); claim('Kc7 lets Ka7', c.legalMoves().map(m => c.san(m)).join() === 'Ka7'); c = new Chess('k7/6R1/2K5/8/8/8/8/8 w - - 0 1'); c.play('Rb7'); claim('Rb7 stalemate', c.isStalemate());
c = new Chess('3r3k/6pp/8/6N1/8/1Q6/8/6K1 w - - 0 1'); c.play('Nf7+'); claim('Nf7+ only Kg8', c.legalMoves().length === 1); c.play('Kg8'); c.play('Nh6+'); claim('Nh6+ two king moves', c.legalMoves().map(m => c.san(m)).sort().join() === 'Kf8,Kh8'); c.play('Kh8'); c.play('Qg8+'); claim('Qg8+ only Rxg8', c.legalMoves().length === 1 && c.san(c.legalMoves()[0]) === 'Rxg8');
c = new Chess('8/8/8/2k5/7R/6R1/8/6K1 w - - 0 1'); for (const m of ['Rg5+', 'Kb6', 'Rh6+', 'Kc7', 'Rg7+', 'Kb8', 'Rh8#']) claim('ladder ' + m, !!c.play(m)); claim('ladder mate', c.isCheckmate());
c = new Chess(); for (const m of 'e4 e5 Nf3 d6 Bc4 Bg4 Nc3 g6 Nxe5 Bxd1 Bxf7+'.split(' ')) c.play(m); claim('Legal: Ke7 only', c.legalMoves().length === 1);
c = new Chess('5rk1/3q1ppp/8/8/8/3B1N2/5PPP/3R2K1 w - - 0 1'); c.play('Bb5'); claim('Bb5 allows Qxd1+', !!c.parseMove('Qxd1+'));
console.log(units, 'units;', bad ? bad + ' PROBLEMS' : 'content OK');
