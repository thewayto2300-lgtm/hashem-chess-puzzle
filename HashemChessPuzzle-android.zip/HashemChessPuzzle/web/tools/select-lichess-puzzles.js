#!/usr/bin/env node
/*
 * Picks a balanced set of puzzles from (part of) the Lichess puzzle database (CC0):
 * up to QUOTA puzzles for every theme at every level, so each theme has puzzles across all levels.
 *   node tools/select-lichess-puzzles.js <lichess_db_puzzle.csv or .csv.zst> [quota]
 * Writes src/content/puzzles.lichess.json (compact rows), which build.js bundles into the app.
 */
const fs = require('fs'), path = require('path'), zlib = require('zlib');
const { Chess } = require('../src/chess.js');
const input = process.argv[2], QUOTA = +(process.argv[3] || 40);
const THEMES = new Set(('fork pin skewer discoveredAttack doubleCheck hangingPiece trappedPiece sacrifice deflection attraction capturingDefender interference clearance xRayAttack intermezzo quietMove zugzwang defensiveMove exposedKing kingsideAttack queensideAttack attackingF2F7 advancedPawn promotion underPromotion enPassant castling ' +
  'mate mateIn1 mateIn2 mateIn3 mateIn4 mateIn5 backRankMate smotheredMate anastasiaMate arabianMate bodenMate doubleBishopMate dovetailMate hookMate ' +
  'opening middlegame endgame pawnEndgame rookEndgame bishopEndgame knightEndgame queenEndgame queenRookEndgame oneMove short long veryLong').split(' '));
const BANDS = [800, 1100, 1400, 1700, 2000, 2300, 99999];
const level = r => BANDS.findIndex(b => r < b);
const counts = {}, rows = [], chess = new Chess();
let seen = 0, invalid = 0, buf = '';
function take(line) {
  const f = line.split(',');
  if (f.length < 8 || f[0] === 'PuzzleId') return;
  seen++;
  const rating = +f[3], dev = +f[4], pop = +f[5], plays = +f[6];
  if (dev > 90 || pop < 80 || plays < 200) return;
  const themes = f[7].trim().split(/\s+/).filter(t => THEMES.has(t));
  if (!themes.length) return;
  const lv = level(rating);
  if (!themes.some(t => (counts[t + lv] || 0) < QUOTA)) return;
  const moves = f[2].trim().split(/\s+/);
  if (moves.length < 2 || chess.load(f[1]) || !chess.play(moves[0])) { invalid++; return; }
  const fen = chess.fen();
  for (let i = 1; i < moves.length; i++) if (!chess.play(moves[i])) { invalid++; return; }
  themes.forEach(t => { counts[t + lv] = (counts[t + lv] || 0) + 1; });
  rows.push(['L' + f[0], fen, moves.slice(1).join(' '), rating, themes.join(' '), moves[0]]);
}
// Accepts the plain CSV or a .zst file (Lichess publishes it in seekable zstd frames).
const z = /\.zst$/i.test(input) ? fs.createReadStream(input).pipe(zlib.createZstdDecompress()) : fs.createReadStream(input);
z.on('data', d => { buf += d.toString('utf8'); const lines = buf.split('\n'); buf = lines.pop(); lines.forEach(take); });
const finish = () => {
  rows.sort((a, b) => a[3] - b[3]);
  const out = path.join(__dirname, '../src/content/puzzles.lichess.json');
  fs.writeFileSync(out, JSON.stringify(rows));
  const perLevel = BANDS.map((_, i) => rows.filter(r => level(r[3]) === i).length);
  const perTheme = {}; rows.forEach(r => r[4].split(' ').forEach(t => perTheme[t] = (perTheme[t] || 0) + 1));
  console.log('read', seen, 'kept', rows.length, 'invalid', invalid, (fs.statSync(out).size / 1048576).toFixed(1) + ' MB');
  console.log('per level', perLevel.join(' '));
  console.log('themes', Object.keys(perTheme).length, 'smallest', Object.entries(perTheme).sort((a, b) => a[1] - b[1]).slice(0, 8).map(e => e.join(':')).join(' '));
};
let done = false;
z.on('end', () => { if (!done) { done = true; finish(); } });
z.on('error', () => { if (!done) { done = true; finish(); } });   // a leading part of the file ends mid-stream
