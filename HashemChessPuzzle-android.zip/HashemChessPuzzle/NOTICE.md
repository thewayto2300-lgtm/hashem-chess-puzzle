# Hashem Chess Puzzle — notices

Copyright (C) 2026 Hashem Chess Castle.

**Program.** The program (everything under `app/` and `web/`, including the lessons and puzzles bundled inside `index.html`) is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License version 3 (see `LICENSE`). It is distributed WITHOUT ANY WARRANTY; see the licence for details.

**Stockfish.** The app includes Stockfish 19 (Stockfish.js v19.0.1, lite single-threaded build), copyright the Stockfish developers and Chess.com, LLC, released under GPLv3.
Source: https://github.com/official-stockfish/Stockfish and https://github.com/nmrugg/stockfish.js/releases/tag/v19.0.1

**Puzzles.** Puzzles from the Lichess puzzle database (https://database.lichess.org), released into the public domain (CC0).

**Names and logo (GPLv3 section 7(e)).** This licence does not grant any rights to use the names "Hashem Chess Castle" and "Hashem Chess Puzzle" or the academy logo. Modified versions must not use them.

**Separate content.** Lesson and puzzle files added later as separate files under `app/src/main/assets/www/content/` (listed in `content/index.json`) are separate works owned by Hashem Chess Castle, all rights reserved, unless a file says otherwise. They are data read by the program, not part of it.
