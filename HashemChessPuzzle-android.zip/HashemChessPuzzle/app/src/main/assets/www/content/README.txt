Put your own lesson and puzzle files in this folder and list them in index.json, for example:

  { "lessons": ["my-course.pgn"], "puzzles": ["lichess.json", "my-puzzles.pgn"] }

File names may use letters, digits, dots, dashes and underscores only.
The PGN conventions are described in README.md at the top of the project.
